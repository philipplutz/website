################################################################################
# Replication Code for:
# "Towards more fairness among states: How Dublin Transfers Redistribute Asylum Responsibility"
#
# Author: Philipp Lutz
# Journal: European Union Politics
# Date: February 2026
#
# Description:
# This script replicates all analyses and figures in the manuscript and 
# supplementary material. The analysis examines fairness in Dublin asylum 
# transfers between EU member states from 2008-2024.
#
# Required data files (to be placed in working directory):
# KEY DATA FILES:
# - dataset_dublin_transfers.csv (prepared Dublin transfer data)
# - sovereignty_total.csv (sovereignty clause usage data)

# Output:
# - All figures from manuscript and supplementary material
# - Summary statistics reported in tables
#
# R Version: 4.x or higher
################################################################################

# ==============================================================================
# 1. SETUP: Load Required Packages
# ==============================================================================

# Install packages if needed (uncomment the following lines):
# install.packages(c("foreign", "stringr", "dplyr", "ggplot2", "hrbrthemes",
#                    "readxl", "ggrepel", "tidyr", "xtable", "countrycode",
#                    "gridExtra", "ggpubr", "patchwork", "tidyverse", "purrr", "lme4", "readr",
#                    "sf", "viridis", "rnaturalearth", "rnaturalearthdata"))

library(foreign)
library(stringr)
library(dplyr)
library(ggplot2)
library(hrbrthemes)
library(readxl)
library(readr)
library(ggrepel)
library(tidyr)
library(xtable)
library(countrycode)
library(gridExtra)
library(ggpubr)
library(patchwork)
library(tidyverse)
library(purrr)
library(lme4)
library(sf)
library(viridis)
library(rnaturalearth)
library(rnaturalearthdata)

# load main dataset 
dataset <- read.csv("dataset_dublin_transfers.csv", check.names = FALSE)

## prepare variables
dataset$transfer_net <- dataset$`Incoming Transfers to GEO` - dataset$`Outgoing Transfers from GEO`
dataset$transfers <- dataset$`Incoming Transfers to GEO` + dataset$`Outgoing Transfers from GEO`
dataset$transfer_rate_distributive <- (abs(dataset$transfer_net))/(dataset$`Incoming Transfers to GEO` + dataset$`Outgoing Transfers from GEO`)*100
dataset$requests_net <- dataset$`Incoming Requests` - dataset$`Outgoing Requests`
dataset$requests <- dataset$`Incoming Requests` + dataset$`Outgoing Requests`
dataset$decisions_net <- dataset$`Positive Decisions Incoming Requests` - dataset$`Positive Decisions Outgoing Requests`
dataset$decisions <- dataset$`Positive Decisions Incoming Requests` + dataset$`Positive Decisions Outgoing Requests`
dataset$requests_net_eurodac <- dataset$`Incoming Requests_Eurodac` - dataset$`Outgoing Requests_Eurodac`
dataset$requests_eurodac <- dataset$`Incoming Requests_Eurodac` + dataset$`Outgoing Requests_Eurodac`
dataset$decisions_net_eurodac <- dataset$`Positive Decisions Incoming Requests_Eurodac` - dataset$`Positive Decisions Outgoing Requests_Eurodac`
dataset$decisions_eurodac <- dataset$`Positive Decisions Incoming Requests_Eurodac` + dataset$`Positive Decisions Outgoing Requests_Eurodac`

## classify into increasing or decreasing distributive equity on the system-level
dataset$fairredistribution <- "zerosum"
dataset$fairredistribution[dataset$fair_share_fulfilment>100 & dataset$fair_share_fulfilment_partner<100 & dataset$transfer_net<0] <- "more"
dataset$fairredistribution[dataset$fair_share_fulfilment<100 & dataset$fair_share_fulfilment_partner>100 & dataset$transfer_net>0] <- "more"
dataset$fairredistribution[dataset$fair_share_fulfilment>100 & dataset$fair_share_fulfilment_partner<100 & dataset$transfer_net>0] <- "less"
dataset$fairredistribution[dataset$fair_share_fulfilment<100 & dataset$fair_share_fulfilment_partner>100 & dataset$transfer_net<0] <- "less"
dataset$fair <- 0
dataset$fair[dataset$fair_share_fulfilment>100 & dataset$fair_share_fulfilment_partner<100 & dataset$transfer_net<0] <- 1
dataset$fair[dataset$fair_share_fulfilment<100 & dataset$fair_share_fulfilment_partner>100 & dataset$transfer_net>0] <- 1
dataset$fair[dataset$fair_share_fulfilment>100 & dataset$fair_share_fulfilment_partner<100 & dataset$transfer_net>0] <- -1
dataset$fair[dataset$fair_share_fulfilment<100 & dataset$fair_share_fulfilment_partner>100 & dataset$transfer_net<0] <- -1
dataset$faircontribute <- NA
dataset$faircontribute <- abs(dataset$transfer_net)*dataset$fair
# number of fair transfers
dataset$fair_system <- dataset$faircontribute
dataset$fair_system[dataset$fair_system<0] <- 0
# number of unfair transfers
dataset$unfair_system <- dataset$faircontribute
dataset$unfair_system[dataset$unfair_system>0] <- 0
## now based on bilateral fairness
dataset$fairB <- 0
dataset$fairB[dataset$fair_share_fulfilment>dataset$fair_share_fulfilment_partner & dataset$transfer_net<0] <- 1
dataset$fairB[dataset$fair_share_fulfilment<dataset$fair_share_fulfilment_partner & dataset$transfer_net>0] <- 1
dataset$fairB[dataset$fair_share_fulfilment>dataset$fair_share_fulfilment_partner & dataset$transfer_net>0] <- -1
dataset$fairB[dataset$fair_share_fulfilment<dataset$fair_share_fulfilment_partner & dataset$transfer_net<0] <- -1
dataset$faircontributeB <- NA
dataset$faircontributeB <- abs(dataset$transfer_net)*dataset$fairB
# number of fair transfers
dataset$fair_dyad <- dataset$faircontributeB
dataset$fair_dyad[dataset$fair_dyad<0] <- 0
dataset$unfair_dyad <- dataset$faircontributeB
dataset$unfair_dyad[dataset$unfair_dyad>0] <- 0
dataset$unfair_dyad <- abs(dataset$unfair_dyad)
# calculate zero-sum transfers as twice the smaller number of incoming and outgoing transfers
dataset$zerosum <- (pmin(dataset$`Incoming Transfers to GEO`, dataset$`Outgoing Transfers from GEO`, na.rm=T))*2
dataset$transfers_redistributive1 <- dataset$transfers-dataset$zerosum 
dataset$total <- rowSums(dataset[, c("zerosum", "fair_dyad", "unfair_dyad")], na.rm = TRUE)

## and now based on absolute relative burden
dataset$fairredistribution_abs <- "zerosum"
dataset$fairredistribution_abs[dataset$fair_share_fulfilment_abs>0 & dataset$fair_share_fulfilment_abs_partner<0 & dataset$transfer_net<0] <- "more"
dataset$fairredistribution_abs[dataset$fair_share_fulfilment_abs<0 & dataset$fair_share_fulfilment_abs_partner>0 & dataset$transfer_net>0] <- "more"
dataset$fairredistribution_abs[dataset$fair_share_fulfilment_abs>0 & dataset$fair_share_fulfilment_abs_partner<0 & dataset$transfer_net>0] <- "less"
dataset$fairredistribution_abs[dataset$fair_share_fulfilment_abs<0 & dataset$fair_share_fulfilment_abs_partner>0 & dataset$transfer_net<0] <- "less"
dataset$fair_abs <- 0
dataset$fair_abs[dataset$fair_share_fulfilment_abs>0 & dataset$fair_share_fulfilment_abs_partner<0 & dataset$transfer_net<0] <- 1
dataset$fair_abs[dataset$fair_share_fulfilment_abs<0 & dataset$fair_share_fulfilment_abs_partner>0 & dataset$transfer_net>0] <- 1
dataset$fair_abs[dataset$fair_share_fulfilment_abs>0 & dataset$fair_share_fulfilment_abs_partner<0 & dataset$transfer_net>0] <- -1
dataset$fair_abs_abs[dataset$fair_share_fulfilment_abs<0 & dataset$fair_share_fulfilment_abs_partner>0 & dataset$transfer_net<0] <- -1
dataset$faircontribute_abs <- NA
dataset$faircontribute_abs <- abs(dataset$transfer_net)*dataset$fair_abs
# number of fair transfers
dataset$fair_system_abs <- dataset$faircontribute_abs
dataset$fair_system_abs[dataset$fair_system_abs<0] <- 0
# number of unfair transfers
dataset$unfair_system_abs <- dataset$faircontribute_abs
dataset$unfair_system_abs[dataset$unfair_system_abs>0] <- 0

# Bilateral fairness logic (again using absolute burden)
dataset$fairB_abs <- 0
dataset$fairB_abs[
  dataset$fair_share_fulfilment_abs > dataset$fair_share_fulfilment_abs_partner & dataset$transfer_net < 0
] <- 1
dataset$fairB_abs[
  dataset$fair_share_fulfilment_abs < dataset$fair_share_fulfilment_abs_partner & dataset$transfer_net > 0
] <- 1
dataset$fairB_abs[
  dataset$fair_share_fulfilment_abs > dataset$fair_share_fulfilment_abs_partner & dataset$transfer_net > 0
] <- -1
dataset$fairB_abs[
  dataset$fair_share_fulfilment_abs < dataset$fair_share_fulfilment_abs_partner & dataset$transfer_net < 0
] <- -1

## Compute fair contribution at the dyad level
dataset$faircontributeB_abs <- abs(dataset$transfer_net) * dataset$fairB_abs
dataset$fair_dyad_abs <- dataset$faircontributeB_abs
dataset$fair_dyad_abs[dataset$fair_dyad_abs < 0] <- 0
dataset$unfair_dyad_abs <- dataset$faircontributeB_abs
dataset$unfair_dyad_abs[dataset$unfair_dyad_abs > 0] <- 0
dataset$unfair_dyad_abs <- abs(dataset$unfair_dyad_abs)
# Calculate zero-sum transfers
dataset$zerosum <- pmin(
  dataset$`Incoming Transfers to GEO`,
  dataset$`Outgoing Transfers from GEO`,
  na.rm = TRUE
) * 2
# Compute redistributive transfers
dataset$transfers_redistributive1 <- dataset$transfers - dataset$zerosum
# Total transfers
dataset$total_abs <- rowSums(
  dataset[, c("zerosum", "fair_dyad_abs", "unfair_dyad_abs")],
  na.rm = TRUE
)

# ============================================================================
# Prepare data for simulation analyses
# ============================================================================

## based on requests
dataset$fairrequests <- NA
dataset$fairrequests <- abs(dataset$requests_net)*dataset$fair
# number of fair transfers
dataset$fairreq_system <- dataset$fairrequests
dataset$fairreq_system[dataset$fairreq_system<0] <- 0
# number of unfair transfers
dataset$unfairreq_system <- dataset$fairrequests
dataset$unfairreq_system[dataset$unfairreq_system>0] <- 0

## based on decision
dataset$fairdecisions <- NA
dataset$fairdecisions <- abs(dataset$decisions_net)*dataset$fair
# number of fair transfers
dataset$fairdec_system <- dataset$fairdecisions
dataset$fairdec_system[dataset$fairdec_system<0] <- 0
# number of unfair transfers
dataset$unfairdec_system <- dataset$fairdecisions
dataset$unfairdec_system[dataset$unfairdec_system>0] <- 0

## based on Eurodac hits
dataset$fairrequests_eurodac <- NA
dataset$fairrequests_eurodac <- abs(dataset$requests_net_eurodac)*dataset$fair
# number of fair transfers
dataset$fairreq_system_eurodac <- dataset$fairrequests_eurodac
dataset$fairreq_system_eurodac[dataset$fairreq_system_eurodac<0] <- 0
# number of unfair transfers
dataset$unfairreq_system_eurodac <- dataset$fairrequests_eurodac
dataset$unfairreq_system_eurodac[dataset$unfairreq_system_eurodac>0] <- 0
# numberr of fair decisions
dataset$fairdecisions_eurodac <- NA
dataset$fairdecisions_eurodac <- abs(dataset$decisions_net_eurodac)*dataset$fair
# number of fair transfers
dataset$fairdec_system_eurodac <- dataset$fairdecisions_eurodac
dataset$fairdec_system_eurodac[dataset$fairdec_system_eurodac<0] <- 0
# number of unfair transfers
dataset$unfairdec_system_eurodac <- dataset$fairdecisions_eurodac
dataset$unfairdec_system_eurodac[dataset$unfairdec_system_eurodac>0] <- 0

# ============================================================================
# DEFINE SUSPENSION PERIODS
# ============================================================================

dataset$suspension <- 0
# Greece: full suspension since 2011
dataset$suspension[dataset$GEO == "Greece" & dataset$YEAR >= 2011] <- 1
dataset$suspension[dataset$PARTNER == "Greece" & dataset$YEAR >= 2011] <- 1
# Hungary: full suspension since 2015
dataset$suspension[dataset$GEO == "Hungary" & dataset$YEAR >= 2015] <- 1
dataset$suspension[dataset$PARTNER == "Hungary" & dataset$YEAR >= 2015] <- 1
# Bulgaria: partial suspension since 2014
dataset$suspension[dataset$GEO == "Bulgaria" & dataset$YEAR >= 2014] <- 1
dataset$suspension[dataset$PARTNER == "Bulgaria" & dataset$YEAR >= 2014] <- 1
# Italy: partial suspension since 2014
dataset$suspension[dataset$GEO == "Italy" & dataset$YEAR >= 2014] <- 1
dataset$suspension[dataset$PARTNER == "Italy" & dataset$YEAR >= 2014] <- 1
# Croatia: partial suspension since 2022
dataset$suspension[dataset$GEO == "Croatia" & dataset$YEAR >= 2022] <- 1
dataset$suspension[dataset$PARTNER == "Croatia" & dataset$YEAR >= 2022] <- 1
# Malta: sporadic suspension since 2021
dataset$suspension[dataset$GEO == "Malta" & dataset$YEAR >= 2021] <- 1
dataset$suspension[dataset$PARTNER == "Malta" & dataset$YEAR >= 2021] <- 1
# Poland: temporary suspension in 2022
dataset$suspension[dataset$GEO == "Poland" & dataset$YEAR == 2022] <- 1
dataset$suspension[dataset$PARTNER == "Poland" & dataset$YEAR == 2022] <- 1
# Romania: temporary suspension in 2022
dataset$suspension[dataset$GEO == "Romania" & dataset$YEAR == 2022] <- 1
dataset$suspension[dataset$PARTNER == "Romania" & dataset$YEAR == 2022] <- 1

# exclude Liechtenstein
dataset <- subset(dataset, dataset$GEO!="Liechtenstein" & dataset$PARTNER!="Liechtenstein")
# reducing it to 15'270 observations

# create incoming transfer variable based on outgoing transfer statistics of PARTNER

# Step 1: Aggregate outgoing by dyad per year (for Incoming_Transfers)
dyad_outgoing <- dataset %>%
  group_by(GEO, PARTNER, YEAR) %>%
  summarise(Outgoing_sum = sum(`Outgoing Transfers from GEO`, na.rm = TRUE), .groups = "drop")

# Step 2: Aggregate incoming by dyad per year (for Outgoing_Transfers_from_Partner)
dyad_incoming <- dataset %>%
  group_by(GEO, PARTNER, YEAR) %>%
  summarise(Incoming_sum = sum(`Incoming Transfers to GEO`, na.rm = TRUE), .groups = "drop")

# Step 3: Join partner's outgoing with Incoming_Transfers
dataset <- dataset %>%
  left_join(
    dyad_outgoing %>%
      rename(
        GEO_rev = GEO,
        PARTNER_rev = PARTNER,
        Incoming_Transfers = Outgoing_sum
      ),
    by = c(
      "GEO" = "PARTNER_rev",
      "PARTNER" = "GEO_rev",
      "YEAR" = "YEAR"
    )
  )

# Step 4: Join partner's incoming with Outgoing_Transfers_from_Partner
dataset <- dataset %>%
  left_join(
    dyad_incoming %>%
      rename(
        GEO_rev = GEO,
        PARTNER_rev = PARTNER,
        Outgoing_Transfers = Incoming_sum
      ),
    by = c(
      "GEO" = "PARTNER_rev",
      "PARTNER" = "GEO_rev",
      "YEAR" = "YEAR"
    )
  )

# calculate variables based on outgoing data only
dataset$transfer_net_OUTGOING <- dataset$Incoming_Transfers - dataset$`Outgoing Transfers from GEO`
dataset$transfers_OUTGOING <- dataset$Incoming_Transfers + dataset$`Outgoing Transfers from GEO`
dataset$fair_OUTGOING <- 0
dataset$fair_OUTGOING[dataset$fair_share_fulfilment>100 & dataset$fair_share_fulfilment_partner<100 & dataset$transfer_net_OUTGOING<0] <- 1
dataset$fair_OUTGOING[dataset$fair_share_fulfilment<100 & dataset$fair_share_fulfilment_partner>100 & dataset$transfer_net_OUTGOING>0] <- 1
dataset$fair_OUTGOING[dataset$fair_share_fulfilment>100 & dataset$fair_share_fulfilment_partner<100 & dataset$transfer_net_OUTGOING>0] <- -1
dataset$fair_OUTGOING[dataset$fair_share_fulfilment<100 & dataset$fair_share_fulfilment_partner>100 & dataset$transfer_net_OUTGOING<0] <- -1
dataset$faircontribute_OUTGOING <- NA
dataset$faircontribute_OUTGOING <- abs(dataset$transfer_net_OUTGOING)*dataset$fair_OUTGOING
# number of fair transfers
dataset$fair_system_OUTGOING <- dataset$faircontribute_OUTGOING
dataset$fair_system_OUTGOING[dataset$fair_system_OUTGOING<0] <- 0
# number of unfair transfers
dataset$unfair_system_OUTGOING <- dataset$faircontribute_OUTGOING
dataset$unfair_system_OUTGOING[dataset$unfair_system_OUTGOING>0] <- 0
## now based on bilateral fairness
dataset$fairB_OUTGOING <- 0
dataset$fairB_OUTGOING[dataset$fair_share_fulfilment>dataset$fair_share_fulfilment_partner & dataset$transfer_net_OUTGOING<0] <- 1
dataset$fairB_OUTGOING[dataset$fair_share_fulfilment<dataset$fair_share_fulfilment_partner & dataset$transfer_net_OUTGOING>0] <- 1
dataset$fairB_OUTGOING[dataset$fair_share_fulfilment>dataset$fair_share_fulfilment_partner & dataset$transfer_net_OUTGOING>0] <- -1
dataset$fairB_OUTGOING[dataset$fair_share_fulfilment<dataset$fair_share_fulfilment_partner & dataset$transfer_net_OUTGOING<0] <- -1
dataset$faircontributeB_OUTGOING <- NA
dataset$faircontributeB_OUTGOING <- abs(dataset$transfer_net_OUTGOING)*dataset$fairB_OUTGOING
# number of fair transfers
dataset$fair_dyad_OUTGOING <- dataset$faircontributeB_OUTGOING
dataset$fair_dyad_OUTGOING[dataset$fair_dyad_OUTGOING<0] <- 0
dataset$unfair_dyad_OUTGOING <- dataset$faircontributeB_OUTGOING
dataset$unfair_dyad_OUTGOING[dataset$unfair_dyad_OUTGOING>0] <- 0
dataset$unfair_dyad_OUTGOING <- abs(dataset$unfair_dyad_OUTGOING)
# calculate zero-sum transfers as twice the smaller number of incoming and outgoing transfers
dataset$zerosum_OUTGOING <- (pmin(dataset$Incoming_Transfers, dataset$`Outgoing Transfers from GEO`, na.rm=T))*2

# calculate based on incoming
dataset$transfer_net_INCOMING <- dataset$`Incoming Transfers to GEO` - dataset$Outgoing_Transfers
dataset$transfers_INCOMING <- dataset$`Incoming Transfers to GEO` + dataset$Outgoing_Transfers
dataset$fair_INCOMING <- 0
dataset$fair_INCOMING[dataset$fair_share_fulfilment>100 & dataset$fair_share_fulfilment_partner<100 & dataset$transfer_net_INCOMING<0] <- 1
dataset$fair_INCOMING[dataset$fair_share_fulfilment<100 & dataset$fair_share_fulfilment_partner>100 & dataset$transfer_net_INCOMING>0] <- 1
dataset$fair_INCOMING[dataset$fair_share_fulfilment>100 & dataset$fair_share_fulfilment_partner<100 & dataset$transfer_net_INCOMING>0] <- -1
dataset$fair_INCOMING[dataset$fair_share_fulfilment<100 & dataset$fair_share_fulfilment_partner>100 & dataset$transfer_net_INCOMING<0] <- -1
dataset$faircontribute_INCOMING <- NA
dataset$faircontribute_INCOMING <- abs(dataset$transfer_net_INCOMING)*dataset$fair_INCOMING
# number of fair transfers
dataset$fair_system_INCOMING <- dataset$faircontribute_INCOMING
dataset$fair_system_INCOMING[dataset$fair_system_INCOMING<0] <- 0
# number of unfair transfers
dataset$unfair_system_INCOMING <- dataset$faircontribute_INCOMING
dataset$unfair_system_INCOMING[dataset$unfair_system_INCOMING>0] <- 0
## now based on bilateral fairness
dataset$fairB_INCOMING <- 0
dataset$fairB_INCOMING[dataset$fair_share_fulfilment>dataset$fair_share_fulfilment_partner & dataset$transfer_net_INCOMING<0] <- 1
dataset$fairB_INCOMING[dataset$fair_share_fulfilment<dataset$fair_share_fulfilment_partner & dataset$transfer_net_INCOMING>0] <- 1
dataset$fairB_INCOMING[dataset$fair_share_fulfilment>dataset$fair_share_fulfilment_partner & dataset$transfer_net_INCOMING>0] <- -1
dataset$fairB_INCOMING[dataset$fair_share_fulfilment<dataset$fair_share_fulfilment_partner & dataset$transfer_net_INCOMING<0] <- -1
dataset$faircontributeB_INCOMING <- NA
dataset$faircontributeB_INCOMING <- abs(dataset$transfer_net_INCOMING)*dataset$fairB_INCOMING
# number of fair transfers
dataset$fair_dyad_INCOMING <- dataset$faircontributeB_INCOMING
dataset$fair_dyad_INCOMING[dataset$fair_dyad_INCOMING<0] <- 0
dataset$unfair_dyad_INCOMING <- dataset$faircontributeB_INCOMING
dataset$unfair_dyad_INCOMING[dataset$unfair_dyad_INCOMING>0] <- 0
dataset$unfair_dyad_INCOMING <- abs(dataset$unfair_dyad_INCOMING)
# calculate zero-sum transfers as twice the smaller number of incoming and outgoing transfers
dataset$zerosum_INCOMING <- (pmin(dataset$`Incoming Transfers to GEO`, dataset$Outgoing_Transfers, na.rm=T))*2

# Aggregate data by GEO (reporting country)
df_aggregated <- dataset %>%
  group_by(GEO) %>%
  summarise(
    Incoming = sum(`Incoming Transfers to GEO`, na.rm = TRUE),
    Incoming_OUTGOING = sum(Incoming_Transfers, na.rm = TRUE),
    Outgoing = sum(`Outgoing Transfers from GEO`, na.rm = TRUE),
    Outgoing_INCOMING = sum(Outgoing_Transfers, na.rm = TRUE),
    FairContribute = sum(faircontribute, na.rm = TRUE),
    FairContributeB = sum(faircontributeB, na.rm = TRUE),
    Transfers1 = sum(transfers[suspension==0], na.rm = TRUE),
    fair_system1 = sum(fair_system[suspension==0], na.rm = TRUE),
    unfair_system1 = abs(sum(unfair_system[suspension==0], na.rm = TRUE)),
    fair_dyad1 = sum(fair_dyad[suspension==0], na.rm = TRUE),
    unfair_dyad1 = abs(sum(unfair_dyad[suspension==0], na.rm = TRUE)),
    zerosum1 = sum(zerosum[suspension==0], na.rm = TRUE),
    zerosum_fair1 = fair_dyad1-fair_system1,
    zerosum_unfair1 = unfair_dyad1-unfair_system1,
    Transfers = sum(transfers, na.rm = TRUE),
    fair_system = sum(fair_system, na.rm = TRUE),
    unfair_system = abs(sum(unfair_system, na.rm = TRUE)),
    fair_dyad = sum(fair_dyad, na.rm = TRUE),
    unfair_dyad = abs(sum(unfair_dyad, na.rm = TRUE)),
    FairContribute_OUTGOING = sum(faircontribute_OUTGOING, na.rm = TRUE),
    FairContributeB_OUTGOING = sum(faircontributeB_OUTGOING, na.rm = TRUE),
    Transfers_OUTGOING = sum(transfers_OUTGOING, na.rm = TRUE),
    fair_system_OUTGOING = sum(fair_system_OUTGOING, na.rm = TRUE),
    unfair_system_OUTGOING = abs(sum(unfair_system_OUTGOING, na.rm = TRUE)),
    fair_dyad_OUTGOING = sum(fair_dyad_OUTGOING, na.rm = TRUE),
    unfair_dyad_OUTGOING = abs(sum(unfair_dyad_OUTGOING, na.rm = TRUE)),
    FairContribute_INCOMING = sum(faircontribute_INCOMING, na.rm = TRUE),
    FairContributeB_INCOMING = sum(faircontributeB_INCOMING, na.rm = TRUE),
    Transfers_INCOMING = sum(transfers_INCOMING, na.rm = TRUE),
    fair_system_INCOMING = sum(fair_system_INCOMING, na.rm = TRUE),
    unfair_system_INCOMING = abs(sum(unfair_system_INCOMING, na.rm = TRUE)),
    fair_dyad_INCOMING = sum(fair_dyad_INCOMING, na.rm = TRUE),
    unfair_dyad_INCOMING = abs(sum(unfair_dyad_INCOMING, na.rm = TRUE)),
    fair_system_abs = sum(fair_system_abs, na.rm = TRUE),
    unfair_system_abs = abs(sum(unfair_system, na.rm = TRUE)),
    fair_dyad_abs = sum(fair_dyad, na.rm = TRUE),
    unfair_dyad_abs = abs(sum(unfair_dyad, na.rm = TRUE)),
    zerosum = sum(zerosum, na.rm = TRUE),
    zerosum_OUTGOING = sum(zerosum_OUTGOING, na.rm = TRUE),
    zerosum_INCOMING = sum(zerosum_INCOMING, na.rm = TRUE),
    zerosum_fair = fair_dyad-fair_system,
    zerosum_unfair = unfair_dyad_abs-unfair_system_abs,
    zerosum_fair_abs = fair_dyad_abs-fair_system_abs,
    zerosum_unfair_abs = unfair_dyad-unfair_system,
    Requests = sum(requests, na.rm = TRUE),
    fairreq_system = sum(fairreq_system, na.rm = TRUE),
    unfairreq_system = sum(unfairreq_system, na.rm = TRUE),
    Decisions = sum(decisions, na.rm = TRUE),
    fairdec_system = sum(fairdec_system, na.rm = TRUE),
    unfairdec_system = abs(sum(unfairdec_system, na.rm = TRUE)),
    Requests_eurodac = sum(requests_eurodac, na.rm = TRUE),
    fairreq_system_eurodac = sum(fairreq_system_eurodac, na.rm = TRUE),
    unfairreq_system_eurodac = sum(unfairreq_system_eurodac, na.rm = TRUE),
    Decisions_eurodac = sum(decisions_eurodac, na.rm = TRUE),
    fairdec_system_eurodac = sum(fairdec_system_eurodac, na.rm = TRUE),
    unfairdec_system_eurodac = abs(sum(unfairdec_system_eurodac, na.rm = TRUE))
  ) %>%
  mutate(
    transfer_net = Incoming - Outgoing,
    transfer_net_OUTGOING = Incoming_OUTGOING - Outgoing,
    transfer_net_INCOMING = Incoming - Outgoing_INCOMING,
    transfer_rate_distributive = (abs(transfer_net) / (Incoming + Outgoing)) * 100,
    transfer_rate_distributive_OUTGOING = (abs(transfer_net_OUTGOING) / (Incoming_OUTGOING + Outgoing)) * 100,
    transfer_rate_distributive_INCOMING = (abs(transfer_net_INCOMING) / (Incoming + Outgoing_INCOMING)) * 100,
    transfer_net_OUTGOING = Incoming_OUTGOING - Outgoing,
    transfer_net_INCOMING = Incoming - Outgoing_INCOMING,
    fair_contribute_ratio = FairContribute / Transfers,
    fair_contribute_ratio_OUTGOING = FairContribute_OUTGOING / Transfers_OUTGOING,
    fair_contribute_ratio_INCOMING = FairContribute_INCOMING / Transfers_INCOMING,
    fair_contributeB_ratio = FairContributeB / Transfers,
    share_fair_dyad = fair_dyad / Transfers,
    share_unfair_dyad = unfair_dyad / Transfers,
    zerosum_ratio = zerosum / Transfers,
    zero_sum_dyad_OUTGOING = pmax(Transfers_OUTGOING - fair_dyad_OUTGOING - abs(unfair_dyad_OUTGOING), 0),
    zero_sum_dyad_INCOMING = pmax(Transfers_INCOMING - fair_dyad_INCOMING - abs(unfair_dyad_INCOMING), 0),
    zero_sum_system_OUTGOING = pmax(Transfers_OUTGOING - fair_system_OUTGOING - abs(unfair_system_OUTGOING), 0),
    zero_sum_system_INCOMING = pmax(Transfers_INCOMING - fair_system_INCOMING - abs(unfair_system_INCOMING), 0),
    transfer_category = ifelse(transfer_net >= 0, "Net receiver", "Net sender")
  )

## aggregated by PARTNER (partner country of reporting country) for robustness purposes
df_aggregated1 <- dataset %>%
  group_by(PARTNER) %>%
  reframe(
    Incoming = sum(`Incoming Transfers to GEO`, na.rm = TRUE),
    Outgoing = sum(`Outgoing Transfers from GEO`, na.rm = TRUE),
    FairContribute = sum(faircontribute, na.rm = TRUE),
    FairContributeB = sum(faircontributeB, na.rm = TRUE),
    Transfers1 = sum(transfers[suspension == 0], na.rm = TRUE),
    fair_system1 = sum(fair_system[suspension == 0], na.rm = TRUE),
    unfair_system1 = abs(sum(unfair_system[suspension == 0], na.rm = TRUE)),
    fair_dyad1 = sum(fair_dyad[suspension == 0], na.rm = TRUE),
    unfair_dyad1 = abs(sum(unfair_dyad[suspension == 0], na.rm = TRUE)),
    zerosum1 = sum(zerosum[suspension == 0], na.rm = TRUE),
    zerosum_fair1 = sum(fair_dyad[suspension == 0] - fair_system[suspension == 0], na.rm = TRUE),
    zerosum_unfair1 = sum(unfair_dyad[suspension == 0] - unfair_system[suspension == 0], na.rm = TRUE),
    Transfers = sum(transfers, na.rm = TRUE),
    fair_system = sum(fair_system, na.rm = TRUE),
    unfair_system = abs(sum(unfair_system, na.rm = TRUE)),
    fair_dyad = sum(fair_dyad, na.rm = TRUE),
    unfair_dyad = abs(sum(unfair_dyad, na.rm = TRUE)),
    zerosum = sum(zerosum, na.rm = TRUE),
    zerosum_fair = sum(fair_dyad - fair_system, na.rm = TRUE),
    zerosum_unfair = sum(unfair_dyad - unfair_system, na.rm = TRUE),
    zerosum_fair_abs = sum(fair_dyad_abs - fair_system_abs, na.rm = TRUE),
    zerosum_unfair_abs = sum(unfair_dyad_abs - unfair_system_abs, na.rm = TRUE),
    Requests = sum(requests, na.rm = TRUE),
    fairreq_system = sum(fairreq_system, na.rm = TRUE),
    unfairreq_system = sum(unfairreq_system, na.rm = TRUE),
    Decisions = sum(decisions, na.rm = TRUE),
    fairdec_system = sum(fairdec_system, na.rm = TRUE),
    unfairdec_system = abs(sum(unfairdec_system, na.rm = TRUE)),
    Requests_eurodac = sum(requests_eurodac, na.rm = TRUE),
    fairreq_system_eurodac = sum(fairreq_system_eurodac, na.rm = TRUE),
    unfairreq_system_eurodac = sum(unfairreq_system_eurodac, na.rm = TRUE),
    Decisions_eurodac = sum(decisions_eurodac, na.rm = TRUE),
    fairdec_system_eurodac = sum(fairdec_system_eurodac, na.rm = TRUE),
    unfairdec_system_eurodac = abs(sum(unfairdec_system_eurodac, na.rm = TRUE))
  ) %>%
  mutate(
    transfer_net = Incoming - Outgoing,
    transfer_rate_distributive = (abs(transfer_net) / (Incoming + Outgoing)) * 100,
    fair_contribute_ratio = FairContribute / Transfers,
    fair_contributeB_ratio = FairContributeB / Transfers,
    share_fair_dyad = fair_dyad / Transfers,
    share_unfair_dyad = unfair_dyad / Transfers,
    zerosum_ratio = zerosum / Transfers,
    transfer_category = ifelse(transfer_net >= 0, "Net receiver", "Net sender")
  )

## Distribution of key outcome variables

## Compute average fair share fulfilment per country
mean_fair_share_fulfilment <- dataset %>%
  group_by(GEO) %>%
  summarise(
    mean_fair_share_fulfilment = mean(fair_share_fulfilment, na.rm = TRUE),
    mean_fair_share_fulfilment_abs = mean(fair_share_fulfilment_abs, na.rm = TRUE),
    .groups = "drop"
  ) %>%
  mutate(mean_fair_share_fulfilment_shifted = mean_fair_share_fulfilment - 100) %>%
  arrange(desc(mean_fair_share_fulfilment))

# Compute Net Transfers for each country
net_transfers <- dataset %>%
  group_by(GEO) %>%
  summarise(
    total_sent = sum(`Outgoing Transfers from GEO`, na.rm = TRUE),
    total_received = sum(`Incoming Transfers to GEO`, na.rm = TRUE),
    net_transfers = total_sent - total_received
  ) %>%
  arrange(desc(net_transfers))

net_transfers1 <- dataset %>%
  group_by(GEO,YEAR) %>%
  summarise(
    total_sent = sum(`Outgoing Transfers from GEO`, na.rm = TRUE),
    total_received = sum(`Incoming Transfers to GEO`, na.rm = TRUE),
    net_transfers = total_sent - total_received
  ) %>%
  arrange(desc(net_transfers))

# Identify biggest winners (countries sending more than they receive)
winners <- net_transfers %>% top_n(16, net_transfers)

# Identify biggest losers (countries receiving more than they send)
losers <- net_transfers %>% top_n(-16, net_transfers)

# Combine winners & losers for visualization
winners_losers <- bind_rows(winners, losers)

# Figure 1a
fig1a <- ggplot(mean_fair_share_fulfilment, aes(
  x = reorder(GEO, mean_fair_share_fulfilment_shifted),
  y = mean_fair_share_fulfilment_shifted,
  fill = mean_fair_share_fulfilment_shifted > 0  # map positive/negative to a logical
)) +
  geom_col(show.legend = FALSE, width = 0.7) +
  scale_fill_manual(values = c("FALSE" = "gray60", "TRUE" = "gray20")) +  
  coord_flip() +
  scale_y_continuous(
    labels = scales::percent_format(scale = 1),
    expand = expansion(mult = c(0.05, 0.05))
  ) +
  labs(
    title = "A. Fair share fulfilment",
    subtitle = "Deviation from fair share of asylum applications",
    x = NULL,
    y = "Average annual deviation from fair share (%)"
  ) +
  theme_ipsum() +
  theme(
    plot.margin = margin(15, 15, 15, 15),
    panel.grid.major.y = element_line(linetype = "dotted", color = "grey70"),
    panel.grid.major.x = element_line(linetype = "dotted", color = "grey70"),
    axis.text.y = element_text(margin = margin(r = 5)),
    plot.subtitle = element_text(size = 10, color = "grey40", margin = margin(b = 10))
  ) +
  geom_hline(yintercept = 0, color = "grey30", linewidth = 0.5)

# Figure 1b
fig1b <- ggplot(winners_losers, aes(x = reorder(GEO, net_transfers), y = net_transfers / 1000, fill = net_transfers > 0)) +
  geom_col(show.legend = FALSE, width = 0.7) +  
  coord_flip() +
  scale_fill_manual(values = c("gray60", "gray20")) +  
  scale_y_continuous(
    labels = scales::comma, 
    expand = expansion(mult = c(0.05, 0.05)) 
  ) +
  labs(
    title = "B. Net Dublin transfers",
    subtitle = "Outgoing minus incoming transfers",  # add context
    x = NULL,  
    y = "Net transfers (thousands)"
  ) +
  theme_ipsum() +
  theme(
    plot.margin = margin(15, 15, 15, 15),
    panel.grid.major.y = element_line(linetype = "dotted", color = "grey70"),  # keep these!
    panel.grid.major.x = element_line(linetype = "dotted", color = "grey70"),
    axis.text.y = element_text(margin = margin(r = 5)),
    plot.subtitle = element_text(size = 10, color = "grey40", margin = margin(b = 10))
  ) +
  geom_hline(yintercept = 0, color = "grey30", linewidth = 0.5)  # emphasize zero line

jpeg("figure1.jpeg", width = 13, height = 6.5, units = "in", res=800)
ggarrange(fig1a,fig1b)
dev.off()

## Macro-level analysis of fair share fulfilment and Dublin transfers
net_transfers2 <- dataset %>%
  group_by(GEO) %>%
  summarise(
    total_sent = sum(`Outgoing Transfers from GEO`, na.rm = TRUE),
    total_received = sum(`Incoming Transfers to GEO`, na.rm = TRUE),
    net_transfers = total_sent - total_received
  ) %>%
  arrange(desc(net_transfers))

mean_fair_share_fulfilment_abs <- dataset %>%
  group_by(GEO) %>%
  summarise(mean_fair_share_fulfilment_abs = mean(fair_share_fulfilment_abs, na.rm = TRUE)) %>%
  arrange(desc(mean_fair_share_fulfilment))

scatterplot_data <- merge(net_transfers2, mean_fair_share_fulfilment_abs, by = "GEO", all = TRUE)
# Create ISO2 code variable
scatterplot_data$iso2 <- countrycode(scatterplot_data$GEO, origin = "country.name", destination = "iso2c")
scatterplot_data$total <- scatterplot_data$total_sent + scatterplot_data$total_received
scatterplot_data$status <- NA
scatterplot_data$status[scatterplot_data$total_received>scatterplot_data$total_sent] <- "Receiver"
scatterplot_data$status[scatterplot_data$total_received<scatterplot_data$total_sent] <- "Sender"

jpeg("figure2.jpeg", width = 6, height = 6, units = "in", res=800)
ggplot(scatterplot_data, aes(x = mean_fair_share_fulfilment_abs, y = net_transfers)) +
  # 1. Shading quadrants
  annotate("rect", xmin = -Inf, xmax = 0, ymin = -Inf, ymax = 0, fill = "grey85", alpha = 0.5) +
  annotate("rect", xmin = 0, xmax = Inf, ymin = 0, ymax = Inf, fill = "grey85", alpha = 0.5) +
  annotate("rect", xmin = -Inf, xmax = 0, ymin = 0, ymax = Inf, fill = "white", alpha = 0.5) +
  annotate("rect", xmin = 0, xmax = Inf, ymin = -Inf, ymax = 0, fill = "white", alpha = 0.5) +
  # 2. Reference lines 
  geom_vline(xintercept = 0, color = "grey30", linetype = "dashed", linewidth = 0.5) +
  geom_hline(yintercept = 0, color = "grey30", linetype = "dashed", linewidth = 0.5) +
  # 3. Regression line
  geom_smooth(method = "lm", se = TRUE, color = "grey20", linetype = "solid", 
              alpha = 0.15, linewidth = 0.7, fill = "grey50") +
  # 4. Data points
  geom_point(
    aes(color = ifelse((mean_fair_share_fulfilment_abs <= 0 & net_transfers <= 0) | 
                         (mean_fair_share_fulfilment_abs >= 0 & net_transfers >= 0), 
                       "black", "grey50"),
        size = total / 1000),
    alpha = 0.8,
    shape = 16  
  ) +
  # 5. Labels with ggrepel
  geom_text_repel(
    aes(label = iso2,
        color = ifelse((mean_fair_share_fulfilment_abs <= 0 & net_transfers <= 0) | 
                         (mean_fair_share_fulfilment_abs >= 0 & net_transfers >= 0), 
                       "black", "grey50")),
    size = 3,
    max.overlaps = Inf,
    segment.size = 0.2,
    segment.alpha = 0.5,
    fontface = "bold",  
    box.padding = 0.35,  
    point.padding = 0.3
  ) +
  # 6. Quadrant labels
  annotate("text", x = -Inf, y = Inf, label = "Unfair senders", 
           hjust = -0.1, vjust = 1.3, size = 3.5, color = "grey50", 
           fontface = "bold") +
  annotate("text", x = Inf, y = Inf, label = "Fair senders", 
           hjust = 1.1, vjust = 1.3, size = 3.5, color = "black", 
           fontface = "bold") +
  annotate("text", x = -Inf, y = -Inf, label = "Fair receivers", 
           hjust = -0.1, vjust = -0.3, size = 3.5, color = "black", 
           fontface = "bold") +
  annotate("text", x = Inf, y = -Inf, label = "Unfair receivers", 
           hjust = 1.1, vjust = -0.3, size = 3.5, color = "grey50", 
           fontface = "bold") +
  # 7. Scales
  scale_color_identity() +
  scale_size_continuous(
    name = "Total transfers (thousands)", 
    range = c(2, 10),  
    breaks = c(10, 50, 100, 150) 
  ) +
  scale_x_continuous(
    labels = scales::label_number(suffix = " pp") 
  ) +
  scale_y_continuous(
    labels = scales::label_number(scale = 1/1000, suffix = "k")  
  ) +
  # 8. Labels and theme
  labs(
    x = "Deviation from fair share (percentage points)",  
    y = "Net transfers (thousands)"
  ) +
  theme_ipsum() +
  theme(
    legend.position = "top",
    plot.margin = margin(10, 10, 10, 10),  
    plot.title = element_text(face = "bold", size = 14),
    plot.subtitle = element_text(size = 10, color = "grey40", margin = margin(b = 10)),
    plot.caption = element_text(hjust = 0, size = 8, color = "grey40", margin = margin(t = 10)),
    panel.grid.minor = element_blank() 
  )
dev.off()

## Main fairness analysis of Dublin transfers

# Calculate the total transfers and percentages on the system-level
df_transfer_shares_system_fig3 <- data.frame(
  Category = c("Fair", "Neutral", "Unfair"),
  Value = c(sum(df_aggregated$fair_system), 
            sum(df_aggregated$Transfers) - (sum(df_aggregated$fair_system) + abs(sum(df_aggregated$unfair_system))), 
            abs(sum(df_aggregated$unfair_system)))
) %>%
  mutate(Percentage = Value / sum(Value) * 100)  
# and dyad-level
df_transfer_shares_dyad_fig3 <- data.frame(
  Category = c("Fair", "Zero-sum", "Unfair"),
  Value = c(sum(df_aggregated$fair_dyad), 
            sum(df_aggregated$Transfers) - (sum(df_aggregated$fair_dyad) + abs(sum(df_aggregated$unfair_dyad))), 
            abs(sum(df_aggregated$unfair_dyad)))
) %>%
  mutate(Percentage = Value / sum(Value) * 100)  

df_transfer_shares_system_fig3$Category <- factor(df_transfer_shares_system_fig3$Category,
                                      levels = c("Fair", "Neutral", "Unfair"))
df_transfer_shares_dyad_fig3$Category <- factor(df_transfer_shares_dyad_fig3$Category,
                                       levels = c("Fair", "Zero-sum", "Unfair"))

# Create the grouped bar plot with percentages
max_value <- max(df_transfer_shares_system_fig3$Value, df_transfer_shares_dyad_fig3$Value)
max_value <- max_value + 15000

fig3a <- ggplot(df_transfer_shares_system_fig3, aes(x = Category, y = Value, fill = Category)) +
  geom_col(width = 0.65, show.legend = FALSE) +  
  scale_fill_manual(values = c("Fair" = "black", "Zero-sum" = "grey60", "Unfair" = "white")) +
  geom_col(width = 0.65, show.legend = FALSE, color = "black", linewidth = 0.3) +
  scale_y_continuous(
    limits = c(0, max_value * 1.1),  
    labels = scales::label_number(scale = 1/1000, suffix = "k"),  
    expand = expansion(mult = c(0, 0.05))  
  ) +
  scale_x_discrete(
    labels = function(x) str_to_title(x)  
  ) +
  labs(
    title = "A. System-level fairness",
    subtitle = "Distribution of Dublin transfers by fairness category",
    x = NULL,
    y = "Dublin transfers (thousands)"
  ) +
  theme_ipsum() +
  theme(
    plot.margin = margin(15, 15, 15, 15),
    legend.position = "none",
    panel.grid.major.x = element_blank(),
    panel.grid.minor = element_blank(),
    panel.grid.major.y = element_line(linetype = "dotted", color = "grey70"),
    plot.title = element_text(face = "bold", size = 13),
    plot.subtitle = element_text(size = 9, color = "grey40", margin = margin(b = 10)),
    axis.text.x = element_text(size = 11, face = "bold")  
  ) +
  geom_text(
    aes(label = paste0(round(Percentage, 1), "%")), 
    vjust = -0.5, 
    size = 4,
    fontface = "bold"
  )

fig3b <- ggplot(df_transfer_shares_dyad_fig3, aes(x = Category, y = Value, fill = Category)) +
  geom_col(width = 0.65, show.legend = FALSE) +
  scale_fill_manual(values = c("Fair" = "black", "Zero-sum" = "grey60", "Unfair" = "white")) +
  geom_col(width = 0.65, show.legend = FALSE, color = "black", linewidth = 0.3) +
scale_y_continuous(
    limits = c(0, max_value * 1.1),  
    labels = scales::label_number(scale = 1/1000, suffix = "k"),
    expand = expansion(mult = c(0, 0.05))
  ) +
  scale_x_discrete(
    labels = function(x) str_to_title(x)  
  ) +
  labs(
    title = "B. Dyad-level fairness",
    subtitle = "Distribution of Dublin transfers by fairness category",
    x = NULL,
    y = "Dublin transfers (thousands)"
  ) +
  theme_ipsum() +
  theme(
    plot.margin = margin(15, 15, 15, 15),
    legend.position = "none",
    panel.grid.major.x = element_blank(),
    panel.grid.minor = element_blank(),
    panel.grid.major.y = element_line(linetype = "dotted", color = "grey70"),
    plot.title = element_text(face = "bold", size = 13),
    plot.subtitle = element_text(size = 9, color = "grey40", margin = margin(b = 10)),
    axis.text.x = element_text(size = 11, face = "bold")
  ) +
  geom_text(
    aes(label = paste0(round(Percentage, 1), "%")), 
    vjust = -0.5, 
    size = 4,
    fontface = "bold"
  )

jpeg("figure3.jpeg", width = 8, height = 4, units = "in", res=800)
ggarrange(fig3a,fig3b,ncol = 2)
dev.off()

## Values for Table 2: Number of Dublin transfers by fairness category

# Fairness group A
sum(dataset$fair_system) # 
sum(dataset$fair_system_abs)/sum(dataset$transfers)
# Fairness group B
sum(dataset$unfair_system) # 
sum(dataset$unfair_system)/sum(dataset$transfers)
# Fairness group C
sum(dataset$fair_dyad) - sum(dataset$fair_system) # 
(sum(dataset$fair_dyad) - sum(dataset$fair_system))/sum(dataset$transfers)
# Fairness group D
sum(dataset$unfair_dyad) + sum(dataset$unfair_system) # 
(sum(dataset$unfair_dyad) + sum(dataset$unfair_system))/sum(dataset$transfers)
# Fairness group E
sum(dataset$zerosum)
sum(dataset$zerosum)/sum(dataset$transfers)

## Marginal distributions
# Total fair dyadic
sum(dataset$fair_dyad)
sum(dataset$fair_dyad)/sum(dataset$transfers)
# Total unfair dyadic
sum(dataset$unfair_dyad)
sum(dataset$unfair_dyad)/sum(dataset$transfers)
# Total neutral system-level
(sum(dataset$fair_dyad) - sum(dataset$fair_system)) + sum(dataset$unfair_dyad) + sum(dataset$unfair_system) + sum(dataset$zerosum)
((sum(dataset$fair_dyad) - sum(dataset$fair_system)) + sum(dataset$unfair_dyad) + sum(dataset$unfair_system) + sum(dataset$zerosum))/sum(dataset$transfers)


## Fairness analysis over time

# Aggregate data by YEAR
df_aggregated_year <- dataset %>%
  group_by(YEAR) %>%
  summarise(
    Incoming = sum(`Incoming Transfers to GEO`, na.rm = TRUE),
    Outgoing = sum(`Outgoing Transfers from GEO`, na.rm = TRUE),
    FairContribute = sum(faircontribute, na.rm = TRUE),
    Transfers = sum(transfers, na.rm = TRUE),
    fair_system = sum(fair_system, na.rm = TRUE),
    unfair_system = sum(unfair_system, na.rm = TRUE),
    fair_dyad = sum(fair_dyad, na.rm = TRUE),
    unfair_dyad = sum(unfair_dyad, na.rm = TRUE),
    fair_system_abs = sum(fair_system_abs, na.rm = TRUE),
    unfair_system_abs = sum(unfair_system_abs, na.rm = TRUE),
    fair_dyad_abs = sum(fair_dyad_abs, na.rm = TRUE),
    unfair_dyad_abs = sum(unfair_dyad_abs, na.rm = TRUE)
  ) %>%
  mutate(
    transfer_net = Incoming - Outgoing,
    transfer_rate_distributive = (abs(transfer_net) / (Incoming + Outgoing)) * 100,
    fair_contribute_ratio = FairContribute / Transfers,
    fair_contribute_ratio1 = fair_system / Transfers,
    fair_contribute_ratio2 = unfair_system / Transfers,
    share_fair_dyad = fair_dyad / Transfers,
    share_unfair_dyad = unfair_dyad / Transfers,
    fair_contribute_ratio1_abs = fair_system_abs / Transfers,
    fair_contribute_ratio2_abs = unfair_system_abs / Transfers,
    share_fair_dyad_abs = fair_dyad_abs / Transfers,
    share_unfair_dyad_abs = unfair_dyad_abs / Transfers,
    transfer_category = ifelse(transfer_net >= 0, "Net receiver", "Net sender")
  )

# Prepare the data for the line plot
df_line_plot <- df_aggregated_year %>%
  select(YEAR, fair_contribute_ratio1, fair_contribute_ratio2) %>%
  mutate(
    fair_contribute_ratio1 = fair_contribute_ratio1 * 100,
    fair_contribute_ratio2 = abs(fair_contribute_ratio2) * 100,  #
    remaining_ratio = 100 - (fair_contribute_ratio1 + fair_contribute_ratio2)  
  ) %>%
  pivot_longer(cols = c(fair_contribute_ratio1, fair_contribute_ratio2, remaining_ratio), 
               names_to = "ContributionType", 
               values_to = "Value") %>%
  mutate(ContributionType = recode(ContributionType, 
                                   fair_contribute_ratio1 = "Fair", 
                                   fair_contribute_ratio2 = "Unfair",
                                   remaining_ratio = "Neutral/Zero-sum"))

fig4a <- ggplot(df_line_plot, aes(x = YEAR, y = Value, color = ContributionType, 
                                  shape = ContributionType, linewidth = ContributionType,
                                  group = ContributionType)) +
  geom_line() +
  geom_point(aes(size = ContributionType)) +
  scale_color_manual(
    values = c("Fair" = "black", "Unfair" = "grey50", "Neutral/Zero-sum" = "grey80"),
    breaks = c("Fair", "Neutral/Zero-sum", "Unfair")
  ) +
  scale_shape_manual(
    values = c("Fair" = 16, "Unfair" = 16, "Neutral/Zero-sum" = 16),
    breaks = c("Fair", "Neutral/Zero-sum", "Unfair")
  ) +
  scale_linewidth_manual(
    values = c("Fair" = 1.4, "Unfair" = 1.4, "Neutral/Zero-sum" = 0.8),
    breaks = c("Fair", "Neutral/Zero-sum", "Unfair")
  ) +
  scale_size_manual(
    values = c("Fair" = 3.5, "Unfair" = 3.5, "Neutral/Zero-sum" = 2),
    breaks = c("Fair", "Neutral/Zero-sum", "Unfair")
  ) +
  scale_x_continuous(
    breaks = seq(min(df_line_plot$YEAR), max(df_line_plot$YEAR), by = 2)
  ) +
  scale_y_continuous(
    limits = c(0, 75), 
    breaks = seq(0, 75, by = 15),
    labels = scales::label_number(suffix = "%"),
    expand = expansion(mult = c(0, 0.02))
  ) +
  labs(
    title = "A. System-level fairness",
    subtitle = "Temporal evolution of transfer fairness shares",
    x = NULL,
    y = "Share of transfers (%)",
    color = NULL,
    shape = NULL,
    linewidth = NULL,
    size = NULL
  ) + 
  theme_ipsum() +
  theme(
    plot.margin = margin(10, 10, 10, 10),
    panel.grid.major.x = element_line(linetype = "dotted", color = "grey70"),
    panel.grid.major.y = element_line(linetype = "dotted", color = "grey70"),
    panel.grid.minor = element_blank(),
    plot.title = element_text(face = "bold", size = 13),
    plot.subtitle = element_text(size = 9, color = "grey40", margin = margin(b = 10))
  ) +
  guides(
    color = guide_legend(override.aes = list(linewidth = 2, size = 3.5), nrow = 1),
    shape = "none",
    linewidth = "none",
    size = "none"
  )

df_line_plot <- df_aggregated_year %>%
  select(YEAR, share_fair_dyad, share_unfair_dyad) %>%
  mutate(
    fair_contribute_ratio1 = share_fair_dyad * 100,
    fair_contribute_ratio2 = abs(share_unfair_dyad) * 100,
    remaining_ratio = 100 - (fair_contribute_ratio1 + fair_contribute_ratio2)  
  ) %>%
  pivot_longer(cols = c(fair_contribute_ratio1, fair_contribute_ratio2, remaining_ratio), 
               names_to = "ContributionType", 
               values_to = "Value") %>%
  mutate(ContributionType = recode(ContributionType, 
                                   fair_contribute_ratio1 = "Fair", 
                                   fair_contribute_ratio2 = "Unfair",
                                   remaining_ratio = "Neutral/Zero-sum"))

fig4b <- ggplot(df_line_plot, aes(x = YEAR, y = Value, color = ContributionType, 
                                  shape = ContributionType, linewidth = ContributionType,
                                  group = ContributionType)) +
  geom_line() +
  geom_point(aes(size = ContributionType)) +
  scale_color_manual(
    values = c("Fair" = "black", "Unfair" = "grey50", "Neutral/Zero-sum" = "grey80"),
    breaks = c("Fair", "Neutral/Zero-sum", "Unfair")
  ) +
  scale_shape_manual(
    values = c("Fair" = 16, "Unfair" = 16, "Neutral/Zero-sum" = 16),
    breaks = c("Fair", "Neutral/Zero-sum", "Unfair")
  ) +
  scale_linewidth_manual(
    values = c("Fair" = 1.4, "Unfair" = 1.4, "Neutral/Zero-sum" = 0.8),
    breaks = c("Fair", "Neutral/Zero-sum", "Unfair")
  ) +
  scale_size_manual(
    values = c("Fair" = 3.5, "Unfair" = 3.5, "Neutral/Zero-sum" = 2),
    breaks = c("Fair", "Neutral/Zero-sum", "Unfair")
  ) +
  scale_x_continuous(
    breaks = seq(min(df_line_plot$YEAR), max(df_line_plot$YEAR), by = 2)
  ) +
  scale_y_continuous(
    limits = c(0, 75), 
    breaks = seq(0, 75, by = 15),
    labels = scales::label_number(suffix = "%"),
    expand = expansion(mult = c(0, 0.02))
  ) +
  labs(
    title = "B. Dyad-level fairness",
    subtitle = "Temporal evolution of transfer fairness shares",
    x = NULL,
    y = "Share of transfers (%)",
    color = NULL,
    shape = NULL,
    linewidth = NULL,
    size = NULL
  ) + 
  theme_ipsum() +
  theme(
    plot.margin = margin(10, 10, 10, 10),
    panel.grid.major.x = element_line(linetype = "dotted", color = "grey70"),
    panel.grid.major.y = element_line(linetype = "dotted", color = "grey70"),
    panel.grid.minor = element_blank(),
    plot.title = element_text(face = "bold", size = 13),
    plot.subtitle = element_text(size = 9, color = "grey40", margin = margin(b = 10))
  ) +
  guides(
    color = guide_legend(override.aes = list(linewidth = 2, size = 3.5), nrow = 1),
    shape = "none",
    linewidth = "none",
    size = "none"
  )

# Combine with patchwork 
combined_plot <- fig4a + fig4b + 
  plot_layout(ncol = 2, guides = "collect") & 
  theme(
    legend.position = "bottom",
    legend.justification = "center",
    legend.text = element_text(size = 11)
  )

jpeg("figure4.jpeg", width = 10, height = 5, units = "in", res=800)
combined_plot 
dev.off()

## Fairness contribution by country 

# Load the countries shapefile data
countries <- ne_countries(scale = "medium", returnclass = "sf")

# Convert country names to title case
df_aggregated$GEO <- str_to_title(df_aggregated$GEO)

# Remove any leading/trailing spaces
df_aggregated$GEO <- trimws(df_aggregated$GEO)

# Merge the spatial data with your dataset based on country names
df_aggregated_sf <- countries %>%
  left_join(df_aggregated, by = c("name" = "GEO"))

# Get a base world map
world_map <- ne_countries(scale = "medium", returnclass = "sf")

# Compute empirical min/max
min_val <- min(c(df_aggregated_sf$fair_contribute_ratio, df_aggregated_sf$fair_contributeB_ratio), na.rm = TRUE)
max_val <- max(c(df_aggregated_sf$fair_contribute_ratio, df_aggregated_sf$fair_contributeB_ratio), na.rm = TRUE)

figA8a <- ggplot(data = df_aggregated_sf) +
  geom_sf(aes(fill = fair_contribute_ratio), color = "white", linewidth = 0.1) +  
  geom_sf(data = world_map, fill = NA, color = "gray70", linewidth = 0.3) +
  scale_fill_gradient2(
    low = "#FFCC00", 
    mid = "white", 
    high = "#003399", 
    midpoint = 0,
    limits = c(min_val, max_val),
    breaks = seq(-1, 1, by = 0.5), 
    labels = function(x) paste0(round(x * 100, 0), "%"),  
    name = NULL,  
    na.value = "grey90" 
  ) +
  labs(
    title = "A. System-level fairness",
    subtitle = "Fair contribution ratio (%)"  
  ) +
  theme_void() +  
  theme(
    plot.title = element_text(face = "bold", size = 13, hjust = 0, margin = margin(b = 5)),
    plot.subtitle = element_text(size = 10, color = "grey40", hjust = 0, margin = margin(b = 10)),
    plot.margin = margin(10, 10, 10, 10),
    legend.position = "top",
    legend.justification = "center",
    legend.key.width = unit(2.5, "cm"),  
    legend.key.height = unit(0.4, "cm"),
    legend.text = element_text(size = 9),
    legend.title = element_text(size = 10, face = "bold"),
    legend.margin = margin(b = 10)
  ) +
  guides(fill = guide_colorbar(
    title.position = "top",
    title.hjust = 0.5,
    barwidth = 15,  
    barheight = 0.5,
    frame.colour = "grey50",  
    ticks.colour = "grey50"
  )) +
  coord_sf(xlim = c(-22, 32), ylim = c(36, 69.5), expand = FALSE)  

figA8b <- ggplot(data = df_aggregated_sf) +
  geom_sf(aes(fill = fair_contributeB_ratio), color = "white", linewidth = 0.1) +
  geom_sf(data = world_map, fill = NA, color = "gray70", linewidth = 0.3) +
  scale_fill_gradient2(
    low = "#FFCC00", 
    mid = "white", 
    high = "#003399",
    midpoint = 0,
    limits = c(min_val, max_val),
    breaks = seq(-1, 1, by = 0.5),
    labels = function(x) paste0(round(x * 100, 0), "%"),
    name = NULL,
    na.value = "grey90"
  ) +
  labs(
    title = "B. Dyad-level fairness",
    subtitle = "Fair contribution ratio (%)"
  ) +
  theme_void() +
  theme(
    plot.title = element_text(face = "bold", size = 13, hjust = 0, margin = margin(b = 5)),
    plot.subtitle = element_text(size = 10, color = "grey40", hjust = 0, margin = margin(b = 10)),
    plot.margin = margin(10, 10, 10, 10),
    legend.position = "top",
    legend.justification = "center",
    legend.key.width = unit(2.5, "cm"),
    legend.key.height = unit(0.4, "cm"),
    legend.text = element_text(size = 9),
    legend.title = element_text(size = 10, face = "bold"),
    legend.margin = margin(b = 10)
  ) +
  guides(fill = guide_colorbar(
    title.position = "top",
    title.hjust = 0.5,
    barwidth = 15,
    barheight = 0.5,
    frame.colour = "grey50",
    ticks.colour = "grey50"
  )) +
  coord_sf(xlim = c(-22, 32), ylim = c(36, 69.5), expand = FALSE)

jpeg("figureA8.jpeg", width = 11, height = 6.7, units = "in", res=800)
grid.arrange(figA8a, figA8b, ncol = 2)
dev.off()

fig5a <- df_aggregated_sf %>%
  filter(!is.na(fair_contribute_ratio)) %>%
  ggplot(aes(x = reorder(name, fair_contribute_ratio), 
             y = fair_contribute_ratio * 100, 
             fill = fair_contribute_ratio > 0)) +
  geom_col(show.legend = FALSE, width = 0.7, color = "black", linewidth = 0.3) +
  coord_flip() +
  scale_fill_manual(values = c("white", "black")) +
  scale_y_continuous(
    labels = scales::label_number(suffix = "%"),
    expand = expansion(mult = c(0.05, 0.05))
  ) +
  labs(
    title = "A. System-level fairness",
    subtitle = "Fair contribution ratio (%)",
    x = NULL,
    y = "Fair contribution ratio (%)"
  ) +
  theme_ipsum() +
  theme(
    plot.margin = margin(15, 15, 15, 15),
    panel.grid.major.y = element_line(linetype = "dotted", color = "grey70"),
    panel.grid.major.x = element_line(linetype = "dotted", color = "grey70"),
    axis.text.y = element_text(margin = margin(r = 5)),
    plot.title = element_text(face = "bold", size = 13),
    plot.subtitle = element_text(size = 10, color = "grey40", margin = margin(b = 10))
  ) +
  geom_hline(yintercept = 0, color = "grey30", linewidth = 0.5)

fig5b <- df_aggregated_sf %>%
  filter(!is.na(fair_contributeB_ratio)) %>%
  ggplot(aes(x = reorder(name, fair_contributeB_ratio), 
             y = fair_contributeB_ratio * 100, 
             fill = fair_contributeB_ratio > 0)) +
  geom_col(show.legend = FALSE, width = 0.7, color = "black", linewidth = 0.3) +
  coord_flip() +
  scale_fill_manual(values = c("white", "black")) +
  scale_y_continuous(
    labels = scales::label_number(suffix = "%"),
    expand = expansion(mult = c(0.05, 0.05))
  ) +
  labs(
    title = "B. Dyad-level fairness",
    subtitle = "Fair contribution ratio (%)",
    x = NULL,
    y = "Fair contribution ratio (%)"
  ) +
  theme_ipsum() +
  theme(
    plot.margin = margin(15, 15, 15, 15),
    panel.grid.major.y = element_line(linetype = "dotted", color = "grey70"),
    panel.grid.major.x = element_line(linetype = "dotted", color = "grey70"),
    axis.text.y = element_text(margin = margin(r = 5)),
    plot.title = element_text(face = "bold", size = 13),
    plot.subtitle = element_text(size = 10, color = "grey40", margin = margin(b = 10))
  ) +
  geom_hline(yintercept = 0, color = "grey30", linewidth = 0.5)

jpeg("figure5.jpeg", width = 11, height = 6.7, units = "in", res=800)
ggarrange(fig5a, fig5b, ncol = 2, nrow = 1)
dev.off()

## Assessing exaplantion of structural non-compliance

# identify the dyads with the most transfers
dyads_by_transfers <- aggregate(transfers ~ GEO + PARTNER, data = dataset, FUN = sum, na.rm = TRUE)

# Step 1: Create an undirected dyad identifier (sorted combination of GEO and PARTNER)
dyads_by_transfers$dyad_id <- apply(dyads_by_transfers[, c("GEO", "PARTNER")], 1, function(x) paste(sort(x), collapse = "_"))

# Step 2: Keep only the row with the highest number of transfers per dyad
dyads_max <- dyads_by_transfers %>%
  group_by(dyad_id) %>%
  slice_max(order_by = transfers, n = 1, with_ties = FALSE) %>%
  ungroup()

# Prepare top 15 dyads
top15_dyads <- dyads_max %>%
  mutate(dyad_display = paste0(pmin(GEO, PARTNER), " -- ", pmax(GEO, PARTNER))) %>%
  group_by(dyad_display) %>%
  summarise(transfers = sum(transfers), .groups = "drop") %>%
  arrange(desc(transfers)) %>%
  slice_head(n = 15)

# Rename columns
colnames(top15_dyads) <- c("Dyad", "Total transfers")

# Table A2
xtable(top15_dyads,
       caption = "Top 15 Dublin transfer dyads by total number of transfers",
       label = "tab:top15_dyads",
       align = c("l", "l", "r"),
       digits = 0)

top15_dyads <- dyads_max %>%
  mutate(dyad_display = paste0(pmin(GEO, PARTNER), " / ", pmax(GEO, PARTNER))) %>%  
  group_by(dyad_display) %>%
  summarise(transfers = sum(transfers), .groups = "drop") %>%
  arrange(desc(transfers)) %>%
  slice_head(n = 15)

jpeg("figure6.jpeg", width = 8, height = 5, units = "in", res = 800)
ggplot(top15_dyads, aes(x = reorder(dyad_display, transfers), y = transfers / 1000)) +
  geom_col(fill = "gray40", width = 0.7, alpha = 0.9) +
  coord_flip() +
  scale_y_continuous(
    labels = scales::label_number(suffix = "k"),
    expand = expansion(mult = c(0, 0.15)) 
  ) +
  labs(
    subtitle = "Total Dublin transfers between country pairs",
    x = NULL,
    y = "Total transfers (thousands)"
  ) +
  theme_ipsum(base_size = 12) +
  theme(
    plot.margin = margin(15, 20, 15, 15),  
    panel.grid.major.x = element_line(linetype = "dotted", color = "grey70"),
    panel.grid.major.y = element_blank(),
    panel.grid.minor = element_blank(),
    axis.text.y = element_text(margin = margin(r = 5), size = 10),
    axis.text.x = element_text(size = 10),
    plot.title = element_text(face = "bold", size = 14, margin = margin(b = 5)),
    plot.subtitle = element_text(size = 11, color = "grey20", margin = margin(b = 10))
  ) +
  geom_text(
    aes(label = scales::comma(transfers)),
    hjust = -0.1,
    size = 3,
    color = "grey20"
  )
dev.off()

#### Additional analyses (supplementary material)

# Plot
jpeg("figureA1.jpeg", width = 6.5, height = 6.5, units = "in", res=800)
ggplot(winners_losers, aes(x = reorder(GEO, net_transfers), y = net_transfers / 1000, fill = net_transfers > 0)) +
  geom_col(show.legend = FALSE, width = 0.7) +  
  coord_flip() +
  scale_fill_manual(values = c("#FFCC00", "#003399")) +  
  scale_y_continuous(
    labels = scales::comma, 
    expand = expansion(mult = c(0.05, 0.05))  
  ) +
  labs(
    subtitle = "Outgoing minus incoming transfers",  
    x = NULL,  
    y = "Net transfers (thousands)",  
    caption = "Blue indicates net receivers, yellow indicates net contributors" 
  ) +
  theme_ipsum() +
  theme(
    plot.margin = margin(15, 15, 15, 15),
    panel.grid.major.y = element_line(linetype = "dotted", color = "grey70"),  
    panel.grid.major.x = element_line(linetype = "dotted", color = "grey70"),
    axis.text.y = element_text(margin = margin(r = 5)),
    plot.subtitle = element_text(size = 10, color = "grey40", margin = margin(b = 10))
  ) +
  geom_hline(yintercept = 0, color = "grey30", linewidth = 0.5) 
dev.off()

## Robustness check: Alternative aggregation based on PARTNER

# Compute Net Transfers for each country
net_transfers <- dataset %>%
  group_by(PARTNER) %>%
  summarise(
    total_sent = sum(`Outgoing Transfers from GEO`, na.rm = TRUE),
    total_received = sum(`Incoming Transfers to GEO`, na.rm = TRUE),
    net_transfers = (total_sent - total_received)*-1  
  ) %>%
  arrange(desc(net_transfers))

# Pyramid plot for system-level
df_pyramid_sorted <- df_aggregated %>%
  mutate(sort_ratio = fair_system / unfair_system) %>%
  arrange(sort_ratio) %>%
  mutate(GEO = factor(GEO, levels = GEO)) %>%
  select(GEO, fair_system, unfair_system)

df_pyramid_long <- df_pyramid_sorted %>%
  mutate(unfair_system = -unfair_system) %>%
  pivot_longer(cols = c(fair_system, unfair_system), names_to = "ContributionType", values_to = "Value")

figA2a <- ggplot(df_pyramid_long, aes(x = GEO, y = Value / 1000, fill = ContributionType)) +
  geom_col(width = 0.7, alpha = 0.9) +
  coord_flip() +
  scale_fill_manual(
    values = c("fair_system" = "#003399", "unfair_system" = "#FFCC00"),
    labels = c("fair_system" = "Fair", "unfair_system" = "Unfair"),
    breaks = c("unfair_system", "fair_system"),  # 
    name = NULL
  ) +
  scale_y_continuous(
    breaks = c(-20,-10, 0, 10,20),
    labels = function(x) paste0(abs(x), "k"),
    expand = expansion(mult = c(0.02, 0.02))
  ) +
  labs(
    title = "A. System-level fairness",
    subtitle = "Fair vs. unfair transfers by country",
    x = NULL,
    y = "Transfers (thousands)"
  ) +
  theme_ipsum() +
  theme(
    plot.margin = margin(10, 10, 10, 10),
    panel.grid.major.y = element_line(linetype = "dotted", color = "grey70"),
    panel.grid.major.x = element_line(linetype = "dotted", color = "grey70"),
    panel.grid.minor = element_blank(),
    axis.text.y = element_text(margin = margin(r = 5), size = 10),
    plot.title = element_text(face = "bold", size = 13),
    plot.subtitle = element_text(size = 10, color = "grey40", margin = margin(b = 10)),
    legend.position = "none"
  ) +
  geom_vline(xintercept = 0, color = "grey30", linewidth = 0.5)

# Pyramid plot for dyadic fairness
df_pyramid_sorted <- df_aggregated %>%
  mutate(sort_ratio = fair_dyad / unfair_dyad) %>%
  arrange(sort_ratio) %>%
  mutate(GEO = factor(GEO, levels = GEO)) %>%
  select(GEO, fair_dyad, unfair_dyad)

df_pyramid_long <- df_pyramid_sorted %>%
  mutate(unfair_dyad = -unfair_dyad) %>%
  pivot_longer(cols = c(fair_dyad, unfair_dyad), names_to = "ContributionType", values_to = "Value")

figA2b <- ggplot(df_pyramid_long, aes(x = GEO, y = Value / 1000, fill = ContributionType)) +
  geom_col(width = 0.7, alpha = 0.9) +
  coord_flip() +
  scale_fill_manual(
    values = c("fair_dyad" = "#003399", "unfair_dyad" = "#FFCC00"),
    labels = c("fair_dyad" = "Fair", "unfair_dyad" = "Unfair"),
    breaks = c("unfair_dyad", "fair_dyad"),  
    name = NULL
  ) +
  scale_y_continuous(
    breaks = c(-30,-20, -10, 0, 10, 20,30,40),
    labels = function(x) paste0(abs(x), "k"),
    expand = expansion(mult = c(0.02, 0.02))
  ) +
  labs(
    title = "B. Dyad-level fairness",
    subtitle = "Fair vs. unfair transfers by country",
    x = NULL,
    y = "Transfers (thousands)"
  ) +
  theme_ipsum() +
  theme(
    plot.margin = margin(10, 10, 10, 10),
    panel.grid.major.y = element_line(linetype = "dotted", color = "grey70"),
    panel.grid.major.x = element_line(linetype = "dotted", color = "grey70"),
    panel.grid.minor = element_blank(),
    axis.text.y = element_text(margin = margin(r = 5), size = 10),
    plot.title = element_text(face = "bold", size = 13),
    plot.subtitle = element_text(size = 10, color = "grey40", margin = margin(b = 10)),
    legend.position = "none"
  ) +
  geom_vline(xintercept = 0, color = "grey30", linewidth = 0.5)

# Combine plots with centered legend using patchwork
combined_plot <- figA2a + figA2b + 
  plot_layout(ncol = 2, guides = "collect") & 
  theme(
    legend.position = "bottom",
    legend.justification = "center",
    legend.direction = "horizontal",
    legend.text = element_text(size = 11),
    legend.box.spacing = unit(0.5, "cm")
  ) &
  guides(fill = guide_legend(
    override.aes = list(size = 4),
    nrow = 1
  ))

jpeg("figureA2.jpeg", width = 10, height = 6.1, units = "in", res=800)
combined_plot
dev.off()

# Plot fair share fulfilment by country over time
# Step 1: Calculate country order by mean fair share fulfilment
country_order <- dataset %>%
  group_by(GEO) %>%
  summarise(mean_fsf = mean(fair_share_fulfilment, na.rm = TRUE)) %>%
  arrange(desc(mean_fsf)) %>%
  pull(GEO)

# Step 2: Collapse to GEO-year level and apply ordering
fair_share_by_country <- dataset %>%
  select(GEO, YEAR, fair_share_fulfilment) %>%
  distinct() %>%
  rename(country = GEO, year = YEAR) %>%
  mutate(country = factor(country, levels = country_order))

# Step 3: Create segmented data with next year values
fair_share_fulfilment_segmented <- fair_share_by_country %>%
  arrange(country, year) %>%
  group_by(country) %>%
  mutate(
    year_next = lead(year),
    fsf_next = lead(fair_share_fulfilment)
  ) %>%
  filter(!is.na(year_next)) %>%
  ungroup()

# Step 4: Create polygon data
df <- fair_share_fulfilment_segmented
baseline <- 100

polys <- df %>%
  mutate(
    row_id = row_number(),
    x1 = year, x2 = year_next,
    y1 = fair_share_fulfilment, y2 = fsf_next
  ) %>%
  rowwise() %>%
  mutate(pieces = list({
    x1 <- x1; x2 <- x2; y1 <- y1; y2 <- y2
    if (is.na(y1) | is.na(y2)) return(NULL)
    if (y1 == baseline && y2 == baseline) return(NULL)
    
    # Case 1: both above
    if (y1 >= baseline && y2 >= baseline) {
      tibble(
        x = c(x1, x2, x2, x1),
        y = c(y1, y2, baseline, baseline),
        piece = "whole",
        side = "Above fair share"
      )
    }
    # Case 2: both below
    else if (y1 <= baseline && y2 <= baseline) {
      tibble(
        x = c(x1, x2, x2, x1),
        y = c(y1, y2, baseline, baseline),
        piece = "whole",
        side = "Below fair share"
      )
    }
    # Case 3: crossing
    else {
      t <- (baseline - y1) / (y2 - y1)
      xi <- x1 + t * (x2 - x1)
      yi <- baseline
      
      if (y1 > baseline) {
        piece1 <- tibble(
          x = c(x1, xi, xi, x1),
          y = c(y1, yi, baseline, baseline),
          piece = "part1",
          side = "Above fair share"
        )
        piece2 <- tibble(
          x = c(xi, x2, x2, xi),
          y = c(yi, y2, baseline, baseline),
          piece = "part2",
          side = "Below fair share"
        )
      } else {
        piece1 <- tibble(
          x = c(x1, xi, xi, x1),
          y = c(y1, yi, baseline, baseline),
          piece = "part1",
          side = "Below fair share"
        )
        piece2 <- tibble(
          x = c(xi, x2, x2, xi),
          y = c(yi, y2, baseline, baseline),
          piece = "part2",
          side = "Above fair share"
        )
      }
      bind_rows(piece1, piece2)
    }
  })) %>%
  ungroup() %>%
  filter(map_lgl(pieces, ~ !is.null(.x))) %>%
  unnest(pieces) %>%
  mutate(poly_id = paste(country, row_id, piece, sep = "_"))

# Step 5: Create line segments that split at crossings
line_segments <- df %>%
  mutate(row_id = row_number()) %>%
  rowwise() %>%
  mutate(segments = list({
    x1 <- year; x2 <- year_next
    y1 <- fair_share_fulfilment; y2 <- fsf_next
    
    if (is.na(y1) | is.na(y2)) return(NULL)
    
    # Case 1: both above or at baseline
    if (y1 >= baseline && y2 >= baseline) {
      tibble(
        x = x1, xend = x2,
        y = y1, yend = y2,
        color = "Above fair share"
      )
    }
    # Case 2: both below baseline
    else if (y1 <= baseline && y2 <= baseline) {
      tibble(
        x = x1, xend = x2,
        y = y1, yend = y2,
        color = "Below fair share"
      )
    }
    # Case 3: crossing - split into two segments
    else {
      t <- (baseline - y1) / (y2 - y1)
      xi <- x1 + t * (x2 - x1)
      yi <- baseline
      
      if (y1 > baseline) {
        tibble(
          x = c(x1, xi),
          xend = c(xi, x2),
          y = c(y1, yi),
          yend = c(yi, y2),
          color = c("Above fair share", "Below fair share")
        )
      } else {
        tibble(
          x = c(x1, xi),
          xend = c(xi, x2),
          y = c(y1, yi),
          yend = c(yi, y2),
          color = c("Below fair share", "Above fair share")
        )
      }
    }
  })) %>%
  ungroup() %>%
  filter(map_lgl(segments, ~ !is.null(.x))) %>%
  unnest(segments)

# Step 6: Plot
jpeg("figureA3.jpeg", width = 13, height = 7, units = "in", res = 800)
ggplot() +
  geom_polygon(
    data = polys,
    aes(x = x, y = y, group = poly_id, fill = side),
    alpha = 0.2  
  ) +
  geom_segment(
    data = line_segments,
    aes(
      x = x, xend = xend,
      y = y, yend = yend,
      color = color
    ),
    linewidth = 0.8  
  ) +
  geom_hline(yintercept = baseline, color = "grey30", linetype = "dashed", linewidth = 0.4) +
  scale_color_manual(
    values = c("Above fair share" = "#003399", "Below fair share" = "#FFCC00"),
    name = NULL
  ) +
  scale_fill_manual(
    values = c("Above fair share" = "#003399", "Below fair share" = "#FFCC00"),
    name = NULL,
    guide = "none"  
  ) +
  scale_x_continuous(
    breaks = function(x) seq(ceiling(min(x)), floor(max(x)), by = 2)  
  ) +
  scale_y_continuous(
    labels = scales::label_number(suffix = "%")  
  ) +
  facet_wrap(~ country, scales = "free_y", ncol = 8) +
  labs(
    x = NULL,  
    y = "fair share fulfillment (%)"  
  ) +
  theme_ipsum(base_size = 10) +  
  theme(
    plot.margin = margin(5, 5, 5, 5),  
    plot.title = element_text(face = "bold", size = 12, margin = margin(b = 10)),
    legend.position = "top",
    legend.justification = "center",
    legend.text = element_text(size = 9),
    legend.margin = margin(b = 5),  
    strip.text = element_text(size = 7.5, face = "bold"),  
    strip.background = element_rect(fill = "grey95", color = NA),  
    axis.text.x = element_text(angle = 45, hjust = 1, size = 7),
    axis.text.y = element_text(size = 7),
    axis.title.y = element_text(size = 9, margin = margin(r = 5)),
    panel.spacing = unit(0.3, "lines"), 
    panel.grid.minor = element_blank(),  
    panel.grid.major = element_line(linewidth = 0.3)  
  )
dev.off()

## Additional visualisation: System-level fairness outcomes over time by member state 

# Prepare the data for the line plot
df_line_plot <- dataset %>%
  group_by(GEO, YEAR) %>%
  summarise(
    Incoming = sum(`Incoming Transfers to GEO`, na.rm = TRUE),
    Outgoing = sum(`Outgoing Transfers from GEO`, na.rm = TRUE),
    Transfers = sum(transfers, na.rm = TRUE),
    FairContribute1 = sum(fair_system, na.rm = TRUE),
    FairContribute2 = sum(unfair_system, na.rm = TRUE)
  ) %>%
  mutate(
    transfer_net = Incoming - Outgoing,
    transfer_rate_distributive = (abs(transfer_net) / (Incoming + Outgoing)) * 100,
    fair_contribute_ratio1 = (FairContribute1 / Transfers) * 100,
    fair_contribute_ratio2 = (abs(FairContribute2) / Transfers) * 100,
    remaining_ratio = 100 - (fair_contribute_ratio1 + fair_contribute_ratio2)  
  ) %>%
  pivot_longer(cols = c(fair_contribute_ratio1, fair_contribute_ratio2, remaining_ratio), 
               names_to = "ContributionType", 
               values_to = "Value") %>%
  mutate(ContributionType = recode(ContributionType, 
                                   fair_contribute_ratio1 = "Fair", 
                                   fair_contribute_ratio2 = "Unfair",
                                   remaining_ratio = "Neutral"))

# Line plot with facets for each country
jpeg("figureA4.jpeg", width = 13, height = 7, units = "in", res=800)
ggplot(df_line_plot, aes(x = YEAR, y = Value, color = ContributionType, group = ContributionType)) +
  geom_line(linewidth = 1, alpha = 0.8) +  
  geom_point(size = 1.5, alpha = 0.9) +  
  scale_color_manual(
    values = c("Fair" = "#003399", "Unfair" = "#FFCC00", "Neutral" = "grey60"),
    breaks = c("Unfair", "Neutral", "Fair"),  
    name = NULL
  ) +
  scale_x_continuous(
    breaks = function(x) seq(ceiling(min(x)), floor(max(x)), by = 2)  
  ) +
  scale_y_continuous(
    limits = c(0, 100),
    labels = scales::label_number(suffix = "%"),
    expand = expansion(mult = c(0, 0.02))  
  ) +
  labs(
    x = NULL,  
    y = "Share of transfers (%)"  
  ) +
  facet_wrap(~ GEO, scales = "free_y", ncol = 8) +
  theme_ipsum(base_size = 10) +  
  theme(
    plot.margin = margin(5, 5, 5, 5),
    plot.title = element_text(face = "bold", size = 12, margin = margin(b = 10)),
    legend.position = "top",
    legend.justification = "center",
    legend.text = element_text(size = 9),
    legend.margin = margin(b = 5),
    strip.text = element_text(size = 7.5, face = "bold"),
    strip.background = element_rect(fill = "grey95", color = NA),
    axis.text.x = element_text(angle = 45, hjust = 1, size = 7),
    axis.text.y = element_text(size = 7),
    axis.title.y = element_text(size = 9, margin = margin(r = 5)),
    panel.spacing = unit(0.3, "lines"),
    panel.grid.minor = element_blank(),
    panel.grid.major = element_line(linewidth = 0.3)
  ) +
  guides(color = guide_legend(
    override.aes = list(linewidth = 2, size = 3),  
    nrow = 1
  ))
dev.off()

## Additional visualisation: Dyad-level fairness outcomes over time by member state
df_line_plot <- dataset %>%
  group_by(GEO, YEAR) %>%
  summarise(
    Incoming = sum(`Incoming Transfers to GEO`, na.rm = TRUE),
    Outgoing = sum(`Outgoing Transfers from GEO`, na.rm = TRUE),
    FairContribute = sum(faircontribute, na.rm = TRUE),
    Transfers = sum(transfers, na.rm = TRUE),
    FairContribute1 = sum(fair_dyad, na.rm = TRUE),
    FairContribute2 = sum(unfair_dyad, na.rm = TRUE)
  ) %>%
  mutate(
    transfer_net = Incoming - Outgoing,
    transfer_rate_distributive = (abs(transfer_net) / (Incoming + Outgoing)) * 100,
    fair_contribute_ratio1 = (FairContribute1 / Transfers) * 100,
    fair_contribute_ratio2 = (abs(FairContribute2) / Transfers) * 100,
    remaining_ratio = 100 - (fair_contribute_ratio1 + fair_contribute_ratio2)  
  ) %>%
  pivot_longer(cols = c(fair_contribute_ratio1, fair_contribute_ratio2, remaining_ratio), 
               names_to = "ContributionType", 
               values_to = "Value") %>%
  mutate(ContributionType = recode(ContributionType, 
                                   fair_contribute_ratio1 = "Fair", 
                                   fair_contribute_ratio2 = "Unfair",
                                   remaining_ratio = "Zero-sum"))

# Line plot with facets for each country
jpeg("figureA5.jpeg", width = 13, height = 7, units = "in", res=800)
ggplot(df_line_plot, aes(x = YEAR, y = Value, color = ContributionType, group = ContributionType)) +
  geom_line(linewidth = 1, alpha = 0.8) +  
  geom_point(size = 1.5, alpha = 0.9) +  
  scale_color_manual(
    values = c("Fair" = "#003399", "Unfair" = "#FFCC00", "Zero-sum" = "grey60"),
    breaks = c("Unfair", "Zero-sum", "Fair"),  
    name = NULL
  ) +
  scale_x_continuous(
    breaks = function(x) seq(ceiling(min(x)), floor(max(x)), by = 2)  
  ) +
  scale_y_continuous(
    limits = c(0, 100),
    labels = scales::label_number(suffix = "%"),
    expand = expansion(mult = c(0, 0.02))  
  ) +
  labs(
    x = NULL,  
    y = "Share of transfers (%)"  
  ) +
  facet_wrap(~ GEO, scales = "free_y", ncol = 8) +
  theme_ipsum(base_size = 10) +  
  theme(
    plot.margin = margin(5, 5, 5, 5),
    plot.title = element_text(face = "bold", size = 12, margin = margin(b = 10)),
    legend.position = "top",
    legend.justification = "center",
    legend.text = element_text(size = 9),
    legend.margin = margin(b = 5),
    strip.text = element_text(size = 7.5, face = "bold"),
    strip.background = element_rect(fill = "grey95", color = NA),
    axis.text.x = element_text(angle = 45, hjust = 1, size = 7),
    axis.text.y = element_text(size = 7),
    axis.title.y = element_text(size = 9, margin = margin(r = 5)),
    panel.spacing = unit(0.3, "lines"),
    panel.grid.minor = element_blank(),
    panel.grid.major = element_line(linewidth = 0.3)
  ) +
  guides(color = guide_legend(
    override.aes = list(linewidth = 2, size = 3),  
    nrow = 1
  ))
dev.off()

## Additional visualisation: System-level fairness outcomes over time by member state (partner country aggregation)

# Prepare the data for the line plot
df_line_plot <- dataset %>%
  group_by(PARTNER, YEAR) %>%
  summarise(
    Incoming = sum(`Incoming Transfers to GEO`, na.rm = TRUE),
    Outgoing = sum(`Outgoing Transfers from GEO`, na.rm = TRUE),
    Transfers = sum(transfers, na.rm = TRUE),
    FairContribute1 = sum(fair_system, na.rm = TRUE),
    FairContribute2 = sum(unfair_system, na.rm = TRUE)
  ) %>%
  mutate(
    transfer_net = Incoming - Outgoing,
    transfer_rate_distributive = (abs(transfer_net) / (Incoming + Outgoing)) * 100,
    fair_contribute_ratio1 = (FairContribute1 / Transfers) * 100,
    fair_contribute_ratio2 = (abs(FairContribute2) / Transfers) * 100,
    remaining_ratio = 100 - (fair_contribute_ratio1 + fair_contribute_ratio2)  
  ) %>%
  pivot_longer(cols = c(fair_contribute_ratio1, fair_contribute_ratio2, remaining_ratio), 
               names_to = "ContributionType", 
               values_to = "Value") %>%
  mutate(ContributionType = recode(ContributionType, 
                                   fair_contribute_ratio1 = "Fair", 
                                   fair_contribute_ratio2 = "Unfair",
                                   remaining_ratio = "Neutral"))

# Line plot with facets for each country
jpeg("figureA6.jpeg", width = 13, height = 7, units = "in", res=800)
ggplot(df_line_plot, aes(x = YEAR, y = Value, color = ContributionType, group = ContributionType)) +
  geom_line(linewidth = 1, alpha = 0.8) +  
  geom_point(size = 1.5, alpha = 0.9) +  
  scale_color_manual(
    values = c("Fair" = "#003399", "Unfair" = "#FFCC00", "Neutral" = "grey60"),
    breaks = c("Unfair", "Neutral", "Fair"),  
    name = NULL
  ) +
  scale_x_continuous(
    breaks = function(x) seq(ceiling(min(x)), floor(max(x)), by = 2)  #
  ) +
  scale_y_continuous(
    limits = c(0, 100),
    labels = scales::label_number(suffix = "%"),
    expand = expansion(mult = c(0, 0.02))  
  ) +
  labs(
    x = NULL,  #
    y = "Share of transfers (%)"  
  ) +
  facet_wrap(~ PARTNER, scales = "free_y", ncol = 8) +
  theme_ipsum(base_size = 10) +  
  theme(
    plot.margin = margin(5, 5, 5, 5),
    plot.title = element_text(face = "bold", size = 12, margin = margin(b = 10)),
    legend.position = "top",
    legend.justification = "center",
    legend.text = element_text(size = 9),
    legend.margin = margin(b = 5),
    strip.text = element_text(size = 7.5, face = "bold"),
    strip.background = element_rect(fill = "grey95", color = NA),
    axis.text.x = element_text(angle = 45, hjust = 1, size = 7),
    axis.text.y = element_text(size = 7),
    axis.title.y = element_text(size = 9, margin = margin(r = 5)),
    panel.spacing = unit(0.3, "lines"),
    panel.grid.minor = element_blank(),
    panel.grid.major = element_line(linewidth = 0.3)
  ) +
  guides(color = guide_legend(
    override.aes = list(linewidth = 2, size = 3), 
    nrow = 1
  ))
dev.off()

## Additional visualisation: Dyad-level fairness outcomes over time by member state (partner country aggregation)
df_line_plot <- dataset %>%
  group_by(PARTNER, YEAR) %>%
  summarise(
    Incoming = sum(`Incoming Transfers to GEO`, na.rm = TRUE),
    Outgoing = sum(`Outgoing Transfers from GEO`, na.rm = TRUE),
    FairContribute = sum(faircontribute, na.rm = TRUE),
    Transfers = sum(transfers, na.rm = TRUE),
    FairContribute1 = sum(fair_dyad, na.rm = TRUE),
    FairContribute2 = sum(unfair_dyad, na.rm = TRUE)
  ) %>%
  mutate(
    transfer_net = Incoming - Outgoing,
    transfer_rate_distributive = (abs(transfer_net) / (Incoming + Outgoing)) * 100,
    fair_contribute_ratio1 = (FairContribute1 / Transfers) * 100,
    fair_contribute_ratio2 = (abs(FairContribute2) / Transfers) * 100,
    remaining_ratio = 100 - (fair_contribute_ratio1 + fair_contribute_ratio2)  
  ) %>%
  pivot_longer(cols = c(fair_contribute_ratio1, fair_contribute_ratio2, remaining_ratio), 
               names_to = "ContributionType", 
               values_to = "Value") %>%
  mutate(ContributionType = recode(ContributionType, 
                                   fair_contribute_ratio1 = "Fair", 
                                   fair_contribute_ratio2 = "Unfair",
                                   remaining_ratio = "Zero-sum"))

# Line plot with facets for each country
jpeg("figureA7.jpeg", width = 13, height = 7, units = "in", res=800)
ggplot(df_line_plot, aes(x = YEAR, y = Value, color = ContributionType, group = ContributionType)) +
  geom_line(linewidth = 1, alpha = 0.8) +  
  geom_point(size = 1.5, alpha = 0.9) +  
  scale_color_manual(
    values = c("Fair" = "#003399", "Unfair" = "#FFCC00", "Zero-sum" = "grey60"),
    breaks = c("Unfair", "Zero-sum", "Fair"),  
    name = NULL
  ) +
  scale_x_continuous(
    breaks = function(x) seq(ceiling(min(x)), floor(max(x)), by = 2)  
  ) +
  scale_y_continuous(
    limits = c(0, 100),
    labels = scales::label_number(suffix = "%"),
    expand = expansion(mult = c(0, 0.02))  
  ) +
  labs(
    x = NULL,  
    y = "Share of transfers (%)"  
  ) +
  facet_wrap(~ PARTNER, scales = "free_y", ncol = 8) +
  theme_ipsum(base_size = 10) + 
  theme(
    plot.margin = margin(5, 5, 5, 5),
    plot.title = element_text(face = "bold", size = 12, margin = margin(b = 10)),
    legend.position = "top",
    legend.justification = "center",
    legend.text = element_text(size = 9),
    legend.margin = margin(b = 5),
    strip.text = element_text(size = 7.5, face = "bold"),
    strip.background = element_rect(fill = "grey95", color = NA),
    axis.text.x = element_text(angle = 45, hjust = 1, size = 7),
    axis.text.y = element_text(size = 7),
    axis.title.y = element_text(size = 9, margin = margin(r = 5)),
    panel.spacing = unit(0.3, "lines"),
    panel.grid.minor = element_blank(),
    panel.grid.major = element_line(linewidth = 0.3)
  ) +
  guides(color = guide_legend(
    override.aes = list(linewidth = 2, size = 3),  
    nrow = 1
  ))
dev.off()

## Robustness check: Choropleth of countries' fair contribution ratio using partner country aggregation

# Convert country names to title case
df_aggregated1$PARTNER <- str_to_title(df_aggregated1$PARTNER)

# Remove any leading/trailing spaces
df_aggregated1$PARTNER <- trimws(df_aggregated1$PARTNER)

# Merge the spatial data with your dataset based on country names
df_aggregated_sf1 <- countries %>%
  left_join(df_aggregated1, by = c("name" = "PARTNER"))

# Get a base world map
world_map <- ne_countries(scale = "medium", returnclass = "sf")

min_val <- min(c(df_aggregated_sf1$fair_contribute_ratio, df_aggregated_sf1$fair_contributeB_ratio), na.rm = TRUE)
max_val <- max(c(df_aggregated_sf1$fair_contribute_ratio, df_aggregated_sf1$fair_contributeB_ratio), na.rm = TRUE)

figA9a <- ggplot(data = df_aggregated_sf1) +
  geom_sf(aes(fill = fair_contribute_ratio), color = "white", linewidth = 0.1) +  
  geom_sf(data = world_map, fill = NA, color = "gray70", linewidth = 0.3) +
  scale_fill_gradient2(
    low = "#FFCC00",  
    mid = "grey95",   
    high = "#003399",
    midpoint = 0,
    limits = c(min_val, max_val),
    breaks = seq(-1, 1, by = 0.5),
    labels = function(x) paste0(round(x * 100, 0), "%"),
    name = NULL,
    na.value = "grey90"
  ) +
  labs(
    title = "A. System-level fairness",
    subtitle = "Fair contribution ratio (%)"
  ) +
  theme_void() +
  theme(
    plot.title = element_text(face = "bold", size = 13, hjust = 0, margin = margin(b = 5)),
    plot.subtitle = element_text(size = 10, color = "grey40", hjust = 0, margin = margin(b = 10)),
    plot.margin = margin(15, 15, 15, 15),
    legend.position = "top",
    legend.justification = "center",
    legend.key.width = unit(2.5, "cm"),
    legend.key.height = unit(0.4, "cm"),
    legend.text = element_text(size = 9),
    legend.title = element_text(size = 10, face = "bold"),
    legend.margin = margin(b = 10)
  ) +
  guides(fill = guide_colorbar(
    title.position = "top",
    title.hjust = 0.5,
    barwidth = 15,
    barheight = 0.5,
    frame.colour = "grey50",
    ticks.colour = "grey50"
  )) +
  coord_sf(xlim = c(-22, 32), ylim = c(36, 69.5), expand = FALSE)

figA9b <- ggplot(data = df_aggregated_sf1) +
  geom_sf(aes(fill = fair_contributeB_ratio), color = "white", linewidth = 0.1) +
  geom_sf(data = world_map, fill = NA, color = "gray70", linewidth = 0.3) +
  scale_fill_gradient2(
    low = "#FFCC00",  
    mid = "grey95",   
    high = "#003399", 
    midpoint = 0,
    limits = c(min_val, max_val),
    breaks = seq(-1, 1, by = 0.5),
    labels = function(x) paste0(round(x * 100, 0), "%"),
    name = NULL,
    na.value = "grey90"
  ) +
  labs(
    title = "B. Dyad-level fairness",
    subtitle = "Fair contribution ratio (%)"
  ) +
  theme_void() +
  theme(
    plot.title = element_text(face = "bold", size = 13, hjust = 0, margin = margin(b = 5)),
    plot.subtitle = element_text(size = 10, color = "grey40", hjust = 0, margin = margin(b = 10)),
    plot.margin = margin(15, 15, 15, 15),
    legend.position = "top",
    legend.justification = "center",
    legend.key.width = unit(2.5, "cm"),
    legend.key.height = unit(0.4, "cm"),
    legend.text = element_text(size = 9),
    legend.title = element_text(size = 10, face = "bold"),
    legend.margin = margin(b = 10)
  ) +
  guides(fill = guide_colorbar(
    title.position = "top",
    title.hjust = 0.5,
    barwidth = 15,
    barheight = 0.5,
    frame.colour = "grey50",
    ticks.colour = "grey50"
  )) +
  coord_sf(xlim = c(-22, 32), ylim = c(36, 69.5), expand = FALSE)

jpeg("figureA9.jpeg", width = 14, height = 8, units = "in", res=800)
grid.arrange(figA9a, figA9b, ncol = 2)
dev.off()

## Robustness check: Fairness outcome calculation based on incoming and outgoing transfers S

# --- SYSTEM-LEVEL DATA ---
df_system <- data.frame(
  Category = rep(c("Fair", "Neutral", "Unfair"), each = 2),
  Direction = rep(c("Outgoing", "Incoming"), 3),
  Value = c(
    sum(df_aggregated$fair_system_OUTGOING),
    sum(df_aggregated$fair_system_INCOMING),
    sum(df_aggregated$zero_sum_system_OUTGOING),
    sum(df_aggregated$zero_sum_system_INCOMING),
    sum(abs(df_aggregated$unfair_system_OUTGOING)),
    sum(abs(df_aggregated$unfair_system_INCOMING))
  )
)

df_system <- df_system %>%
  group_by(Direction) %>%
  mutate(Percentage = Value / sum(Value) * 100) %>%
  ungroup()

# --- DYADIC-LEVEL DATA ---
df_dyad <- data.frame(
  Category = rep(c("Fair", "Zero-sum", "Unfair"), each = 2),
  Direction = rep(c("Outgoing", "Incoming"), 3),
  Value = c(
    sum(df_aggregated$fair_dyad_OUTGOING),
    sum(df_aggregated$fair_dyad_INCOMING),
    sum(df_aggregated$zero_sum_dyad_OUTGOING),
    sum(df_aggregated$zero_sum_dyad_INCOMING),
    sum(abs(df_aggregated$unfair_dyad_OUTGOING)),
    sum(abs(df_aggregated$unfair_dyad_INCOMING))
  )
)

df_dyad <- df_dyad %>%
  group_by(Direction) %>%
  mutate(Percentage = Value / sum(Value) * 100) %>%
  ungroup()

# Factor ordering
df_system$Category <- factor(df_system$Category, levels = c("Fair", "Neutral", "Unfair"))
df_dyad$Category <- factor(df_dyad$Category, levels = c("Fair", "Zero-sum", "Unfair"))
df_system$Direction <- factor(df_system$Direction, levels = c("Outgoing", "Incoming"))
df_dyad$Direction <- factor(df_dyad$Direction, levels = c("Outgoing", "Incoming"))

# Shared y-axis limit
max_value <- max(df_system$Value, df_dyad$Value) * 1.1

# Define base colors by category
base_colors <- c("Fair" = "#003399", "Zero-sum" = "gray", "Unfair" = "#FFCC00")

# --- PLOT A: System-level fairness ---
figA10a <- ggplot(df_system, aes(x = Category, y = Value, fill = Category, alpha = Direction)) +
  geom_col(position = position_dodge(width = 0.8), width = 0.7, 
           color = "white", linewidth = 0.3) +
  scale_fill_manual(values = base_colors, guide = "none") +
  scale_alpha_manual(
    values = c("Outgoing" = 1, "Incoming" = 0.5),
    labels = c("Outgoing", "Incoming"),
    name = NULL
  ) +
  scale_y_continuous(
    labels = scales::label_number(scale = 1/1000, suffix = "k"),
    limits = c(0, max_value * 1.15),
    expand = expansion(mult = c(0, 0.05))
  ) +
  scale_x_discrete(labels = function(x) str_to_title(x)) +
  labs(
    title = "A. System-level fairness",
    subtitle = "Distribution of Dublin transfers by fairness category",
    x = NULL,
    y = "Dublin transfers (thousands)"
  ) +
  geom_text(
    aes(label = paste0(round(Percentage, 1), "%")),
    position = position_dodge(width = 0.8),
    vjust = -0.5,
    size = 3.5,
    fontface = "bold",
    show.legend = FALSE  #
  ) +
  theme_ipsum() +
  theme(
    plot.margin = margin(10,10,10,10),
    plot.title = element_text(face = "bold", size = 13),
    plot.subtitle = element_text(size = 9, color = "grey40", margin = margin(b = 10)),
    legend.position = "top",
    legend.justification = "center",
    legend.text = element_text(size = 10),
    axis.text.x = element_text(size = 11, face = "bold"),
    panel.grid.major.x = element_blank(),
    panel.grid.minor = element_blank(),
    panel.grid.major.y = element_line(linetype = "dotted", color = "grey70")
  )

# --- PLOT B: Dyadic fairness ---
figA10b <- ggplot(df_dyad, aes(x = Category, y = Value, fill = Category, alpha = Direction)) +
  geom_col(position = position_dodge(width = 0.8), width = 0.7,
           color = "white", linewidth = 0.3) +
  scale_fill_manual(values = base_colors, guide = "none") +
  scale_alpha_manual(
    values = c("Outgoing" = 1, "Incoming" = 0.5),
    labels = c("Outgoing", "Incoming"),
    name = NULL
  ) +
  scale_y_continuous(
    labels = scales::label_number(scale = 1/1000, suffix = "k"),
    limits = c(0, max_value * 1.15),
    expand = expansion(mult = c(0, 0.05))
  ) +
  scale_x_discrete(labels = function(x) str_to_title(x)) +
  labs(
    title = "B. Dyad-level fairness",
    subtitle = "Distribution of Dublin transfers by fairness category",
    x = NULL,
    y = "Dublin transfers (thousands)"
  ) +
  geom_text(
    aes(label = paste0(round(Percentage, 1), "%")),
    position = position_dodge(width = 0.8),
    vjust = -0.5,
    size = 3.5,
    fontface = "bold",
    show.legend = FALSE  
  ) +
  theme_ipsum() +
  theme(
    plot.margin = margin(10,10,10,10),
    plot.title = element_text(face = "bold", size = 13),
    plot.subtitle = element_text(size = 9, color = "grey40", margin = margin(b = 10)),
    legend.position = "top",
    legend.justification = "center",
    legend.text = element_text(size = 10),
    axis.text.x = element_text(size = 11, face = "bold"),
    panel.grid.major.x = element_blank(),
    panel.grid.minor = element_blank(),
    panel.grid.major.y = element_line(linetype = "dotted", color = "grey70")
  )
# --- COMBINE AND EXPORT ---
jpeg("figureA10.jpeg", width = 8, height = 4, units = "in", res = 800)
ggarrange(figA10a, figA10b, ncol = 2, common.legend = TRUE, legend = "top")
dev.off()

## Assessing the suspension explanation
# calculating the fairness of Dublin transfers under the exclusion of dyad-years with legal suspensions

# Calculate the total transfers and percentages on the system-level
df_transfer_shares_system_figA11 <- data.frame(
  Category = c("Fair", "Neutral", "Unfair"),
  Value = c(sum(df_aggregated$fair_system1), 
            sum(df_aggregated$Transfers1) - (sum(df_aggregated$fair_system1) + abs(sum(df_aggregated$unfair_system1))), 
            abs(sum(df_aggregated$unfair_system1)))
) %>%
  mutate(Percentage = Value / sum(Value) * 100)  # 
# and dyad-level
df_transfer_shares_dyad_figA11 <- data.frame(
  Category = c("Fair", "Zero-sum", "Unfair"),
  Value = c(sum(df_aggregated$fair_dyad1), 
            sum(df_aggregated$Transfers1) - (sum(df_aggregated$fair_dyad1) + abs(sum(df_aggregated$unfair_dyad1))), 
            abs(sum(df_aggregated$unfair_dyad1)))
) %>%
  mutate(Percentage = Value / sum(Value) * 100)  # 

df_transfer_shares_system_figA11$Category <- factor(df_transfer_shares_system_figA11$Category,
                                      levels = c("Fair", "Neutral", "Unfair"))
df_transfer_shares_dyad_figA11$Category <- factor(df_transfer_shares_dyad_figA11$Category,
                                       levels = c("Fair", "Zero-sum", "Unfair"))

# Determine common y-axis range (optional if you know the max)
max_y <- max(df_transfer_shares_system_figA11$Value+10000, df_transfer_shares_dyad_figA11$Value+10000) / 1000

figA11a <- ggplot(df_transfer_shares_system_figA11, aes(x = Category, y = Value / 1000, fill = Category)) +
  geom_col(width = 0.65, show.legend = FALSE) +  # 
  scale_fill_manual(values = c("Fair" = "#003399", "Neutral" = "grey60", "Unfair" = "#FFCC00")) +
  scale_y_continuous(
    labels = scales::label_number(suffix = "k"),
    expand = expansion(mult = c(0, 0.05))
  ) +
  scale_x_discrete(labels = function(x) str_to_title(x)) +
  labs(
    title = "A. System-level fairness",
    subtitle = "Distribution of Dublin transfers by fairness category",
    x = NULL,
    y = "Dublin transfers (thousands)"
  ) +
  geom_text(
    aes(label = paste0(round(Percentage, 1), "%")),
    vjust = -0.5,
    size = 4,
    fontface = "bold"
  ) +
  coord_cartesian(ylim = c(0, max_y)) +
  theme_ipsum() +
  theme(
    plot.margin = margin(15, 15, 15, 15),
    plot.title = element_text(face = "bold", size = 13),
    plot.subtitle = element_text(size = 9, color = "grey40", margin = margin(b = 10)),
    legend.position = "none",
    axis.text.x = element_text(size = 11, face = "bold"),
    panel.grid.major.x = element_blank(),
    panel.grid.minor = element_blank(),
    panel.grid.major.y = element_line(linetype = "dotted", color = "grey70")
  )

figA11b <- ggplot(df_transfer_shares_dyad_figA11, aes(x = Category, y = Value / 1000, fill = Category)) +
  geom_col(width = 0.65, show.legend = FALSE) +
  scale_fill_manual(values = c("Fair" = "#003399", "Zero-sum" = "grey60", "Unfair" = "#FFCC00")) +
  scale_y_continuous(
    labels = scales::label_number(suffix = "k"),
    expand = expansion(mult = c(0, 0.05))
  ) +
  scale_x_discrete(labels = function(x) str_to_title(x)) +
  labs(
    title = "B. Dyad-level fairness",
    subtitle = "Distribution of Dublin transfers by fairness category",
    x = NULL,
    y = "Dublin transfers (thousands)"
  ) +
  geom_text(
    aes(label = paste0(round(Percentage, 1), "%")),
    vjust = -0.5,
    size = 4,
    fontface = "bold"
  ) +
  coord_cartesian(ylim = c(0, max_y)) +
  theme_ipsum() +
  theme(
    plot.margin = margin(15, 15, 15, 15),
    plot.title = element_text(face = "bold", size = 13),
    plot.subtitle = element_text(size = 9, color = "grey40", margin = margin(b = 10)),
    legend.position = "none",
    axis.text.x = element_text(size = 11, face = "bold"),
    panel.grid.major.x = element_blank(),
    panel.grid.minor = element_blank(),
    panel.grid.major.y = element_line(linetype = "dotted", color = "grey70")
  )

jpeg("figureA11.jpeg", width = 9, height = 4.5, units = "in", res = 800)
ggarrange(figA11a, figA11b, ncol = 2)
dev.off()

## Assessing the selective implementation explanation
# Simulating the fairness of Dublin transfers under full implementation of requests and positive decisions

df_transfer_shares_system_figA12 <- data.frame(
  Category = c("Fair", "Neutral", "Unfair"),
  Value = c(sum(df_aggregated$fairreq_system), 
            sum(df_aggregated$Requests) - (sum(df_aggregated$fairreq_system) + abs(sum(df_aggregated$unfairreq_system))), 
            abs(sum(df_aggregated$unfairreq_system)))
) %>%
  mutate(Percentage = Value / sum(Value) * 100) 

df_transfer_shares_dyad_figA12 <- data.frame(
  Category = c("Fair", "Neutral", "Unfair"),
  Value = c(sum(df_aggregated$fairdec_system), 
            sum(df_aggregated$Decisions) - (sum(df_aggregated$fairdec_system) + abs(sum(df_aggregated$unfairdec_system))), 
            abs(sum(df_aggregated$unfairdec_system)))
) %>%
  mutate(Percentage = Value / sum(Value) * 100)  

df_transfer_shares_system_figA12$Category <- factor(df_transfer_shares_system_figA12$Category,
                                      levels = c("Fair", "Neutral", "Unfair"))
df_transfer_shares_dyad_figA12$Category <- factor(df_transfer_shares_dyad_figA12$Category,
                                       levels = c("Fair", "Neutral", "Unfair"))

# Determine common y-axis limit
max_y <- max(df_transfer_shares_system_figA12$Value+20000, df_transfer_shares_dyad_figA12$Value+20000) / 1000

figA12a <- ggplot(df_transfer_shares_system_figA12, aes(x = Category, y = Value / 1000, fill = Category)) +
  geom_col(width = 0.65, show.legend = FALSE) +
  scale_fill_manual(values = c("Fair" = "#003399", "Neutral" = "grey60", "Unfair" = "#FFCC00")) +
  scale_y_continuous(
    labels = scales::label_number(suffix = "k"),
    expand = expansion(mult = c(0, 0.05))
  ) +
  scale_x_discrete(labels = function(x) str_to_title(x)) +
  labs(
    title = "A. Fairness simulation: Requests",
    subtitle = "Distribution of Dublin requests by fairness category",
    x = NULL,
    y = "Dublin requests (thousands)"
  ) +
  geom_text(
    aes(label = paste0(round(Percentage, 1), "%")),
    vjust = -0.5,
    size = 4,
    fontface = "bold"
  ) +
  coord_cartesian(ylim = c(0, max_y)) +
  theme_ipsum() +
  theme(
    plot.margin = margin(15, 15, 15, 15),
    plot.title = element_text(face = "bold", size = 13),
    plot.subtitle = element_text(size = 9, color = "grey40", margin = margin(b = 10)),
    legend.position = "none",
    axis.text.x = element_text(size = 11, face = "bold"),
    panel.grid.major.x = element_blank(),
    panel.grid.minor = element_blank(),
    panel.grid.major.y = element_line(linetype = "dotted", color = "grey70")
  )

figA12b <- ggplot(df_transfer_shares_dyad_figA12, aes(x = Category, y = Value / 1000, fill = Category)) +
  geom_col(width = 0.65, show.legend = FALSE) +
  scale_fill_manual(values = c("Fair" = "#003399", "Neutral" = "grey60", "Unfair" = "#FFCC00")) +
  scale_y_continuous(
    labels = scales::label_number(suffix = "k"),
    expand = expansion(mult = c(0, 0.05))
  ) +
  scale_x_discrete(labels = function(x) str_to_title(x)) +
  labs(
    title = "B. Fairness simulation: Positive decisions",
    subtitle = "Distribution of positive Dublin decisions by fairness category",
    x = NULL,
    y = "Positive Dublin decisions (thousands)"
  ) +
  geom_text(
    aes(label = paste0(round(Percentage, 1), "%")),
    vjust = -0.5,
    size = 4,
    fontface = "bold"
  ) +
  coord_cartesian(ylim = c(0, max_y)) +
  theme_ipsum() +
  theme(
    plot.margin = margin(15, 15, 15, 15),
    plot.title = element_text(face = "bold", size = 13),
    plot.subtitle = element_text(size = 9, color = "grey40", margin = margin(b = 10)),
    legend.position = "none",
    axis.text.x = element_text(size = 11, face = "bold"),
    panel.grid.major.x = element_blank(),
    panel.grid.minor = element_blank(),
    panel.grid.major.y = element_line(linetype = "dotted", color = "grey70")
  )

# Combine plots
jpeg("figureA12.jpeg", width = 10, height = 5, units = "in", res=800)
ggarrange(figA12a, figA12b, ncol = 2)
dev.off()

## Robustness check: Fairness outcome calculation based on requests and decisions based on Eurodac hits

df_transfer_shares_system_figA13 <- data.frame(
  Category = c("Fair", "Neutral", "Unfair"),
  Value = c(sum(df_aggregated$fairreq_system_eurodac), 
            sum(df_aggregated$Requests_eurodac) - (sum(df_aggregated$fairreq_system_eurodac) + abs(sum(df_aggregated$unfairreq_system_eurodac))), 
            abs(sum(df_aggregated$unfairreq_system_eurodac)))
) %>%
  mutate(Percentage = Value / sum(Value) * 100)  

df_transfer_shares_dyad_figA13 <- data.frame(
  Category = c("Fair", "Neutral", "Unfair"),
  Value = c(sum(df_aggregated$fairdec_system_eurodac), 
            sum(df_aggregated$Decisions_eurodac) - (sum(df_aggregated$fairdec_system_eurodac) + abs(sum(df_aggregated$unfairdec_system_eurodac))), 
            abs(sum(df_aggregated$unfairdec_system_eurodac)))
) %>%
  mutate(Percentage = Value / sum(Value) * 100)  

df_transfer_shares_system_figA13$Category <- factor(df_transfer_shares_system_figA13$Category,
                                      levels = c("Fair", "Neutral", "Unfair"))
df_transfer_shares_dyad_figA13$Category <- factor(df_transfer_shares_dyad_figA13$Category,
                                       levels = c("Fair", "Neutral", "Unfair"))

# Determine common y-axis limit
max_y <- max(df_transfer_shares_system_figA13$Value+20000, df_transfer_shares_dyad_figA13$Value+20000) / 1000

figA13a <- ggplot(df_transfer_shares_system_figA13, aes(x = Category, y = Value / 1000, fill = Category)) +
  geom_col(width = 0.65, show.legend = FALSE) +
  scale_fill_manual(values = c("Fair" = "#003399", "Neutral" = "grey60", "Unfair" = "#FFCC00")) +
  scale_y_continuous(
    labels = scales::label_number(suffix = "k"),
    expand = expansion(mult = c(0, 0.05))
  ) +
  scale_x_discrete(labels = function(x) str_to_title(x)) +
  labs(
    title = "A. Fairness simulation: Requests",
    subtitle = "Distribution of Eurodac-based Dublin requests by fairness category",
    x = NULL,
    y = "Dublin requests (thousands)"
  ) +
  geom_text(
    aes(label = paste0(round(Percentage, 1), "%")),
    vjust = -0.5,
    size = 4,
    fontface = "bold"
  ) +
  coord_cartesian(ylim = c(0, max_y)) +
  theme_ipsum() +
  theme(
    plot.margin = margin(15, 15, 15, 15),
    plot.title = element_text(face = "bold", size = 13),
    plot.subtitle = element_text(size = 9, color = "grey40", margin = margin(b = 10)),
    legend.position = "none",
    axis.text.x = element_text(size = 11, face = "bold"),
    panel.grid.major.x = element_blank(),
    panel.grid.minor = element_blank(),
    panel.grid.major.y = element_line(linetype = "dotted", color = "grey70")
  )

figA13b <- ggplot(df_transfer_shares_dyad_figA13, aes(x = Category, y = Value / 1000, fill = Category)) +
  geom_col(width = 0.65, show.legend = FALSE) +
  scale_fill_manual(values = c("Fair" = "#003399", "Neutral" = "grey60", "Unfair" = "#FFCC00")) +
  scale_y_continuous(
    labels = scales::label_number(suffix = "k"),
    expand = expansion(mult = c(0, 0.05))
  ) +
  scale_x_discrete(labels = function(x) str_to_title(x)) +
  labs(
    title = "B. Fairness simulation: Positive decisions",
    subtitle = "Distribution of Eurodac-based positive Dublin decisions by fairness category",
    x = NULL,
    y = "Positive Dublin decisions (thousands)"
  ) +
  geom_text(
    aes(label = paste0(round(Percentage, 1), "%")),
    vjust = -0.5,
    size = 4,
    fontface = "bold"
  ) +
  coord_cartesian(ylim = c(0, max_y)) +
  theme_ipsum() +
  theme(
    plot.margin = margin(15, 15, 15, 15),
    plot.title = element_text(face = "bold", size = 13),
    plot.subtitle = element_text(size = 9, color = "grey40", margin = margin(b = 10)),
    legend.position = "none",
    axis.text.x = element_text(size = 11, face = "bold"),
    panel.grid.major.x = element_blank(),
    panel.grid.minor = element_blank(),
    panel.grid.major.y = element_line(linetype = "dotted", color = "grey70")
  )

# Combine plots
jpeg("figureA13.jpeg", width = 10, height = 5, units = "in", res=800)
ggarrange(figA13a, figA13b, ncol = 2)
dev.off()

## Analysis of sovereignty clause use
sovereign <- read.csv("sovereignty_total.csv")
names(sovereign)[4] <- "sovereign"
sovereign <- subset(sovereign, PARTNER == "Total")
sovereign <- sovereign[sovereign$PARTNER == "Total", ]
sovereign <- sovereign[,-c(2)]
sovereign_agg <- aggregate(sovereign ~ GEO, data = sovereign, FUN = sum)

sovereignty <- df_aggregated %>%
  left_join(sovereign_agg, by = c("GEO"))

merged_sovereign <- merge(sovereign, dataset, 
                     by = c("GEO", "YEAR"), 
                     all = TRUE)
merged_sovereign <- subset(merged_sovereign, merged_sovereign$YEAR>=2014)

merged_sovereign <- merged_sovereign %>%
  mutate(
    # Rate per 1000 applications
    sovereign_rate = (sovereign / applications) * 1000,
    # Or as percentage
    sovereign_pct = (sovereign / applications) * 100
  )

# Aggregate to country level with rates
country_sovereign <- merged_sovereign %>%
  filter(!is.na(sovereign), !is.na(applications), !is.na(fair_share_fulfilment)) %>%
  group_by(GEO) %>%
  summarise(
    total_sovereign = sum(sovereign),
    total_applications = sum(applications),
    avg_fair_share_fulfilment = mean(fair_share_fulfilment),
    sovereign_rate = (total_sovereign / total_applications) * 1000,
    years = n()
  ) %>%
  filter(total_applications > 1000)  # exclude very small countries

# Correlation at country level
cor.test(country_sovereign$avg_fair_share_fulfilment, 
         country_sovereign$sovereign_rate,
         method = "spearman")

# Calculate correlation for caption
cor_value <- cor(country_sovereign$avg_fair_share_fulfilment, 
                 country_sovereign$sovereign_rate, 
                 method = "spearman")
# Calculate correlation and test
cor_test <- cor.test(country_sovereign$avg_fair_share_fulfilment, 
                     country_sovereign$sovereign_rate, 
                     method = "spearman")

# Plot with country labels
jpeg("figureA14.jpeg", width = 5, height = 5, units = "in", res=800)
ggplot(country_sovereign, aes(x = avg_fair_share_fulfilment, y = sovereign_rate)) +
  geom_vline(xintercept = 100, linetype = "dashed", color = "grey50", linewidth = 0.8) + 
  geom_smooth(method = "lm", color = "#FFCC00", fill = "#FFCC00", alpha = 0.2) +
  geom_point(size = 3, color = "#003399", alpha = 0.7) +
  geom_text_repel(
    aes(label = GEO),
    size = 3,
    max.overlaps = 15,
    box.padding = 0.5
  ) +
  annotate("text", x = 100, y = max(country_sovereign$sovereign_rate) * 0.95, 
           label = "Fair share", angle = 90, vjust = -0.5, 
           size = 3, color = "grey50", fontface = "italic") +
  labs(
    subtitle = "Country-level aggregates (2014-2024)",
    x = "Average fair share fulfillment (pp)",
    y = "Sovereignty clause uses per 1,000 applications",
    caption = paste0("Spearman's rho = ", round(cor_test$estimate, 2), 
                     ", p = ", round(cor_test$p.value, 3))
  ) +
  theme_ipsum() +
  theme(
    plot.margin = margin(10, 10, 10, 10),
    plot.title = element_text(face = "bold", size = 13),
    plot.subtitle = element_text(size = 10, color = "grey40", margin = margin(b = 10)),
    plot.caption = element_text(hjust = 0, size = 9, color = "grey40", margin = margin(t = 10)),
    panel.grid.major = element_line(linetype = "dotted", color = "grey70"),
    panel.grid.minor = element_blank()
  )
dev.off()
###############################
# Replication File
#
# EXPLAINING THE IMMIGRATION POLICY MIX: COUNTRIES' RELATIVE OPENNESS TO ASYLUM AND LABOUR MIGRATION
# Authors: Caroline Schultz, Philipp Lutz & Stephan Simon

### Analysing the immigration policy mix based on policies (IMPIC dataset)

library(foreign)
library(lmtest)
library(sandwich)
dataset <- read.dta("policy_dataset.dta")

# subsample of EU member states
dataset_eu <- subset(dataset, dataset$country!="United States" & dataset$country!="Turkey" & dataset$country!="Taiwan" & dataset$country!="New Zealand" & dataset$country!="Mexico" & dataset$country!="Korea" & dataset$country!="Japan" & dataset$country!="Israel" & dataset$country!="Chile" & dataset$country!="Canada" & dataset$country!="Australia" & dataset$country!="Norway" & dataset$country!="Iceland" & dataset$country!="Switzerland")

### descriptive plots

# Figure 1
asylum_means <- aggregate(dataset$asylum, by=list(dataset$country), FUN=mean)
names(asylum_means)[1] <- "country"
names(asylum_means)[2] <- "asylum_mean"
labour_means <- aggregate(dataset$labor, by=list(dataset$country), FUN=mean)
names(labour_means)[1] <- "country"
names(labour_means)[2] <- "labour_mean"
means <- merge(asylum_means, labour_means, by=c("country"))
means$diff <- means$asylum_mean-means$labour_mean
means$asl1 <- means$asylum_mean
means$asl1[means$diff>0] <- NA
means$asl2 <- means$asylum_mean
means$asl2[means$diff<0] <- NA
means$lab1 <- means$labour_mean
means$lab1[means$diff>0] <- NA
means$lab2 <- means$labour_mean
means$lab2[means$diff<0] <- NA
means <- means[order(means$diff),]
means <- subset(means, means$asylum_mean>=0)
library(tibble)
ID <- rowid_to_column(means)
redtrans1 <- adjustcolor("red", alpha.f=0.3)
bluetrans1 <- adjustcolor("blue", alpha.f=0.3)
blacktrans1 <- adjustcolor("black", alpha.f=0.3)
par (mar=c(7,3,0,1), mgp=c(2,.7,0), tck=-.01, las=1, bty="n") # 
par(mfrow = c(1,1))
plot(ID$asylum_mean, ylim=c(0,1),col="red", pch=20, xaxt='n', xlab="", ylab="Policy restrictiveness")
axis(1, at=ID$rowid, labels=ID$country, las=2)
abline(h=c(0.2,0.4,0.6,0.8), lty=2, col="gray70")
segments(ID$rowid,ID$asl1,ID$rowid,ID$lab1, lwd=5, col=redtrans1)
segments(ID$rowid,ID$asl2,ID$rowid,ID$lab2, lwd=5, col=bluetrans1)
points(ID$labour_mean, add=T, pch=20, col="blue")
points(ID$asylum_mean, add=T, pch=20, col="red")
legend(20,1, c("asylum", "labour"), col=c("red", "blue"), pch=20, bty='n')
legend(25,1, c("asylum-favourability", "labour-favourability"), col=c(redtrans1,bluetrans1), lwd=5, bty='n')
text(21.8,1, "Sub-field", font=2)
text(29.3,1, "Immigration policy mix", font=2)

# Figure A1
mixonly <- dataset[c(1,2,14)]
mix1980 <- subset(mixonly, mixonly$year==1980)
mix1980 <- mix1980[-c(1)]
names(mix1980)[2] <- "mix1980"
mix2010 <- subset(mixonly, mixonly$year==2010)
mix2010 <- mix2010[-c(1)]
names(mix2010)[2] <- "mix2010"
mix_comparison <- merge(mix1980,mix2010, by=c("country"))
mix_comparison$diff <- mix_comparison$mix1980-mix_comparison$mix2010
mix_comparison$mix1980a <- mix_comparison$mix1980
mix_comparison$mix1980a[mix_comparison$diff>0] <- NA
mix_comparison$mix1980b <- mix_comparison$mix1980
mix_comparison$mix1980b[mix_comparison$diff<0] <- NA
mix_comparison$mix2010a <- mix_comparison$mix2010
mix_comparison$mix2010a[mix_comparison$diff>0] <- NA
mix_comparison$mix2010b <- mix_comparison$mix2010
mix_comparison$mix2010b[mix_comparison$diff<0] <- NA
mix_comparison <- mix_comparison[order(mix_comparison$diff),]
mix_comparison <- subset(mix_comparison, mix_comparison$mix1980>=-2)
library(tibble)
ID <- rowid_to_column(mix_comparison)
par (mar=c(7,3,0,1), mgp=c(2,.7,0), tck=-.01, las=1, bty="n") # 
plot(ID$mix1980, ylim=c(-1,1),col="red", pch=20, xaxt='n', xlab="", ylab="Immigration policy mix")
axis(1, at=ID$rowid, labels=ID$country, las=2)
abline(h=c(-0.5,0,0.5), lty=2, col="gray70")
arrows(ID$rowid,ID$mix1980a,ID$rowid,ID$mix2010a, lwd=5, col=redtrans1, length=0.15)
arrows(ID$rowid,ID$mix1980b,ID$rowid,ID$mix2010b, lwd=5, col=bluetrans1, length=0.15)
points(ID$mix2010, add=T, pch=20, col="blue")
points(ID$mix1980, add=T, pch=20, col="red")
legend(5,1, c("1980"), col=c("red"), pch=20, bty='n')
legend(5,0.88, c("2010"), col=c("blue"), pch=20, bty='n')
legend(22,1, c("more labour-favourability", "more asylum-favourability"), col=c(redtrans1,bluetrans1), lwd=5, bty='n')
text(15,0.8, "prefer labour")
arrows(x0=15, y0=0.9, y1=1, lwd=1, length=0.07)
text(15,-0.8, "prefer asylum")
arrows(x0=15, y0=-0.9, y1=-1, lwd=1, length=0.07)

# Figure 2a
library(ggplot2)
library(grid)
library(gridExtra)
my_text <- "Labour"
text1 = grid.text(my_text, x=0.94, y=0.37, gp=gpar(col="blue", fontsize=8, fontface="bold"))
my_text <- "Asylum"
text2 = grid.text(my_text, x=0.94, y=0.27, gp=gpar(col="red", fontsize=8, fontface="bold"))
p1 <-ggplot() + geom_jitter(aes(dataset$year, dataset$asylum), color=redtrans1, width=0.5, height=0.03) + geom_jitter(aes(dataset$year, dataset$labor), color=bluetrans1, width=0.5, height=0.03) + geom_hline(yintercept=c(0.25,0.5,0.75), linetype="dashed", color="gray") + ggtitle("2a. Sub-field restrictiveness") + 
  geom_smooth(aes(dataset$year, dataset$asylum),method="loess", span=0.2, se=T, level=0.9, fill=redtrans1, color="red", na.rm=T, lwd=1.5)   + scale_x_continuous(name="Year", limits=c(1980,2014), breaks=c(1980,1990,2000,2010)) + scale_y_continuous(name="Policy restrictiveness", breaks=c(0, 0.25,0.5,0.75,1)) +
  geom_smooth(aes(dataset$year, dataset$labor),method="loess", span=0.2, se=T, level=0.9,fill=bluetrans1, color="blue", na.rm=T, lwd=1.5) + theme_bw() + theme(plot.title=element_text(size=16, face="bold")) + annotation_custom(text1) + annotation_custom(text2)

# Figure 2b: 
p2 <-ggplot() + geom_jitter(aes(dataset$year, dataset$mix), color=blacktrans1, width=0.5, height=0.03) + geom_hline(yintercept=0, linetype="dashed", color="gray")  + labs(title="2b. Immigration policy mix") + 
  geom_smooth(aes(dataset$year, dataset$mix),method="loess", span=0.2, se=T, level=0.9, fill=blacktrans1, color="black", na.rm=T, lwd=1.5)  + xlim(1980,2010) + ylim(-1,1) + scale_x_continuous(name="Year", breaks=c(1980,1990,2000,2010)) + scale_colour_manual(name="Sub-field", values=c("black")) +
  ggtitle("2b. Immigration policy mix") + theme_bw() + theme(plot.title=element_text(size=16, face="bold")) + ylab("Immigration policy mix")

### combining Figure 2a & 2b
grid.arrange(p1, p2, nrow=1)

### convergence analysis
sd_oecd <- aggregate(dataset$mix, by=list(dataset$year), FUN=sd, na.rm=T)
sd_eu <- aggregate(dataset_eu$mix, by=list(dataset_eu$year), FUN=sd, na.rm=T)

# Figure 3
par (mar=c(3,3,0,1), mgp=c(2,.7,0), tck=-.01, las=1, bty="n") # 
plot(sd_oecd, type='l', ylim=c(0,0.4), lwd=3, col="red", xlab="Year", ylab="SD (Policy mix)")
lines(sd_eu, add=T, lwd=3, col="gray20")
abline(h=c(0.1,0.2,0.3,0.4), lty=2, col="gray70")
legend(2001,0.37, legend=c("OECD", "EU"), col=c("red", "gray20"), cex=1.1, lty=1, lwd=3, bty='n')

## calculate Beta-Convergence
data1980 <- subset(dataset, dataset_eu$year==1980)
data2010 <- subset(dataset, dataset_eu$year==2010)
con_data <- data.frame(data1980$mix, data2010$mix, data1980$country)
con_data$change <- con_data$data2010.mix-con_data$data1980.mix
con1 <- lm(change ~ data1980.mix, data = con_data)  # 
summary(con1)
data1980 <- subset(dataset_eu, dataset_eu$year==1980)
data2010 <- subset(dataset_eu, dataset_eu$year==2010)
con_data <- data.frame(data1980$mix, data2010$mix, data1980$country)
con_data$change <- con_data$data2010.mix-con_data$data1980.mix
con2 <- lm(change ~ data1980.mix, data = con_data)  # 
summary(con2)

# Table 1
library(stargazer)
stargazer(con1, con2,
          title="Estimation of Beta-Convergence", 
          align=F, 
          dep.var.labels=c("DV: Change in policy mix (1980-2010)"), 
          covariate.labels=c("Policy mix (1980)"),  
          no.space=TRUE, 
          dep.var.caption="", 
          model.numbers=T,
          star.cutoffs = c(0.05, 0.01, 0.001))

# Figure A3
ggplot(data=dataset, aes(x=year, y=mix, group=country)) + geom_line(lwd=1.2,color='gray30', alpha=0.4) + geom_hline(yintercept=c(0), linetype="dashed") + xlab("Year")  + ylab("Immigration policy mix") + theme_bw()

# Figure A5
d <- density(dataset$mix, na.rm=T)
par (mar=c(4,3,2,1), mgp=c(2,.7,0), tck=-.01, las=1, bty="l")   # 
p2 <- plot(d1, main="", xlim=c(-1.2,1.1), ylim=c(0,3), col=redtrans1)
polygon(d1, col=redtrans1)
d2 <- density(dataset$mix[dataset$year==2010], na.rm=T)
lines(d2, main="", xlim=c(-1.2,1.1), add=T, col=bluetrans1)
polygon(d2, col=bluetrans1)
legend("topright", legend=c("1980", "2010"), fill=c(redtrans1, bluetrans1), bty='n')

#### models (panel regression models with country-clustered standard errors)
library(plm)
dataset_plm <- pdata.frame(dataset, index=c("country","year"), drop.index=TRUE, row.names=TRUE)
dataset_plm_eu <- pdata.frame(dataset_eu, index=c("country","year"), drop.index=TRUE, row.names=TRUE)

### Within-models
# all OECD countries
within1 <- plm(mix ~ eu + rrpp_vote + gov_left2 + gov_right2 + unemp, data = dataset_plm, model="within")  # 
coef1 <- coeftest(within1, vcov=vcovHC, type="HC1") #
# only EU countries
within2 <- plm(mix ~ eu + rrpp_vote + gov_left2 + gov_right2 + unemp, data = dataset_plm_eu, model="within")  # 
coef2 <- coeftest(within2, vcov=vcovHC, type="HC1") #

## alternative model specifications
# adjusted for time trend
within3 <- plm(mix ~ eu + rrpp_vote + gov_left2 + gov_right2 + unemp  + timetrend, data = dataset_plm, model="within")  # 
coef3 <- coeftest(within3, vcov=vcovHC, type="HC1") #
# with welfare generosity
within5 <- plm(mix ~ eu + rrpp_vote + gov_left2 + gov_right2 + unemp + totgen, data = dataset_plm, model="within")  # 
coef5 <- coeftest(within5, vcov=vcovHC, type="HC1") #
# with net migration
within6 <- plm(mix ~ eu + rrpp_vote + gov_left2 + gov_right2 + unemp + netmig, data = dataset_plm, model="within")  # 
coef6 <- coeftest(within6, vcov=vcovHC, type="HC1") #
# with seat share instead of vote share
within8 <- plm(mix ~ eu + rrpp_seat + gov_left2 + gov_right2 + unemp, data = dataset_plm, model="within")  # 
coef8 <- coeftest(within8, vcov=vcovHC, type="HC1") #


### Between-models
# all OECD countries
between1 <- plm(mix ~ totgen + unemp, data = dataset_plm, model="between")  # 
coef1b <- coeftest(between1) #
# only EU countries
between2 <- plm(mix ~ totgen + unemp, data = dataset_plm_eu, model="between")  # 
coef2b <- coeftest(between2) #

## alternative model estimates
# with regime dummies
between3 <- plm(mix ~ as.factor(welfare) + unemp, data = dataset_plm, model="between")  # 
coeftest(between3) #
# with all independent variables
between4 <- plm(mix ~ totgen + eu + rrpp_vote + gov_left2 + gov_right2 +  unemp, data = dataset_plm, model="between")  # 
coef4b <- coeftest(between4) #


# Table 2a
library(stargazer)
stargazer(within1, within2,
          title="Determinants of the Policy Mix (within models)", 
          se = list(coef1[,2],coef2[,2]),
          align=F, 
          dep.var.labels=c("DV: Policy Mix"), 
          covariate.labels=c("EU-membership", "Radical-right strength", "Left government", "Right government",  "Unemployment"),  
          no.space=TRUE, 
          dep.var.caption="", 
          model.numbers=T,
          star.cutoffs = c(0.05, 0.01, 0.001))

# Table 2b
stargazer(between1, between2,
          title="Determinants of the Policy Mix (within models)", 
          align=F, 
          dep.var.labels=c("DV: Policy Mix"), 
          covariate.labels=c("Welfare generosity", "Unemployment"),  
          no.space=TRUE, 
          dep.var.caption="", 
          model.numbers=T,
          star.cutoffs = c(0.05, 0.01, 0.001))

# Table A2
stargazer(within1, within3, within5, within6, within8,
          title="Alternative model specifications (within models)", 
          se = list(coef1[,2],coef3[,2],coef5[,2],coef6[,2],coef8[,2]),
          align=F, 
          dep.var.labels=c("DV: Policy Mix"), 
          covariate.labels=c("EU-membership", "Radical-right vote share", "Radical-right seat share","Left government", "Right government",  "Unemployment", "Time trend", "Welfare generosity", "Net migration"),  
          no.space=TRUE, 
          dep.var.caption="", 
          model.numbers=T,
          star.cutoffs = c(0.05, 0.01, 0.001))

# Table A3
stargazer(between3, between4,
          title="Alternative model specifications (between models)", 
          align=F, 
          dep.var.labels=c("DV: Policy Mix"), 
          covariate.labels=c("Social-democratic regime", "Liberal regime", "Conservative regime","Southern regime", "Welfare generosity",  "EU-membership", "Radical-right strength", "Left government", "Right government", "Unemployment"),  
          no.space=TRUE, 
          dep.var.caption="", 
          model.numbers=T,
          star.cutoffs = c(0.05, 0.01, 0.001))


### Analysing the immigration policy mix with party positions (Dancygier/Margalit-Dataset)

dama <- read.dta("position_dataset.dta")

## calculate preferences on immigration policy mix: positive value=labour-favoribility
dama$mix <- dama$jobs_netsent - dama$asylum_refugees_netsent

# Figure 4
par (mar=c(4,3,2,1), mgp=c(2,.7,0), tck=-.01, las=1, bty="l") # 
par(mfrow = c(2,2))
boxplot(dama$asylum_refugees_netsent[dama$leftparty==1], dama$asylum_refugees_netsent[dama$rightparty==1], dama$asylum_refugees_netsent[dama$farright==1], ylim=c(-1.25,1.2), frame=F, names=c("centre-left", "centre-right", "radical-right"), border=F,  col=c("gray70", "grey50", "grey20"), ylab="Net sentiment" , main="Position asylum")
abline(h=0, lty=2, col="lightgray")
text(2,1.2, "more positive")
arrows(x0=2, y0=0.9, y1=1.1, lwd=1, length=0.07)
text(2,-1.2, "more negative")
arrows(x0=2, y0=-0.9, y1=-1.1, lwd=1, length=0.07)
boxplot(dama$jobs_netsent[dama$leftparty==1], dama$jobs_netsent[dama$rightparty==1], dama$jobs_netsent[dama$farright==1], ylim=c(-1.25,1.2), frame=F, names=c("centre-left", "centre-right", "radical-right"), border=F,  col=c("gray70", "grey50", "grey20"), ylab="Net sentiment" , main="Position labour")
abline(h=0, lty=2, col="lightgray")
text(2,1.2, "more positive")
arrows(x0=2, y0=0.9, y1=1.1, lwd=1, length=0.07)
text(2,-1.2, "more negative")
arrows(x0=2, y0=-0.9, y1=-1.1, lwd=1, length=0.07)
boxplot(dama$mix[dama$leftparty==1], dama$mix[dama$rightparty==1], dama$mix[dama$farright==1], ylim=c(-1.25,1.2), frame=F, names=c("centre-left", "centre-right", "radical-right"), border=F,  col=c("gray70", "grey50", "grey20"), ylab="Mix preference" , main="Preference immigration mix (across parties)")
abline(h=0, lty=2, col="lightgray")
text(2,1.2, "prefer labour")
arrows(x0=2, y0=0.9, y1=1.1, lwd=1, length=0.07)
text(2,-1.2, "prefer asylum")
arrows(x0=2, y0=-0.9, y1=-1.1, lwd=1, length=0.07)
boxplot(dama$mix[dama$year<1990], dama$mix[dama$year>1989 & dama$year<2000], dama$mix[dama$year>1999], ylim=c(-1.75,1.25), frame=F, names=c("1980s", "1990s", "2000s"), border=F,  col=c("gray70", "grey50", "grey20"), ylab="Mix preference" , main="Preference immigration mix (across time)")
abline(h=0, lty=2, col="lightgray")
text(2,1.2, "prefer labour")
arrows(x0=2, y0=0.9, y1=1.1, lwd=1, length=0.07)
text(2,-1.7, "prefer asylum")
arrows(x0=2, y0=-1.4, y1=-1.6, lwd=1, length=0.07)

# Figure A2
par (mar=c(4,3,2,1), mgp=c(2,.7,0), tck=-.01, las=1, bty="l") # 
par(mfrow = c(2,3))
boxplot(dama$asylum_refugees_netsent[dama$year<1990], dama$asylum_refugees_netsent[dama$year>1989 & dama$year<2000], dama$asylum_refugees_netsent[dama$year>1999], ylim=c(-1.75,1.25), frame=F, names=c("1980s", "1990s", "2000s"), border=F,  col=c("gray70", "grey50", "grey20"), ylab="Net sentiment" , main="Asylum position")
#mtext("Government ideology", side=1, adj=0.5, line=2.4, cex=1, font=1); 
abline(h=0, lty=2, col="lightgray")
text(2,1.2, "more positive")
arrows(x0=2, y0=0.9, y1=1.1, lwd=1, length=0.07)
text(2,-1.7, "more negative")
arrows(x0=2, y0=-1.4, y1=-1.6, lwd=1, length=0.07)
boxplot(dama$jobs_netsent[dama$year<1990], dama$jobs_netsent[dama$year>1989 & dama$year<2000], dama$jobs_netsent[dama$year>1999], ylim=c(-1.75,1.25), frame=F, names=c("1980s", "1990s", "2000s"), border=F,  col=c("gray70", "grey50", "grey20"), ylab="Net sentiment" , main="Labour position")
#mtext("Government ideology", side=1, adj=0.5, line=2.4, cex=1, font=1); 
abline(h=0, lty=2, col="lightgray")
text(2,1.2, "more positive")
arrows(x0=2, y0=0.9, y1=1.1, lwd=1, length=0.07)
text(2,-1.7, "more negative")
arrows(x0=2, y0=-1.4, y1=-1.6, lwd=1, length=0.07)
boxplot(dama$mix[dama$year<1990], dama$mix[dama$year>1989 & dama$year<2000], dama$mix[dama$year>1999], ylim=c(-1.75,1.25), frame=F, names=c("1980s", "1990s", "2000s"), border=F,  col=c("gray70", "grey50", "grey20"), ylab="Mix preference" , main="Preference immigration mix")
abline(h=0, lty=2, col="lightgray")
text(2,1.2, "prefer labour")
arrows(x0=2, y0=0.9, y1=1.1, lwd=1, length=0.07)
text(2,-1.7, "prefer asylum")
arrows(x0=2, y0=-1.4, y1=-1.6, lwd=1, length=0.07)
boxplot(dama$mix[dama$leftparty==1 & dama$year<1990], dama$mix[dama$leftparty==1 & dama$year>1989 & dama$year<2000], dama$mix[dama$leftparty==1 & dama$year>1999], ylim=c(-2,1.25), frame=F, names=c("1980s", "1990s", "2000s"), border=F,  col=c("gray70", "grey50", "grey20"), ylab="Mix preference" , main="Centre-left parties")
abline(h=0, lty=2, col="lightgray")
text(2,1.2, "prefer labour")
arrows(x0=2, y0=0.9, y1=1.1, lwd=1, length=0.07)
text(2,-2, "prefer asylum")
arrows(x0=2, y0=-1.7, y1=-1.9, lwd=1, length=0.07)
boxplot(dama$mix[dama$rightparty==1 & dama$year<1990], dama$mix[dama$rightparty==1 & dama$year>1989 & dama$year<2000], dama$mix[dama$rightparty==1 & dama$year>1999], ylim=c(-2,1.25), frame=F, names=c("1980s", "1990s", "2000s"), border=F,  col=c("gray70", "grey50", "grey20"), ylab="Mix preference" , main="Centre-right parties")
abline(h=0, lty=2, col="lightgray")
text(2,1.2, "prefer labour")
arrows(x0=2, y0=0.9, y1=1.1, lwd=1, length=0.07)
text(2,-2, "prefer asylum")
arrows(x0=2, y0=-1.7, y1=-1.9, lwd=1, length=0.07)
boxplot(dama$mix[dama$farright==1 & dama$year<1990], dama$mix[dama$farright==1 & dama$year>1989 & dama$year<2000], dama$mix[dama$farright==1 & dama$year>1999], ylim=c(-2,1.25), frame=F, names=c("1980s", "1990s", "2000s"), border=F,  col=c("gray70", "grey50", "grey20"), ylab="Mix preference" , main="Radical-right parties")
abline(h=0, lty=2, col="lightgray")
text(2,1.2, "prefer labour")
arrows(x0=2, y0=0.9, y1=1.1, lwd=1, length=0.07)
text(2,-2, "prefer asylum")
arrows(x0=2, y0=-1.7, y1=-1.9, lwd=1, length=0.07)

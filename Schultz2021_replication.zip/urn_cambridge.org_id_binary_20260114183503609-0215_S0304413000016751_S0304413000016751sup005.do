*******************************************************************************************************
* 	REPLICATION FILE FOR FIGURE 5, FIGURE 6 & FIGURE A4
*
*	EXPLAINING THE IMMIGRATION POLICY MIX: COUNTRIES' RELATIVE OPENNESS TO ASYLUM AND LABOUR MIGRATION
*	Authors: Caroline Schultz, Philipp Lutz & Stephan Simon
*******************************************************************************************************

set more off
set scheme plotplain // ssc install blindschemes (Bischof 2016)
				
******************************************************
*	FIGURE 5
******************************************************
preserve
drop if country == "Chile" | country == "Czech Republic" | country == "Estonia" | ///
		country == "Hungary" | country == "Iceland" | country == "Israel" | country == "Luxembourg" | ///
		country == "Mexico" | country == "Poland" | country == "Slovakia" | country == "Turkey" | ///
		country == "Korea" | country == "Portugal" | country == "Spain" | country == "Switzerland"

collapse (mean) mtotgen = totgen (mean) mmix = mix, by(cntry)
sort cntry
twoway  (scatter mmix mtotgen, mlabel(cntry)) ///
		(lfitci mmix mtotgen, ciplot(rline) clpattern(solid) alpattern(dash)), ///
		xtitle("Welfare generosity", size(small)) ytitle("Immigration policy mix", size(small)) ///
		ylabel(.1 "0.1" 0 "0" -.1 "-0.1" -.2 "-0.2" -.3 "-0.3" -.4 "-0.4", labsize(small) nogrid)  yline(0) ///	
		xlabel(, nogrid) ///
		legend(label(1 "Country means") ring(1) position(3)) ///
		scale(1.6)
		
pwcorr mmix mtotgen, sig // Pearson correlation
		
graph save Graph "Figure_5", replace
restore

******************************************************
*	FIGURE 6
******************************************************
// Figure 6a
preserve
xtset country_nr year
xtreg mix eu rrpp_vote gov_left2 gov_right2 unemp, fe cluster(country_nr) 
margins, at(eu=(2 1))
marginsplot, xlabel(, nogrid labsize(small)) ylabel(, nogrid labsize(small)) ///
			plot1opts(lwidth(thick)) ///
			ytitle("Policy mix", size(small)) ///
			title("{bf:6a. EU membership}", size(msmall) span justification(left)) ///
				addplot(hist eu if unemp!=., below percent ///
				yaxis(2) ///
				yscale(alt lcolor() axis(2)) ///
				fcolor(none) ///
				ytitle("Percent", axis(2) size(small)) ///
				xtitle("EU membership", size(small)) ///
				xlabel(2 1) ///
				ylabel(0 "0" -.05 "-0.05" -.1 "-0.1" -.15 "-0.15" -.2 "-0.2") ///
				legend(off))
graph save Graph "6a", replace 
restore

// Figure 6b
preserve
xtset country_nr year
xtreg mix eu rrpp_vote gov_left2 gov_right2 unemp, fe cluster(country_nr) 
margins, at(rrpp_vote=(0(5)40.4))
marginsplot, xlabel(, nogrid labsize(small)) ylabel(, nogrid labsize(small)) ///
			plot1opts(lwidth(thick)) ///
			recast(line) recastci(rline) ciopts(lpattern(dash)) yline(0) ///
			ytitle("Policy mix", size(small)) ///
			title("{bf:6b. Radical right vote share}", size(msmall) span justification(left)) ///
				addplot(hist rrpp_vote if unemp!=., below percent ///
				yaxis(2) ///
				yscale(alt lcolor() axis(2)) ///
				fcolor(none) ///
				ytitle("Percent", axis(2) size(small)) ///
				xtitle("Radical right vote share", size(small)) ///
				ylabel(.3 "0.3" .2 "0.2" .1 "0.1" 0 "0" -.1 "-0.1" -.2 "-0.2") ///
				legend(off))
graph save Graph "6b", replace
restore

graph combine "6a" "6b", col(2) scale(2.3) ysize(2) xsize(6)
graph save Graph "Figure_6", replace

******************************************************
*	FIGURE A4
******************************************************
alpha asylum labor, gen(asyllab)

preserve
collapse (mean) mmix = mix (mean) masyllab = asyllab, by(cntry)

twoway  (scatter mmix masyllab, mlabel(cntry)) ///
		(lfitci mmix masyllab, ciplot(rline) clpattern(solid) alpattern(dash)), ///
		xtitle("Immigration policy restrictiveness", size(small)) ytitle("Immigration policy mix", size(small)) ///
		ylabel(.4 "0.4" .3 "0.3" .2 "0.2" .1 "0.1" 0 "0" -.1 "-0.1" -.2 "-0.2" -.3 "-0.3" -.4 "-0.4" -.5 "-0.5" -.6 "-0.6", labsize(small) nogrid)  yline(0) ///
		xlabel(.3 "0.3" .4 "0.4" .5 "0.5" .6 "0.6" .7 "0.7" .8 "0.8", labsize(small) nogrid) ///
		legend(label(1 "Country means")ring(1) position(3)) ///
		scale(1.4)

pwcorr mmix masyllab, sig // Pearson correlation
		
graph save Graph "Figure_A4", replace
restore

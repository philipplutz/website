######################3
### Replication code
### Do immigrants at bay keep the xenophobes away? Post-entry rights and public opposition to immigrant admission 
### European Political Science Review 2024
### Author: Philipp Lutz


### load packages
library(foreign)
library(ggpubr)
library(gridExtra)
library(lmtest)
library(sandwich)
library(coefplot)
library(sjPlot)
library(ggplot2)
library(stargazer)
library(hrbrthemes)
library(expss)


### load datasets
dataset <- read.dta("dataset.dta") #
dataset_us <- read.dta("dataset_us.dta") #
dataset_us_resample <- read.dta("dataset_us_resample.dta") #
dataset_ch <- read.dta("dataset_ch.dta") #
dataset_ch_resample <- read.dta("dataset_ch_resample.dta") #

# descriptive plots
hist1 <- ggplot(dataset_us, aes(x=outcome)) + geom_histogram(binwidth=1, colour="white") + ggtitle("United States") + xlab("Likelihood of immigrant admission") + ylab("Frequencies (observations)") + theme_ipsum() + geom_vline(xintercept=mean(dataset_us$outcome, na.rm=T), linetype="dashed", color = "red")
hist2 <- ggplot(dataset_ch, aes(x=outcome)) + geom_histogram(binwidth=1, colour="white") + ggtitle("Switzerland") + xlab("Likelihood of immigrant admission") + ylab("Frequencies (observations)") + theme_ipsum() + geom_vline(xintercept=mean(dataset_ch$outcome, na.rm=T), linetype="dashed", color = "red")

mean(dataset_us$outcome, na.rm=T) # 
mean(dataset_ch$outcome, na.rm=T) #
sd(dataset_us$outcome, na.rm=T) # 
sd(dataset_ch$outcome, na.rm=T) # 
mean_resp_us <- aggregate(dataset_us$outcome, by=list(dataset_us$ResponseId), FUN=mean, na.rm=T)
mean(mean_resp_us$x) # 
sd(mean_resp_us$x) # 
mean_resp_ch <- aggregate(dataset_ch$outcome, by=list(dataset_ch$ResponseId), FUN=mean, na.rm=T)
mean(mean_resp_ch$x) 
sd(mean_resp_ch$x) # 

hist3 <- ggplot(mean_resp_us, aes(x=x)) + geom_histogram(binwidth=1, colour="white") + ggtitle("United States") + xlab("Likelihood of immigrant admission") + ylab("Frequencies (respondents)") + theme_ipsum() + geom_vline(xintercept=mean(mean_resp_us$x, na.rm=T), linetype="dashed", color = "red")
hist4 <- ggplot(mean_resp_ch, aes(x=x)) + geom_histogram(binwidth=1, colour="white") + ggtitle("United States") + xlab("Likelihood of immigrant admission") + ylab("Frequencies (respondents)") + theme_ipsum() + geom_vline(xintercept=mean(mean_resp_ch$x, na.rm=T), linetype="dashed", color = "red")

jpeg("figure_A1.jpeg", width = 1000, height = 700)
ggarrange(hist1, hist2, hist3, hist4, ncol = 2, nrow = 2)
dev.off()

## estimate base models
reg1a <- lm(outcome ~ age + gender + family + nationality + education + benefits + permit, data=dataset_us) #
coeftest(reg1a, vcov = vcovCL, cluster = ~ResponseId)
se1a <- coeftest(reg1a, vcov = vcovCL, cluster = ~ResponseId)[,2]
reg2a <- lm(outcome ~ age + gender  + family  + nationality + education + benefits + permit, data=dataset_ch) #
coeftest(reg2a, vcov = vcovCL, cluster = ~ResponseId)
se2a <- coeftest(reg2a, vcov = vcovCL, cluster = ~ResponseId)[,2]

jpeg("figure1.jpeg", 
     width = 11, height = 3.5, units = "in", res=800)
par (mar=c(3.2,7,1.2,1.2), mgp=c(2,.7,0), tck=-.01, las=1)
par(mfrow=c(1,2))
plot1 <- coefplot(reg1a, alpha=0.05, title="United States", innerCI = 1.645, outerCI = 1.96, coefficients=c("ageyoung", "genderwoman", "familysingle", "educationhigh", "nationalityCanada", "benefitsno", "permittemporary"), ylim=c(-0.4,1),newNames=c("ageyoung"="Age (young)", "genderwoman"="Gender (woman)", "familysingle"="Family status (single)", "educationhigh"="Education (high)", "nationalityCanada"="Nationality (close)", "benefitsno"="Welfare rights (no)", "permittemporary"="Residence rights (temporary)"), sd=se1a)  + ylab("") + xlab("Estimated coefficient") + theme_classic() 
plot2 <- coefplot(reg2a, alpha=0.05, title="Switzerland", innerCI = 1.645, outerCI = 1.96, coefficients=c("ageyoung", "genderwoman", "familysingle", "educationhigh", "nationalityGermany", "benefitsno", "permittemporary"), ylim=c(-0.4,1), newNames=c("ageyoung"="Age (young)", "genderwoman"="Gender (woman)", "familysingle"="Family status (single)", "educationhigh"="Education (high)", "nationalityGermany"="Nationality (close)", "benefitsno"="Welfare rights (no)", "permittemporary"="Residence rights (temporary)"), sd=se2a)  + ylab("")  + xlab("Estimated coefficient") + theme_classic() 
grid.arrange(plot1, plot2, nrow = 1)
dev.off()

## Alternative model specifications

# models with control variables
reg1a_control <- lm(outcome ~ age + gender + family + nationality + education + benefits + permit + sex_resp + age_resp + edu_resp, data=dataset_us) # control variables: + sex_resp + age_resp + edu_resp
coeftest(reg1a_control, vcov = vcovCL, cluster = ~ResponseId)
se1a_control <- coeftest(reg1a_control, vcov = vcovCL, cluster = ~ResponseId)[,2]
reg2a_control <- lm(outcome ~ age + gender  + family  + nationality + education + benefits + permit + sex_resp + age_resp + edu_resp, data=dataset_ch) # control variables: + sex_resp + age_resp + edu_resp
coeftest(reg2a_control, vcov = vcovCL, cluster = ~ResponseId)
se2a_control <- coeftest(reg2a_control, vcov = vcovCL, cluster = ~ResponseId)[,2]

# models on the full sample
reg <- lm(outcome ~ age + gender + family + nationality1 + education + benefits + permit, data=dataset) #
coeftest(reg, vcov = vcovCL, cluster = ~ResponseId)
se <- coeftest(reg, vcov = vcovCL, cluster = ~ResponseId)[,2]
reg_int <- lm(outcome ~ age + gender + family + nationality1 + education + benefits*country + permit*country, data=dataset) #
coeftest(reg_int, vcov = vcovCL, cluster = ~ResponseId)
se_int <- coeftest(reg_int, vcov = vcovCL, cluster = ~ResponseId)[,2]
reg_int_lrs <- lm(outcome ~ age + gender + family + nationality1 + education + benefits*lrs + permit*lrs + country, data=dataset) #
coeftest(reg_int_lrs, vcov = vcovCL, cluster = ~ResponseId)
se_int_lrs <- coeftest(reg_int_lrs, vcov = vcovCL, cluster = ~ResponseId)[,2]
reg_int_immig <- lm(outcome ~ age + gender + family + nationality1 + education + benefits*immig + permit*immig + country, data=dataset) #
coeftest(reg_int_immig, vcov = vcovCL, cluster = ~ResponseId)
se_int_immigt <- coeftest(reg_int_immig, vcov = vcovCL, cluster = ~ResponseId)[,2]
reg_int_rights <- lm(outcome ~ age + gender + family + nationality1 + education + benefits*permit + country, data=dataset) #
coeftest(reg_int_rights, vcov = vcovCL, cluster = ~ResponseId)
se_int_rights <- coeftest(reg_int_rights, vcov = vcovCL, cluster = ~ResponseId)[,2]
reg_int_edu <- lm(outcome ~ age + gender + family + nationality1 + benefits*education + permit*education + country, data=dataset) #
coeftest(reg_int_edu, vcov = vcovCL, cluster = ~ResponseId)
se_int_edu <- coeftest(reg_int_edu, vcov = vcovCL, cluster = ~ResponseId)[,2]
reg_int_nat <- lm(outcome ~ age + gender + family + education + benefits*nationality1 + permit*nationality1 + country, data=dataset) #
coeftest(reg_int_nat, vcov = vcovCL, cluster = ~ResponseId)
se_int_nat <- coeftest(reg_int_nat, vcov = vcovCL, cluster = ~ResponseId)[,2]

# resampling
reg_rs1 <- lm(outcome ~ age + gender + family + nationality + education + benefits + permit, data=dataset_us_resample) #
coeftest(reg_rs1, vcov = vcovCL, cluster = ~ResponseId)
se_rs1 <- coeftest(reg_rs1, vcov = vcovCL, cluster = ~ResponseId)[,2]
reg_rs2 <- lm(outcome ~ age + gender  + family  + nationality + education + benefits + permit, data=dataset_ch_resample) #
coeftest(reg_rs2, vcov = vcovCL, cluster = ~ResponseId)
se_rs2 <- coeftest(reg_rs2, vcov = vcovCL, cluster = ~ResponseId)[,2]

# Table A1
stargazer(reg1a,reg2a,reg_rs1,reg_rs2,reg1a_control,reg2a_control,
          title="Panel regression estimates", 
          align=F, 
          dep.var.labels=c("Likelihood of immigrant admission"), 
          covariate.labels=c("Age (young)", "Gender (woman)", "Family status (single)",  "Nationality (close)","Nationality (close)", "Education (high)", "Welfare rights (no)", "Residence rights (no)", "Gender (respondent)", "Age (respondent)", "Education (respondent)"),  
          no.space=TRUE, 
          dep.var.caption="", 
          se = list(se1a,se2a,se_rs1, se_rs2, se1a_control,se2a_control),
          model.numbers=T,
          star.cutoffs = c(0.05, 0.01, 0.001))

# Table A2
stargazer(reg, reg_int,
          title="Panel regression estimates", 
          align=F, 
          dep.var.labels=c("Likelihood of immigrant admission"), 
          covariate.labels=c("Age (young)", "Gender (woman)", "Family status (single)",  "Nationality (close)","Education (high)", "Welfare rights (no)", "Countryt (US)", "Residence rights (no)", "Welfare rights * US", "Residence rights * US"),  
          no.space=TRUE, 
          dep.var.caption="", 
          se = list(se,se_int),
          model.numbers=T,
          star.cutoffs = c(0.05, 0.01, 0.001))

# causal interaction models
mod1 <- lm(outcome ~ permit*nationality, data=dataset_ch)
coeftest(mod1, vcov = vcovCL, cluster = ~ResponseId)
se_mod1 <- coeftest(mod1, vcov = vcovCL, cluster = ~ResponseId)[,2] # 
mod2 <- lm(outcome ~ benefits*education, data=dataset_ch)
coeftest(mod2, vcov = vcovCL, cluster = ~ResponseId)
se_mod2 <- coeftest(mod2, vcov = vcovCL, cluster = ~ResponseId)[,2]
mod3 <- lm(outcome ~ benefits*nationality, data=dataset_ch)
coeftest(mod3, vcov = vcovCL, cluster = ~ResponseId)
se_mod3 <- coeftest(mod3, vcov = vcovCL, cluster = ~ResponseId)[,2]
mod4 <- lm(outcome ~ permit*education, data=dataset_ch)
coeftest(mod4, vcov = vcovCL, cluster = ~ResponseId)
se_mod4 <- coeftest(mod4, vcov = vcovCL, cluster = ~ResponseId)[,2]
mod5 <- lm(outcome ~ permit*nationality, data=dataset_us)
coeftest(mod5, vcov = vcovCL, cluster = ~ResponseId) # 
se_mod5 <- coeftest(mod5, vcov = vcovCL, cluster = ~ResponseId)[,2] # 
mod6 <- lm(outcome ~ benefits*education, data=dataset_us)
coeftest(mod6, vcov = vcovCL, cluster = ~ResponseId)
se_mod6 <- coeftest(mod6, vcov = vcovCL, cluster = ~ResponseId)[,2] # 
mod7 <- lm(outcome ~ benefits*nationality, data=dataset_us)
coeftest(mod7, vcov = vcovCL, cluster = ~ResponseId)
se_mod7 <- coeftest(mod7, vcov = vcovCL, cluster = ~ResponseId)[,2] # 
mod8 <- lm(outcome ~ permit*education, data=dataset_us)
coeftest(mod8, vcov = vcovCL, cluster = ~ResponseId)
se_mod8 <- coeftest(mod8, vcov = vcovCL, cluster = ~ResponseId)[,2] # 

jpeg("figure2a.jpeg", 
     width = 15, height = 4, units = "in", res=800)
theme_set(theme_sjplot())
p1 <- plot_model(mod5, type = "int", se=se_mod5, title="Residence rights",dodge = .5, axis.title=c("", "Coefficient"))
p2 <- plot_model(mod6, type = "int", se=se_mod6, title="Welfare rights",axis.title=c("", "Coefficient"),dodge = .5)
p3 <- plot_model(mod7, type = "int", se=se_mod7, title="Welfare rights",axis.title=c("", "Coefficient"),dodge = .5)
p4 <- plot_model(mod8, type = "int", se=se_mod8, title="Residence rights",axis.title=c("", "Coefficient"),dodge = .5)
plot1 <- ggarrange(p1,p4,p3,p2, ncol = 4, nrow = 1)
annotate_figure(plot1, top = text_grob("United States", face = "bold", size = 18))
dev.off()

jpeg("figure2b.jpeg", 
     width = 15, height = 4, units = "in", res=800)
theme_set(theme_sjplot())
p5 <- plot_model(mod1, type = "int", se=se_mod1, title="Residence rights",dodge = .5, axis.title=c("", "Coefficient"))
p6 <- plot_model(mod2, type = "int", se=se_mod2, title="Welfare rights", axis.title=c("", "Coefficient"),dodge = .5)
p7 <- plot_model(mod3, type = "int", se=se_mod3, title="Welfare rights", axis.title=c("", "Coefficient"),dodge = .5)
p8 <- plot_model(mod4, type = "int", se=se_mod4, title="Residence rights", axis.title=c("", "Coefficient"),dodge = .5)
plot1 <- ggarrange(p5,p8,p7,p6, ncol = 4, nrow = 1)
annotate_figure(plot1, top = text_grob("Switzerland", face = "bold", size = 18))
dev.off()

coef_us <- plot_models(mod5,mod7,mod8,mod6, vcov.fun=c(se_mod5,se_mod7,se_mod8,se_mod6), axis.labels=c("welfare access (no) * education (high)", "residence (temporary) * eduction (high)", "welfare access (no) * nationality (Canada)","residence (temporary) * nationality (Canada)"), rm.terms = c("permittemporary", "nationalityCanada", "benefitsno", "educationhigh", "immig"),show.values = TRUE, show.p=T, show.legend=F, colors="black") + theme_ipsum() + ggtitle("United States") + geom_hline(yintercept=0, linetype="dashed", color = "black")
coef_ch <- plot_models(mod1,mod3,mod4,mod2, vcov.fun=c(se_mod1,se_mod3,se_mod4,se_mod2), axis.labels=c("welfare access (no) * education (high)", "residence (temporary) * eduction (high)", "welfare access (no) * nationality (Germany)","residence (temporary) * nationality (Germany)"), rm.terms = c("permittemporary", "nationalityGermany", "benefitsno", "educationhigh", "immig"),show.values = TRUE, show.legend=F, colors="black") + theme_ipsum() + ggtitle("Switzerland") + geom_hline(yintercept=0, linetype="dashed", color = "black")

jpeg("figure_a2.jpeg", width = 1000, height = 400)
ggarrange(coef_us,coef_ch)
dev.off()

# interaction residence rights and welfare rights
reg_int1 <- lm(outcome ~ permit*benefits, data=dataset_ch)
coeftest(reg_int1, vcov = vcovCL, cluster = ~ResponseId)
reg_int2 <- lm(outcome ~ benefits*permit, data=dataset_ch)
coeftest(reg_int2, vcov = vcovCL, cluster = ~ResponseId)
reg_int3 <- lm(outcome ~ permit*benefits, data=dataset_us)
coeftest(reg_int3, vcov = vcovCL, cluster = ~ResponseId)
reg_int4 <- lm(outcome ~ benefits*permit, data=dataset_us)
coeftest(reg_int4, vcov = vcovCL, cluster = ~ResponseId)

# add labels
var_lab(dataset_ch$immig) = "Immigration concern"
var_lab(dataset_us$immig) = "Immigration concern"
var_lab(dataset_ch$lrs) = "Political ideology"
var_lab(dataset_us$lrs) = "Political ideology"
val_lab(dataset_ch$immig) = num_lab("
            0 low
            1 high")

# robustness check: effect heterogeneity
reg_im1 <- lm(outcome ~ permit*immig, data=dataset_us)
coeftest(reg_im1, vcov = vcovCL, cluster = ~ResponseId)
se_im1 <- coeftest(reg_im1, vcov = vcovCL, cluster = ~ResponseId)[,2] # 
reg_im2 <- lm(outcome ~ benefits*immig, data=dataset_us)
coeftest(reg_im2, vcov = vcovCL, cluster = ~ResponseId)
se_im2 <- coeftest(reg_im2, vcov = vcovCL, cluster = ~ResponseId)[,2] # 
reg_lrs1 <- lm(outcome ~ permit*lrs, data=dataset_us)
coeftest(reg_lrs1, vcov = vcovCL, cluster = ~ResponseId)
se_lrs1 <- coeftest(reg_lrs1, vcov = vcovCL, cluster = ~ResponseId)[,2] # 
reg_lrs2 <- lm(outcome ~ benefits*lrs, data=dataset_us)
coeftest(reg_lrs2, vcov = vcovCL, cluster = ~ResponseId)
se_lrs2 <- coeftest(reg_lrs2, vcov = vcovCL, cluster = ~ResponseId)[,2] # 
coefhet1 <- plot_models(reg_im1,reg_im2,reg_lrs1,reg_lrs2, vcov.fun=c(se_im1,se_im2,se_lrs1,se_lrs2), axis.labels=c("welfare access (no) * right-wing orientation", "residence (temporary) * right-wing orientation", "welfare access (no) * high immigration concern","residence (temporary) * high immigration concern"),rm.terms = c("permittemporary", "nationalityGermany", "benefitsno", "lrs", "immig"),show.values = TRUE, show.legend=F, colors="black") + ggtitle("United States") + theme_ipsum() + geom_hline(yintercept=0, linetype="dashed", color = "black")

reg_im3 <- lm(outcome ~ permit*immig, data=dataset_ch)
coeftest(reg_im3, vcov = vcovCL, cluster = ~ResponseId)
se_im3 <- coeftest(reg_im3, vcov = vcovCL, cluster = ~ResponseId)[,2] # 
reg_im4 <- lm(outcome ~ benefits*immig, data=dataset_ch)
coeftest(reg_im4, vcov = vcovCL, cluster = ~ResponseId)
se_im4 <- coeftest(reg_im4, vcov = vcovCL, cluster = ~ResponseId)[,2] # 
reg_lrs3 <- lm(outcome ~ permit*lrs, data=dataset_ch)
coeftest(reg_lrs3, vcov = vcovCL, cluster = ~ResponseId)
se_lrs3 <- coeftest(reg_lrs3, vcov = vcovCL, cluster = ~ResponseId)[,2] # 
reg_lrs4 <- lm(outcome ~ benefits*lrs, data=dataset_ch)
coeftest(reg_lrs4, vcov = vcovCL, cluster = ~ResponseId)
se_lrs4 <- coeftest(reg_lrs4, vcov = vcovCL, cluster = ~ResponseId)[,2] # 
coefhet2 <- plot_models(reg_im3,reg_im4,reg_lrs3,reg_lrs4, vcov.fun=c(se_im3,se_im4,se_lrs3,se_lrs4), axis.labels=c("welfare access (no) * right-wing orientation", "residence (temporary) * right-wing orientation", "welfare access (no) * high immigration concern","residence (temporary) * high immigration concern"),rm.terms = c("permittemporary", "nationalityGermany", "benefitsno", "lrs", "immig"),show.values = TRUE, show.legend=F, colors="black") + theme_ipsum() + ggtitle("Switzerland") + geom_hline(yintercept=0, linetype="dashed", color = "black")

jpeg("figure_a4.jpeg", width = 1000, height = 400)
ggarrange(coefhet1,coefhet2)
dev.off()

jpeg("figure_a3.jpeg", width = 1200, height = 500)
par (mar=c(1,1,1,1), mgp=c(2,.7,0), tck=-.01, las=1)
theme_set(theme_sjplot())
p1 <- plot_model(reg_im1,type="int", se=se_im1, show.values = TRUE,dodge=.5) + ggtitle("United States")  + scale_color_manual(labels = c("low", "high"), values = c("blue", "red")) + ylab("Likelihood of immigrant admission") + xlab("Residence rights")
p2 <- plot_model(reg_im2,type="int", se=se_im2, show.values = TRUE,dodge=.5) + ggtitle("")  + scale_color_manual(labels = c("low", "high"), values = c("blue", "red")) + ylab("Likelihood of immigrant admission")+ xlab("Welfare access")
p3 <- plot_model(reg_lrs1,type="int", se=se_lrs1, show.values = TRUE,dodge=.5) + ggtitle("") + scale_color_manual(labels = c("left-wing", "right-wing"), values = c("blue", "red")) + ylab("Likelihood of immigrant admission") + xlab("Residence rights")
p4 <- plot_model(reg_lrs2,type="int", se=se_lrs2, show.values = TRUE,dodge=.5) + ggtitle("") + scale_color_manual(labels = c("left-wing", "right-wing"), values = c("blue", "red")) + ylab("Likelihood of immigrant admission") + xlab("Welfare access")
p5 <- plot_model(reg_im3,type="int", se=se_im3, show.values = TRUE,dodge=.5) + ggtitle("Switzerland")  + scale_color_manual(labels = c("low", "high"), values = c("blue", "red"))  + ylab("Likelihood of immigrant admission") + xlab("Residence rights")
p6 <- plot_model(reg_im4,type="int", se=se_im4, show.values = TRUE,dodge=.5) + ggtitle("")  + scale_color_manual(labels = c("low", "high"), values = c("blue", "red")) + ylab("Likelihood of immigrant admission") + xlab("Welfare access")
p7 <- plot_model(reg_lrs3,type="int", se=se_lrs3, show.values = TRUE,dodge=.5) + ggtitle("") + scale_color_manual(labels = c("left-wing", "right-wing"), values = c("blue", "red"))  + ylab("Likelihood of immigrant admission") + xlab("Residence rights")
p8 <- plot_model(reg_lrs4,type="int", se=se_lrs4, show.values = TRUE,dodge=.5) + ggtitle("")  + scale_color_manual(labels = c("left-wing", "right-wing"), values = c("blue", "red"))  + ylab("Likelihood of immigrant admission") + xlab("Welfare access")
ggarrange(p1,p2,p3,p4,p5,p6,p7,p8, ncol=4,nrow=2)
dev.off()



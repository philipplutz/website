################
# Public fairness preferences in EU asylum governance

# R code file

# Author: Philipp Lutz
# Date: 26.05.2026

## load packages
required_packages <- c(
  "foreign","ggplot2","dplyr","readxl","hrbrthemes","ggpubr",
  "factoextra","eurostat","tidyr","RColorBrewer","ggmosaic",
  "ComplexUpset","scales","broom","gridExtra","stringr",
  "patchwork","ggcorrplot","sandwich","lme4","lmtest",
  "stargazer","clubSandwich","ggeffects","fixest",
  "marginaleffects","purrr","tibble","forcats",
  "modelsummary","cowplot","magrittr", "texreg",
  "tidyverse", "lavaan"
)

missing <- required_packages[!required_packages %in% installed.packages()[, "Package"]]
if (length(missing) > 0) {
  install.packages(missing)
}

invisible(lapply(required_packages, library, character.only = TRUE))

### load data
dataset <- read.csv("dataset.csv")
dataset_extended <- read.csv("dataset_extended.csv")

### Empirical analysis

## PART I: Grounding fairness judgements

## 1. Evaluation of actual refugee distribution
fairness_perception_by_country <- dataset %>%
  filter(fairness_perc != 4) %>%   # remove neutral observations
  group_by(country) %>%
  summarise(
    Support = mean(fairness_perc > 4) * 100,
    N = n()
  )

## 2. Support of fairness objective
fairness_objective_by_country <- dataset %>%
  filter(fairness_perc != 4) %>%   # remove neutral observations
  group_by(country) %>%
  summarise(
    Support = mean(fairness_objective2 > 4) * 100,
    N = n()
  )

# Create a data frame for plotting
df <- data.frame(
  fairness_objective1 = dataset$fairness_objective1,
  fairness_objective2 = dataset$fairness_objective2
)

# Convert to long format and rename categories for better labels
df_long <- df %>%
  pivot_longer(cols = everything(), names_to = "Objective", values_to = "Score") %>%
  mutate(Objective = recode(Objective,
                            "fairness_objective1" = "Low refugee intakes",
                            "fairness_objective2" = "Fair distribution"))

# Calculate mean score for each Objective
df_means <- df_long %>%
  group_by(Objective) %>%
  summarise(mean_score = mean(Score, na.rm = TRUE))

# Merge means back to original data
df_long <- df_long %>%
  left_join(df_means, by = "Objective")

# Boxplot with gradient fill based on mean score
fig1a <- ggplot(df_long, aes(x = reorder(Objective, -mean_score), y = Score, fill = mean_score)) +
  geom_boxplot(alpha = 0.8, outlier.shape = NA) +
  geom_jitter(width = 0.2, alpha = 0.02) +
  scale_fill_gradient(low = "lightsteelblue", high = "steelblue4") +
  theme_ipsum() +
  ggtitle("A. Univariate distribution") +
  theme(legend.position = "none", 
        plot.title = element_text(size = 14,face="bold"), 
        plot.margin = margin(10, 10, 10, 10),    
        panel.grid.major.x = element_blank(),  
        panel.grid.minor.x = element_blank()) +   
  xlab(NULL) + ylab("Agreement score (1-7 scale)")

## Correlation between fairness and self-interest objective in refugee allocation
cor(df$fairness_objective1, df$fairness_objective2, method = "pearson")  # 0.05
cor(df$fairness_objective1, df$fairness_objective2, method = "spearman") # 0.06

# prepare data for mosaic plot

# Step 1: Recode into 3-point scale
df <- dataset %>%
  mutate(
    obj1_cat = case_when(
      fairness_objective1 %in% 1:3 ~ "Disagree",
      fairness_objective1 == 4     ~ "Neutral",
      fairness_objective1 %in% 5:7 ~ "Agree",
      TRUE                         ~ NA_character_
    ),
    obj2_cat = case_when(
      fairness_objective2 %in% 1:3 ~ "Disagree",
      fairness_objective2 == 4     ~ "Neutral",
      fairness_objective2 %in% 5:7 ~ "Agree",
      TRUE                         ~ NA_character_
    ),
    SupportCategory = case_when(
      obj1_cat == "Agree"   & obj2_cat == "Agree"   ~ "Both supported",
      obj1_cat == "Disagree" & obj2_cat == "Disagree" ~ "Both not supported",
      obj1_cat == "Agree"   & obj2_cat == "Disagree" ~ "Self-interest supported,\nFairness not supported",
      obj1_cat == "Disagree" & obj2_cat == "Agree"   ~ "Self-interest not supported,\nFairness supported",
      obj1_cat == "Neutral" | obj2_cat == "Neutral" ~ "Neutral",
      TRUE ~ "Other"
    ),
    obj1_cat = factor(obj1_cat, levels = c("Disagree", "Neutral", "Agree")),
    obj2_cat = factor(obj2_cat, levels = c("Disagree", "Neutral", "Agree")),
    SupportCategory = factor(SupportCategory, levels = c(
      "Both supported",
      "Both not supported",
      "Self-interest supported,\nFairness not supported",
      "Self-interest not supported,\nFairness supported",
      "Neutral"
    ))
  ) %>%
  filter(!is.na(SupportCategory))

# Create the contingency table with percentages
tab <- table(df$obj1_cat, df$obj2_cat)
tab_prop <- prop.table(tab) * 100  # Convert to percentages

# Convert to data frame for ggplot
df_plot <- as.data.frame(tab_prop)
colnames(df_plot) <- c("obj1", "obj2", "percentage")

# Plot the heatmap
fig1b <- ggplot(df_plot, aes(x = obj2, y = obj1, fill = percentage)) +
  geom_tile(color = "white") +
  scale_fill_gradient(name = "Percent", low = "white", high = "steelblue") +
  geom_text(aes(label = sprintf("%.1f%%", percentage)), size = 3) +
  labs(
    x = "Fairness",
    y = "Self-interest",
    title = "B. Bivariate distribution"
  ) +
  theme_ipsum() +
  theme(legend.position = "right", plot.title = element_text(size = 14,face="bold"), plot.margin = margin(10, 10, 10, 10)) +
  coord_fixed()

png("figure1.png", width = 10, height = 5, units = "in", res = 800)
grid.arrange(fig1a, fig1b, ncol = 2, widths = c(1.2, 1.8))
dev.off()

## Institutional dimension: Support for EU-level refugee distribution

# Recode fairness columns for better display labels
dataset_labeled <- dataset %>%
  mutate(
    fair1 = fairness_procedural1 >= 5,
    fair2 = fairness_procedural2 >= 5,
    fair3 = fairness_procedural3 >= 5
  ) %>%
  rename(
    `EU-level key` = fair1,
    `State choice` = fair2,
    `Refugee choice` = fair3
  )

# Calculate total number of observations for percentage calculation
total_n <- nrow(dataset_labeled)

# Create a custom function to convert counts to percentages
percentage_labeller <- function(x) {
  paste0(round(x/total_n * 100, 1), "%")
}

# Create the UpSet plot with percentages
intersect_cols <- c("EU-level key", "State choice", "Refugee choice")
total_n <- nrow(dataset_labeled)

png("figure2.png", width = 10, height = 5.5, units = "in", res = 800)
upset(
  dataset_labeled,
  intersect_cols,
  name = "Agreement with procedural fairness",
  base_annotations = list(),
  set_sizes = (
    upset_set_size(
      geom = geom_bar(width = 0.6, fill = "steelblue4")
    ) +
      geom_text(
        stat = "count",
        aes(label = paste0(round(after_stat(count)/total_n*100,1), "%")),
        hjust = -0.2,
        color = "white",
        size = 3
      ) +
      labs(x = "Set size (in %)")
  ),
  annotations = list(
    'Intersection size (in %)' = (
      ggplot(mapping = aes(x = intersection)) +
        geom_bar(
          stat = "count",
          width = 0.6,
          fill = "steelblue",
          aes(y = after_stat(count)/total_n)
        ) +
        geom_text(
          stat = "count",
          mapping = aes(
            y = after_stat(count)/total_n,
            label = paste0(round(after_stat(count)/total_n*100,1), "%")
          ),
          vjust = -0.5,
          color = "gray45",
          size = 3
        ) +
        scale_y_continuous(
          breaks = seq(0.05, 0.25, 0.05),
          labels = percent_format(accuracy = 1),
          expand = expansion(mult = c(0,0.1))
        ) +
        labs(y = "Intersection size (in %)") +
        theme(
          axis.text.x = element_blank(),
          axis.ticks.x = element_blank(),
          panel.grid.major.x = element_blank(),
          panel.grid.minor.x = element_blank()
        )
    )
  )
)
dev.off()

# Create dataframe for procedural fairness
procedural_items <- c("fairness_procedural1", "fairness_procedural2", 
                      "fairness_procedural3", "fairness_procedural4")
procedural_labels <- c("EU-level key", "State choice", "Refugee choice", "First arrival")

percentage_by_country_no_neutral <- function(var, data) {
  data %>%
    filter(!is.na(.data[[var]]), !is.na(country), .data[[var]] != 4) %>%
    group_by(country) %>%
    summarise(Percentage = mean(.data[[var]] >= 5, na.rm = TRUE) * 100) %>%
    mutate(Item = var)
}
df_procedural_country <- bind_rows(
  lapply(procedural_items, percentage_by_country_no_neutral, data = dataset)
) %>%
  left_join(data.frame(Item = procedural_items, Criterion = procedural_labels), by = "Item")

# Specify the desired order
df_procedural_country$country <- factor(
  df_procedural_country$country,
  levels = c("Denmark", "Germany", "Italy", "Greece", "Poland", "Hungary")
)
criterion_levels <- c( "EU-level key", "State choice", "Refugee choice","First arrival")  #
df_procedural_country <- df_procedural_country %>%
  mutate(Criterion = factor(Criterion, levels = criterion_levels))

# Compute average per Criterion
avg_per_criterion <- df_procedural_country %>%
  group_by(Criterion) %>%
  summarise(avg = mean(Percentage))
# Get x positions for each Criterion
x_positions <- 1:length(unique(df_procedural_country$Criterion))
names(x_positions) <- unique(df_procedural_country$Criterion)
avg_per_criterion <- avg_per_criterion %>%
  mutate(x = x_positions[Criterion])

png("figure3.png", width = 9, height = 5.5, units = "in", res = 800)
ggplot(df_procedural_country, aes(x = country, y = Percentage, fill = Criterion)) +
  geom_col(position = position_dodge2(padding = 0.08), width = 0.75) +   # gaps between bars, groups tighter
  geom_text(aes(label = round(Percentage, 0)),
            position = position_dodge2(width = 0.75, padding = 0.08),    # must match exactly
            vjust = -0.5, size = 3.5) +
  scale_y_continuous(limits = c(0, 100), expand = expansion(mult = c(0, 0.05))) +
  scale_fill_manual(values = c("steelblue4", "steelblue", "slateblue3", 
                               "lightsteelblue")) +
  labs(x = NULL, y = "Share of respondents (in %)", fill = "") +
  theme_ipsum(base_size = 14) +
  theme(
    legend.position = c(0.5, 1.035),          # centered horizontally, near top inside panel
    legend.justification = c(0.5, 1),         # anchor legend box at its top center
    legend.direction = "horizontal",
    legend.background = element_rect(fill = alpha("white", 0.75), color = NA),
    legend.key.size = unit(0.4, "cm"),
    legend.title = element_text(size = 9),
    legend.text = element_text(size = 14),
    panel.grid.major.x = element_blank(),
    panel.grid.minor.x = element_blank(),
    plot.margin = margin(t = 10, r = 10, b = 0, l = 10),
    axis.text.x = element_text(margin = margin(t = 10))
  ) +
  guides(fill = guide_legend(nrow = 1, byrow = TRUE))
dev.off()

### PART II: Descriptive support for distributive fairness principles

# Distributive Fairness
distributive_items <- c("fairness_distributive1", "fairness_distributive2", 
                        "fairness_distributive3", "fairness_distributive4", 
                        "fairness_distributive5")
dataset_long <- dataset %>%
  pivot_longer(cols = starts_with("fairness_distributive"),
               names_to = "Criterion",
               values_to = "Score") %>%
  mutate(Criterion = recode(Criterion,
                            "fairness_distributive1" = "Population",
                            "fairness_distributive2" = "Wealth",
                            "fairness_distributive3" = "Unemployment",
                            "fairness_distributive4" = "Costs",
                            "fairness_distributive5" = "Previous intakes"))

percentage_above_4 <- function(x) {
  mean(x > 4, na.rm = TRUE) * 100  # Convert to percentage
}

percentage <- function(x) {
  mean(x > 4, na.rm = TRUE) * 100  # Convert to percentage
}

df_distributive <- dataset_long %>%
  filter(Score != 4) %>%   # drop values == 4
  group_by(Criterion) %>%
  summarize(Percentage = percentage_above_4(Score), .groups = "drop") %>%
  arrange(desc(Percentage))

# Determine order from decreasing Percentage
df_distributive$Criterion <- factor(
  df_distributive$Criterion,
  levels = df_distributive$Criterion[order(-df_distributive$Percentage)]
)

fig4a <- ggplot(df_distributive, aes(x = reorder(Criterion, -Percentage), y = Percentage, fill = Criterion)) +
  geom_col(width = 0.6) +
  geom_text(aes(label = round(Percentage, 0)), vjust = -0.5, size = 4) +
  scale_y_continuous(limits = c(0, 100), expand = expansion(mult = c(0, 0.05))) +
  scale_fill_manual(values = c("steelblue4", "steelblue", "slateblue3",
                               "lightsteelblue", "skyblue3")) +
  labs(title = "A. Overall support",
       x = NULL, y = "Support (in %)") +
  theme_ipsum(base_size = 14) +
  theme(axis.text.x = element_text(angle = 45, hjust = 1),
        panel.grid.major.x = element_blank(),
        legend.position = "none",
        plot.margin = margin(t = 10, r = 10, b = 0, l = 10))

distributive_labels <- c("Population", "Wealth", "Unemployment", "Costs", "Previous Intakes")
df_distributive_country <- bind_rows(
  lapply(distributive_items, percentage_by_country_no_neutral, data = dataset)
) %>%
  left_join(data.frame(Item = distributive_items, Criterion = distributive_labels), by = "Item")

df_distributive_country$Criterion <- factor(
  df_distributive_country$Criterion,
  levels = c("Wealth", "Costs", "Previous Intakes", "Unemployment", "Population")
)

df_distributive_country$country <- factor(
  df_distributive_country$country,
  levels = c("Denmark", "Germany", "Italy", "Greece", "Poland", "Hungary")
)

fig4b <- ggplot(df_distributive_country,
                          aes(x = country,
                              y = Percentage,
                              fill = Criterion)) +
  geom_col(position = position_dodge2(padding = 0.08), width = 0.75) +   # gaps between bars, groups tighter
  geom_text(aes(label = round(Percentage, 0)),
            position = position_dodge2(width = 0.75, padding = 0.08),    # must match exactly
            vjust = -0.5, size = 3.5) +
  scale_y_continuous(limits = c(0, 100), expand = expansion(mult = c(0, 0.05))) +
  scale_fill_manual(values = c("steelblue4", "steelblue", "slateblue3",
                               "lightsteelblue", "skyblue3")) +
  labs(title = "B. Support by country",
       x = NULL, y = "Support (in %)", fill = "") +
  theme_ipsum(base_size = 14) +
  theme(
    legend.position = c(0.5, 1.03),          # centered horizontally, near top inside panel
    legend.justification = c(0.5, 1),         # anchor legend box at its top center
    legend.direction = "horizontal",
    legend.background = element_rect(fill = alpha("white", 0.75), color = NA),
    legend.key.size = unit(0.4, "cm"),
    legend.title = element_text(size = 9),
    legend.text = element_text(size = 14),
    panel.grid.major.x = element_blank(),
    panel.grid.minor.x = element_blank(),
    plot.margin = margin(t = 10, r = 10, b = 0, l = 10),
    axis.text.x = element_text(margin = margin(t = 10))
  ) +
  guides(fill = guide_legend(nrow = 1, byrow = TRUE))

# 6. Save
png("figure4.png", width = 14, height = 6, units = "in", res = 800)
fig4a + fig4b +
  plot_layout(widths = c(0.5, 2)) &
  theme(plot.margin = margin(t = 10, r = 10, b = 0, l = 10))
dev.off()

# Fit the distributive fairness models with country fixed effects
model1 <- lm(fairness_distributive1 ~ fairness_objective1 + fairness_objective2 + as.factor(country), data = dataset)
model2 <- lm(fairness_distributive2 ~ fairness_objective1 + fairness_objective2 + as.factor(country), data = dataset)
model3 <- lm(fairness_distributive3 ~ fairness_objective1 + fairness_objective2 + as.factor(country), data = dataset)
model4 <- lm(fairness_distributive4 ~ fairness_objective1 + fairness_objective2 + as.factor(country), data = dataset)
model5 <- lm(fairness_distributive5 ~ fairness_objective1 + fairness_objective2 + as.factor(country), data = dataset)

# Function to create predictions manually
create_predictions <- function(model, var_name, var_values, model_name, predictor_name) {
  # Get the most common country for prediction
  most_common_country <- names(sort(table(dataset$country), decreasing = TRUE))[1]
  
  # Create prediction data frame
  if (predictor_name == "Self-interest") {
    pred_data <- data.frame(
      fairness_objective1 = var_values,
      fairness_objective2 = mean(dataset$fairness_objective2, na.rm = TRUE),
      country = most_common_country
    )
  } else {
    pred_data <- data.frame(
      fairness_objective1 = mean(dataset$fairness_objective1, na.rm = TRUE),
      fairness_objective2 = var_values,
      country = most_common_country
    )
  }
  
  # Generate predictions
  preds <- predict(model, newdata = pred_data, interval = "confidence")
  
  # Return formatted data frame
  data.frame(
    x = var_values,
    predicted = preds[, "fit"],
    conf.low = preds[, "lwr"],
    conf.high = preds[, "upr"],
    Model = model_name,
    Predictor = predictor_name
  )
}

# Create value ranges for predictions
obj1_range <- seq(min(dataset$fairness_objective1, na.rm = TRUE), 
                  max(dataset$fairness_objective1, na.rm = TRUE), 
                  length.out = 50)
obj2_range <- seq(min(dataset$fairness_objective2, na.rm = TRUE), 
                  max(dataset$fairness_objective2, na.rm = TRUE), 
                  length.out = 50)

# Create predictions for distributive fairness models
pred_dist_combined <- bind_rows(
  # Self-interest predictions
  create_predictions(model1, "fairness_objective1", obj1_range, "Population", "Self-interest"),
  create_predictions(model2, "fairness_objective1", obj1_range, "Wealth", "Self-interest"),
  create_predictions(model3, "fairness_objective1", obj1_range, "Unemployment", "Self-interest"),
  create_predictions(model4, "fairness_objective1", obj1_range, "Costs", "Self-interest"),
  create_predictions(model5, "fairness_objective1", obj1_range, "Previous Intakes", "Self-interest"),
  
  # Fairness predictions
  create_predictions(model1, "fairness_objective2", obj2_range, "Population", "Fairness"),
  create_predictions(model2, "fairness_objective2", obj2_range, "Wealth", "Fairness"),
  create_predictions(model3, "fairness_objective2", obj2_range, "Unemployment", "Fairness"),
  create_predictions(model4, "fairness_objective2", obj2_range, "Costs", "Fairness"),
  create_predictions(model5, "fairness_objective2", obj2_range, "Previous Intakes", "Fairness")
)

pred_dist_combined$Model <- factor(
  pred_dist_combined$Model,
  levels = c("Wealth", "Costs", "Previous Intakes", "Unemployment", "Population")
)

# Create plot for distributive fairness
p1 <- ggplot(pred_dist_combined, aes(x = x, y = predicted, color = Model)) +
  geom_line(size = 1.2) +
  geom_ribbon(aes(ymin = conf.low, ymax = conf.high, fill = Model), alpha = 0.2, color = NA) +
  facet_wrap(~Predictor, scales = "free_x") +
  labs(title = "A. Distributive fairness",
       x = "Predictor value",
       y = "Predicted support (1-7 scale)",
       color = "",
       fill = "") +
  scale_color_manual(values = c("steelblue4", "steelblue", "slateblue3", "lightsteelblue", "skyblue3")) +
  scale_fill_manual(values = c("steelblue4", "steelblue", "slateblue3", "lightsteelblue", "skyblue3")) +
  theme_ipsum(base_size = 14) +
  theme(strip.text = element_text(size = 12, face = "bold"),
        legend.position = "bottom",
        legend.direction = "horizontal",plot.margin = margin(5, 5, 5, 5)) +
  guides(color = guide_legend(nrow = 1, byrow = TRUE,plot.margin = margin(5, 5, 5, 5)),
         fill = guide_legend(nrow = 1, byrow = TRUE))

# Fit the procedural fairness models with country fixed effects
model1_proc <- lm(fairness_procedural1 ~ fairness_objective1 + fairness_objective2 + as.factor(country), data = dataset)
model2_proc <- lm(fairness_procedural2 ~ fairness_objective1 + fairness_objective2 + as.factor(country), data = dataset)
model3_proc <- lm(fairness_procedural3 ~ fairness_objective1 + fairness_objective2 + as.factor(country), data = dataset)
model4_proc <- lm(fairness_procedural4 ~ fairness_objective1 + fairness_objective2 + as.factor(country), data = dataset)
model5_proc <- lm(fairness_procedural5 ~ fairness_objective1 + fairness_objective2 + as.factor(country), data = dataset)

# Create predictions for procedural fairness models
pred_proc_combined <- bind_rows(
  # Self-interest predictions
  create_predictions(model1_proc, "fairness_objective1", obj1_range, "Distribution Key", "Self-interest"),
  create_predictions(model2_proc, "fairness_objective1", obj1_range, "State Choice", "Self-interest"),
  create_predictions(model3_proc, "fairness_objective1", obj1_range, "Refugee Choice", "Self-interest"),
  create_predictions(model4_proc, "fairness_objective1", obj1_range, "First Arrival", "Self-interest"),

  # Fairness predictions
  create_predictions(model1_proc, "fairness_objective2", obj2_range, "Distribution Key", "Fairness"),
  create_predictions(model2_proc, "fairness_objective2", obj2_range, "State Choice", "Fairness"),
  create_predictions(model3_proc, "fairness_objective2", obj2_range, "Refugee Choice", "Fairness"),
  create_predictions(model4_proc, "fairness_objective2", obj2_range, "First Arrival", "Fairness"),
)

pred_proc_combined$Model <- factor(
  pred_proc_combined$Model,
  levels = c("Distribution Key", "State Choice", "Refugee Choice", "First Arrival")
)

# Create plot for procedural fairness
p2 <- ggplot(pred_proc_combined, aes(x = x, y = predicted, color = Model)) +
  geom_line(size = 1.2) +
  geom_ribbon(aes(ymin = conf.low, ymax = conf.high, fill = Model), alpha = 0.2, color = NA) +
  facet_wrap(~Predictor, scales = "free_x") +
  labs(title = "B. Procedural fairness",
       x = "Predictor value",
       y = "Predicted support (1-7 scale)",
       color = "",
       fill = "") +
  scale_color_manual(values = c("steelblue4", "steelblue", "slateblue3", "lightsteelblue", "skyblue3")) +
  scale_fill_manual(values = c("steelblue4", "steelblue", "slateblue3", "lightsteelblue", "skyblue3")) +
  theme_ipsum(base_size = 14) +
  theme(strip.text = element_text(size = 12, face = "bold"),
        legend.position = "bottom",
        legend.direction = "horizontal",plot.margin = margin(5, 5, 5, 5)) +
  guides(color = guide_legend(nrow = 1, byrow = TRUE),
         fill = guide_legend(nrow = 1, byrow = TRUE))

# Save the combined plot
png("figure5.png", width = 14, height = 5, units = "in", res = 800)
ggarrange(p1, p2, common.legend = FALSE)
dev.off()

# export models
cluster_se <- function(model, cluster_var) {
  vc <- vcovCL(model, cluster = cluster_var, type = "HC1")
  sqrt(diag(vc))
}

se1 <- cluster_se(model1_proc, model.frame(model1_proc)$country)
se2 <- cluster_se(model2_proc, model.frame(model2_proc)$country)
se3 <- cluster_se(model3_proc, model.frame(model3_proc)$country)
se4 <- cluster_se(model4_proc, model.frame(model4_proc)$country)
se5 <- cluster_se(model5_proc, model.frame(model5_proc)$country)

# export regression table (Table A1)
stargazer(
  model1_proc, model2_proc, model3_proc, model4_proc, model5_proc,
  type = "latex",
  title = "Regression estimates for fairness and self-interest",
  dep.var.labels = c(
    "Distribution key",
    "State choice",
    "Refugee choice",
    "First arrival",
    "Quota trading"
  ),
  covariate.labels = c("Fairness", "Self-interest"),
  omit = "country",
  omit.labels = "Country Fixed Effects",
  omit.stat = c("LL", "aic"),
  no.space = TRUE,
  star.cutoffs = c(0.05, 0.01, 0.001),
  digits = 3,
  se = list(se1, se2, se3, se4, se5)
)


## PART III: Hypotheses testing

# Create binary variables for each alternative vs. status quo
dataset <- dataset %>%
  mutate(prefers_proc1 = ifelse(fairness_procedural1 > fairness_procedural4, 1, 0),
         prefers_proc2 = ifelse(fairness_procedural2 > fairness_procedural4, 1, 0),
         prefers_proc3 = ifelse(fairness_procedural3 > fairness_procedural4, 1, 0),
         prefers_proc5 = ifelse(fairness_procedural5 > fairness_procedural4, 1, 0))

dataset$unfair <- (dataset$fairness_perc*(-1))+ 8

# Fit logistic regression models

# Function for clustered SE tidy results
tidy_clustered <- function(model, cluster_var, model_label) {
  # Extract the clustering variable from the model's data
  cluster_data <- model$data[[cluster_var]]
  
  # Clustered covariance matrix
  vcov_cluster <- vcovCL(model, cluster = cluster_data)
  
  # Coefficient test with clustered SE
  coeftest_res <- coeftest(model, vcov. = vcov_cluster)
  
  # Convert to tidy tibble
  tidy_res <- broom::tidy(coeftest_res) %>%
    rename(estimate = estimate,
           std.error = std.error,
           statistic = statistic,
           p.value = p.value) %>%
    mutate(model = model_label)
  
  return(tidy_res)
}

# Estimate models
model1 <- glm(prefers_proc1 ~ unfair + age + gender + edu + refsupp_norm + country,
              family = binomial, data = dataset)
model2 <- glm(prefers_proc2 ~ unfair + age + gender + edu + refsupp_norm + country,
              family = binomial, data = dataset)
model3 <- glm(prefers_proc3 ~ unfair + age + gender + edu + refsupp_norm + country,
              family = binomial, data = dataset)
model5 <- glm(prefers_proc5 ~ unfair + age + gender + edu + refsupp_norm + country,
              family = binomial, data = dataset)

# List of models
models <- list(model1, model2, model3, model5)

# Function to get clustered robust SEs for each model
clustered_ses <- lapply(models, function(mod) {
  vcov_mat <- vcovCR(mod, cluster = dataset$country, type = "CR2")
  sqrt(diag(vcov_mat))
})

# model output (Table A2)
stargazer(models,
          se = clustered_ses,
          type = "latex",
          title = "Logistic Regression Models with Country Fixed Effects",
          dep.var.labels = c("Prefers distribution key", "Prefers state choice", "Prefers refugee choice", "Prefers quota trading"),
          covariate.labels = c("Perceived unfairness", "Age", "Gender (male)", "Gender (other)", "Education (low)", "Refugee attitudes"),
          omit = "country",  
          omit.labels = "Country Fixed Effects",
          omit.stat = c("LL", "aic"),
          no.space = TRUE,
          star.cutoffs = c(0.05, 0.01, 0.001),
          digits = 3,
          out = "tableA2.tex")

## Predicted probabilities

# Your models
models <- list(
  "Distribution key" = model1,
  "State choice" = model2,
  "Refugee choice" = model3
)

# Function to get clustered SE for a model (country level)
get_clustered_se <- function(model, cluster_var) {
  # Compute cluster-robust vcov
  vcov_cl <- vcovCR(model, cluster = cluster_var, type = "CR2")
  # Get robust SEs
  se <- sqrt(diag(vcov_cl))
  return(se)
}

# Extract predicted probabilities with ggpredict for 'unfair' across all models
preds_list <- lapply(names(models), function(modname) {
  mod <- models[[modname]]
  # Predicted probabilities from ggpredict (no clustered SE here, but good for visualization)
  preds <- ggpredict(mod, terms = "unfair [all]") %>%
    mutate(model = modname)
  return(preds)
})

# Combine all predictions into one dataframe
preds_all <- bind_rows(preds_list)

preds_all$model <- factor(
  preds_all$model,
  levels = c("Distribution key", "State choice", "Refugee choice")
)


# Plot all together with color by model
png("figure6.png", width = 5, height = 5, units = "in", res = 800)
ggplot(preds_all, aes(x = x, y = predicted * 100, color = model, fill = model)) +
  geom_line(size = 1.2) +
  geom_ribbon(aes(ymin = conf.low * 100, ymax = conf.high * 100), alpha = 0.15, color = NA) +
  scale_fill_manual(values = c("steelblue4", "steelblue", "slateblue3", "lightsteelblue")) +
  scale_color_manual(values = c("steelblue4", "steelblue", "slateblue3", "lightsteelblue")) +
  labs(
    x = "Perceived unfairness of current distribution",
    y = "Predicted probability of preferring alternative procedure (in %)",
    color = "",
    fill = ""
  ) +
  theme_ipsum() +
  theme(
    legend.position = "bottom",
    plot.title = element_text(face = "bold", size = 14),
    plot.subtitle = element_text(size = 11),
    plot.margin = margin(5, 5, 5, 5)
  )
dev.off()

## Testing H2

# Create respondent_id
dataset <- dataset %>%
  mutate(respondent_id = row_number())

# Reshape to long format
dataset_long <- dataset %>%
  pivot_longer(
    cols = starts_with("fairness_distributive"),
    names_to = "principle",
    values_to = "support"
  ) %>%
  mutate(
    share = case_when(
      principle == "fairness_distributive1" ~ population_share,
      principle == "fairness_distributive2" ~ gdp_share,
      principle == "fairness_distributive3" ~ unemployment_share,
      principle == "fairness_distributive4" ~ costs_share,
      principle == "fairness_distributive5" ~ previous_intakes_share
    ),
    principle = factor(principle)
  )

# Fixed-effects regression
model_fe <- feols(
  support ~ share | respondent_id,
  data = dataset_long
)
# Cluster by both respondent_id and country directly in summary
model_summary <- summary(model_fe, cluster = c("respondent_id"))

# Use the mean of all fixed effects as baseline
mean_support <- mean(dataset_long$support, na.rm = TRUE)

# Create a range of share values
share_range_clean <- seq(min(dataset_long$share, na.rm = TRUE), 
                         max(dataset_long$share, na.rm = TRUE), 
                         length.out = 100)

# Calculate predicted support on original scale
# (using mean support as baseline since FE absorb individual/country intercepts)
effect_data <- data.frame(
  share = share_range_clean,
  predicted_support = mean_support + coef(model_fe)["share"] * (share_range_clean - mean(dataset_long$share, na.rm = TRUE))
)

# Calculate confidence bands
se_coef <- model_summary$se["share"]
effect_data$ci_lower <- effect_data$predicted_support - 1.96 * se_coef * abs(share_range_clean - mean(dataset_long$share, na.rm = TRUE))
effect_data$ci_upper <- effect_data$predicted_support + 1.96 * se_coef * abs(share_range_clean - mean(dataset_long$share, na.rm = TRUE))

# extract p-value
p_val <- model_summary$coeftable[1, "Pr(>|t|)"]
# create subtitle
subtitle_text <- paste0(
  "Fixed-effects model: � = ", round(coef(model_fe)["share"], 3),
  " (p = ", ifelse(p_val < 0.001, "< 0.001", round(p_val, 3)), ")"
)

fig7a <- ggplot(effect_data, aes(x = share * 100, y = predicted_support)) +
  geom_line(color = "steelblue3", size = 1.5) +
  geom_ribbon(aes(ymin = ci_lower, ymax = ci_upper), 
              alpha = 0.3, fill = "steelblue") +
  labs(
    title = "A. Predicted support by country's fair-share",
    subtitle = subtitle_text,
    x = "Country's fair-share (%)",
    y = "Predicted support (1-7 scale)",
    caption = "95% confidence band shown. Effect estimated within-person."
  ) +
  theme_ipsum() +
  theme(
    plot.title = element_text(face = "bold", size = 18),
    plot.subtitle = element_text(size = 14),
    axis.title = element_text(size = 11),
    panel.grid.minor = element_blank(),
    plot.margin = margin(5, 5, 5, 5)
  )

## probing mechanism

# Center the self-interest variable for easier interpretation
dataset_long <- dataset_long %>%
  mutate(fairness_objective1_centered = fairness_objective1 - mean(fairness_objective1, na.rm = TRUE))

model_fe_centered <- feols(
  support ~ share * fairness_objective1_centered | respondent_id,
  data = dataset_long
)

model_summary_centered <- summary(model_fe_centered, cluster = c("respondent_id"))

fig7b <- ggplot(dataset_long, aes(x = share, y = support)) +
  geom_smooth(
    aes(color = factor(ntile(fairness_objective1, 2)), fill = factor(ntile(fairness_objective1, 2))),
    method = "lm", 
    se = TRUE, 
    alpha = 0.3
  ) +
  labs(
    title = "B. Fairness-bias by self-interest",
    subtitle = "Interaction between country fair-share and respondent self-interest",
    x = "Country's fair-share",
    y = "Predicted support (1-7 scale)",
    caption = "95% confidence band shown. Effect estimated within-person.",
    color = "Self-Interest",
    fill = "Self-Interest"
  ) +
  theme_ipsum() + 
  theme(
    plot.margin = margin(5, 5, 5, 5),
    panel.grid.minor = element_blank(),
    panel.grid.minor.x = element_blank()
  ) +
  scale_color_manual(values = c("lightsteelblue", "steelblue4"), labels = c("Low", "High")) +
  scale_fill_manual(values = c("lightsteelblue", "steelblue4"), labels = c("Low", "High"))

png("figure7.png", width = 12, height = 5, units = "in", res = 600)
y_lims <- c(3.4,4.5)
fig7a_fixed <- fig7a + coord_cartesian(ylim = y_lims)
fig7b_fixed <- fig7b + coord_cartesian(ylim = y_lims)
ggarrange(fig7a_fixed, fig7b_fixed, widths = c(1, 1.05), align = "v")
dev.off()


### Appendix

# Descriptive plot distributive fairness principles
dataset_long <- dataset %>%
  pivot_longer(cols = starts_with("fairness_distributive"),
               names_to = "Criterion",
               values_to = "Score") %>%
  mutate(Criterion = recode(Criterion,
                            "fairness_distributive1" = "Population",
                            "fairness_distributive2" = "Wealth",
                            "fairness_distributive3" = "Unemployment",
                            "fairness_distributive4" = "Costs",
                            "fairness_distributive5" = "Previous intakes"))

# new aligned version
df_distributive1 <- dataset_long %>%
  group_by(Criterion) %>%
  summarize(Percentage = percentage(Score), .groups = "drop") %>%
  arrange(desc(Percentage))

df_distributive1$Criterion <- factor(
  df_distributive1$Criterion,
  levels = df_distributive1$Criterion[order(-df_distributive1$Percentage)]
)

figA1a <- ggplot(df_distributive1,
                 aes(x = reorder(Criterion, -Percentage),
                     y = Percentage,
                     fill = Criterion)) +
  geom_col(width = 0.6) +
  geom_text(aes(label = round(Percentage, 0)),
            vjust = -0.5, size = 4) +
  scale_y_continuous(
    limits = c(0, 100),
    expand = expansion(mult = c(0, 0.05))
  ) +
  scale_fill_manual(
    values = c(
      "steelblue4",
      "steelblue",
      "slateblue3",
      "lightsteelblue",
      "skyblue3"
    )
  ) +
  labs(title = "A. Overall support",
       x = NULL,
       y = "Support (in %)") +
  theme_ipsum(base_size = 14) +
  theme(
    axis.text.x = element_text(angle = 45, hjust = 1),
    panel.grid.major.x = element_blank(),
    legend.position = "none",
    plot.margin = margin(5, 5, 5, 5)
  )

df_distributive2 <- dataset_long %>%
  group_by(Criterion, country) %>%
  summarize(Percentage = percentage(Score), .groups = "drop") %>%
  arrange(desc(Percentage))

df_distributive2$Criterion <- factor(
  df_distributive2$Criterion,
  levels = c("Wealth", "Previous intakes", "Costs", "Unemployment", "Population")
)

df_distributive2$country <- factor(
  df_distributive2$country,
  levels = c("Denmark", "Germany", "Italy", "Greece", "Poland", "Hungary")
)

figA1b <- ggplot(df_distributive2, aes(x = country, y = Percentage, fill = Criterion)) +
  geom_col(position = position_dodge2(padding = 0.08), width = 0.75) +   # gaps between bars, groups tighter
  geom_text(aes(label = round(Percentage, 0)),
            position = position_dodge2(width = 0.75, padding = 0.08),    # must match exactly
            vjust = -0.5, size = 3.5) +
  scale_y_continuous(
    limits = c(0, 100),
    expand = expansion(mult = c(0, 0.05))
  ) +
  scale_fill_manual(
    values = c(
      "steelblue4",
      "steelblue",
      "slateblue3",
      "lightsteelblue",
      "skyblue3"
    )
  ) +
  labs(title = "B. Support by country",
       x = NULL,
       y = "Support (in %)",
       fill = "") +
  theme_ipsum(base_size = 14) +
  theme(
    legend.position = c(0.5, 1.03),          # centered horizontally, near top inside panel
    legend.justification = c(0.5, 1),         # anchor legend box at its top center
    legend.direction = "horizontal",
    legend.background = element_rect(fill = alpha("white", 0.75), color = NA),
    legend.key.size = unit(0.4, "cm"),
    legend.title = element_text(size = 9),
    legend.text = element_text(size = 14),
    panel.grid.major.x = element_blank(),
    panel.grid.minor.x = element_blank(),
    plot.margin = margin(t = 10, r = 10, b = 0, l = 10),
    axis.text.x = element_text(margin = margin(t = 10))
  ) +
  guides(fill = guide_legend(nrow = 1, byrow = TRUE))


png("figureA1.png", width = 11, height = 5, units = "in", res = 600)
figA1a + figA1b +
      plot_layout(widths = c(0.5, 2)) &
      theme(plot.margin = margin(t = 10, r = 10, b = 0, l = 10))
dev.off()


## display the fairness items ranked highest
# Create a function to calculate the percentage of respondents who rank an item highest
percentage_highest_ranked <- function(item_name, data) {
  # For each respondent, identify if this item has the highest score
  # (or is tied for highest) among all fairness items
  
  # Extract all distributive or procedural fairness columns based on the item prefix
  prefix <- ifelse(grepl("distributive", item_name), "fairness_distributive", "fairness_procedural")
  all_items <- grep(paste0("^", prefix), names(data), value = TRUE)
  
  # For each row, check if this item is the highest (or tied for highest)
  highest_count <- sum(
    sapply(1:nrow(data), function(i) {
      item_score <- data[i, item_name]
      other_scores <- data[i, all_items]
      # Check if this item's score is >= all others (handling NA values)
      if(is.na(item_score)) return(FALSE)
      return(all(item_score >= other_scores | is.na(other_scores)))
    })
  )
  
  # Calculate percentage
  return((highest_count / nrow(data)) * 100)
}

# Distributive Fairness
distributive_items <- c("fairness_distributive1", "fairness_distributive2", 
                        "fairness_distributive3", "fairness_distributive4", 
                        "fairness_distributive5")

df_distributive <- data.frame(
  Criterion = c("Population", "Wealth", "Unemployment", "Costs", "Previous Intakes"),
  ItemName = distributive_items,
  Percentage = sapply(distributive_items, percentage_highest_ranked, data = dataset)
) %>%
  arrange(desc(Percentage))

# Procedural Fairness
procedural_items <- c("fairness_procedural1", "fairness_procedural2", 
                      "fairness_procedural3", "fairness_procedural4", 
                      "fairness_procedural5")

df_procedural <- data.frame(
  Criterion = c("EU-level key", "State choice", "Refugee choice", "First arrival", "Quota trading"),
  ItemName = procedural_items,
  Percentage = sapply(procedural_items, percentage_highest_ranked, data = dataset)
) %>%
  arrange(desc(Percentage))

figA2a <- ggplot(df_distributive, aes(x = reorder(Criterion, -Percentage), y = Percentage, fill = Percentage)) +
  geom_col(width = 0.6) +
  geom_text(aes(label = round(Percentage, 1)), vjust = -0.5, size = 4) +
  scale_y_continuous(limits = c(0, 100), expand = expansion(mult = c(0, 0.05))) +
  scale_fill_gradient(low = "lightsteelblue", high = "steelblue4") +
  labs(title = "Distributive fairness",
       subtitle = "Percentage of respondents ranking each criterion highest",
       x = NULL, y = "Share of respondents (in %)",
       fill = "Support (%)") +
  theme_ipsum(base_size = 14) +
  theme(axis.text.x = element_text(angle = 45, hjust = 1),
        panel.grid.major.x = element_blank(),
        legend.position = "none",plot.margin = margin(5, 5, 5, 5))

figA2b <- ggplot(df_procedural, aes(x = reorder(Criterion, -Percentage), y = Percentage, fill = Percentage)) +
  geom_col(width = 0.6) +
  geom_text(aes(label = round(Percentage, 1)), vjust = -0.5, size = 4) +
  scale_y_continuous(limits = c(0, 100), expand = expansion(mult = c(0, 0.05))) +
  scale_fill_gradient(low = "lightsteelblue", high = "steelblue4") +
  labs(title = "Procedural fairness",
       subtitle = "Percentage of respondents ranking each criterion highest",
       x = NULL, y = "Share of respondents (in %)",
       fill = "Support (%)") +
  theme_ipsum(base_size = 14) +
  theme(axis.text.x = element_text(angle = 45, hjust = 1),
        panel.grid.major.x = element_blank(),
        legend.position = "none",plot.margin = margin(5, 5, 5, 5))

# Combined plot
png("figureA2.png", width = 9, height = 4.5, units = "in", res = 600)
ggarrange(figA2a, figA2b, ncol = 2)
dev.off()

## same but based on a strict item preference
# Create a function to calculate the percentage of respondents who strictly prefer an item
percentage_strictly_preferred <- function(item_name, data) {
  # Extract all distributive or procedural fairness columns based on the item prefix
  prefix <- ifelse(grepl("distributive", item_name), "fairness_distributive", "fairness_procedural")
  all_items <- grep(paste0("^", prefix), names(data), value = TRUE)
  other_items <- setdiff(all_items, item_name)
  
  # For each row, check if this item has strictly higher value than all others
  strictly_preferred_count <- sum(
    sapply(1:nrow(data), function(i) {
      item_score <- data[i, item_name]
      if(is.na(item_score)) return(FALSE)
      
      # Check if this item's score is strictly greater than all others
      all(
        sapply(other_items, function(other) {
          other_score <- data[i, other]
          if(is.na(other_score)) return(TRUE)  # NA other scores don't prevent preference
          return(item_score > other_score)
        })
      )
    })
  )
  
  # Calculate percentage
  return((strictly_preferred_count / nrow(data)) * 100)
}

# Distributive Fairness
distributive_items <- c("fairness_distributive1", "fairness_distributive2", 
                        "fairness_distributive3", "fairness_distributive4", 
                        "fairness_distributive5")

df_distributive <- data.frame(
  Criterion = c("Population", "Wealth", "Unemployment", "Costs", "Previous Intakes"),
  ItemName = distributive_items,
  Percentage = sapply(distributive_items, percentage_strictly_preferred, data = dataset)
) %>%
  arrange(desc(Percentage))

# Procedural Fairness
procedural_items <- c("fairness_procedural1", "fairness_procedural2", 
                      "fairness_procedural3", "fairness_procedural4", 
                      "fairness_procedural5")

df_procedural <- data.frame(
  Criterion = c("EU-level key", "State choice", "Refugee choice", "First arrival", "Quota trading"),
  ItemName = procedural_items,
  Percentage = sapply(procedural_items, percentage_strictly_preferred, data = dataset)
) %>%
  arrange(desc(Percentage))

figA3a <- ggplot(df_distributive, aes(x = reorder(Criterion, -Percentage), y = Percentage, fill = Percentage)) +
  geom_col(width = 0.6) +
  geom_text(aes(label = round(Percentage, 1)), vjust = -0.5, size = 4) +
  scale_y_continuous(limits = c(0, 30), expand = expansion(mult = c(0, 0.05))) +
  scale_fill_gradient(low = "lightsteelblue", high = "steelblue4") +
  labs(title = "Distributive fairness",
       subtitle = "Percentage of respondents strictly preferring each criterion",
       x = NULL, y = "Share of respondents (%)",
       fill = "Percentage") +
  theme_ipsum(base_size = 14) +
  theme(axis.text.x = element_text(angle = 45, hjust = 1),
        panel.grid.major.x = element_blank(),
        legend.position = "none",plot.margin = margin(5, 5, 5, 5))  # Or "none" if you want no legend

figA3b <- ggplot(df_procedural, aes(x = reorder(Criterion, -Percentage), y = Percentage, fill = Percentage)) +
  geom_col(width = 0.6) +
  geom_text(aes(label = round(Percentage, 1)), vjust = -0.5, size = 4) +
  scale_y_continuous(limits = c(0, 30), expand = expansion(mult = c(0, 0.05))) +
  scale_fill_gradient(low = "lightsteelblue", high = "steelblue4") +
  labs(title = "Procedural fairness",
       subtitle = "Percentage of respondents strictly preferring each criterion",
       x = NULL, y = "Share of respondents (%)",
       fill = "Percentage") +
  theme_ipsum(base_size = 14) +
  theme(axis.text.x = element_text(angle = 45, hjust = 1),
        panel.grid.major.x = element_blank(),
        legend.position = "none",plot.margin = margin(5, 5, 5, 5))

# Combined plot
png("figureA3.png", width = 9, height = 4.5, units = "in", res = 600)
ggarrange(figA3a, figA3b, ncol = 2)
dev.off()

# Share of strict neutrals
# Function to calculate percentage of respondents who rated all items in a group equally
percentage_strict_neutrals <- function(data, item_prefix) {
  # Get all items in the group
  all_items <- grep(paste0("^", item_prefix), names(data), value = TRUE)
  
  # Count respondents who gave the same rating to all items in the group
  neutral_count <- sum(
    sapply(1:nrow(data), function(i) {
      # Get all values for this row
      values <- as.numeric(data[i, all_items])
      
      # Check if all non-NA values are equal
      non_na_values <- values[!is.na(values)]
      if(length(non_na_values) == 0) return(FALSE)  # All NAs
      
      # If only one unique value exists among the non-NA values, this is a neutral respondent
      return(length(unique(non_na_values)) == 1)
    })
  )
  
  # Calculate percentage
  return((neutral_count / nrow(data)) * 100)
}

# Calculate percentages for both groups
distributive_neutrals <- percentage_strict_neutrals(dataset, "fairness_distributive")
procedural_neutrals <- percentage_strict_neutrals(dataset, "fairness_procedural")

# Create a data frame for visualization
df_neutrals <- data.frame(
  Group = c("Distributive fairness", "Procedural fairness"),
  Percentage = c(distributive_neutrals, procedural_neutrals)
)

# Plot the results
png("figureA4.png", width = 5, height = 4, units = "in", res = 600)
ggplot(df_neutrals, aes(x = Group, y = Percentage, fill = Percentage)) +
  geom_col(width = 0.6) +
  geom_text(aes(label = round(Percentage, 1)), vjust = -0.5, size = 4) +
  scale_y_continuous(limits = c(0, 30), expand = expansion(mult = c(0, 0.05))) +
  scale_fill_gradient(low = "lightsteelblue", high = "steelblue4") +
  labs(title = "Strict neutrals in fairness preferences",
       subtitle = "Percentage of respondents giving identical ratings to all items in a group",
       x = NULL, y = "Share of respondents (%)") +
  theme_ipsum(base_size = 14) +
  theme(panel.grid.major.x = element_blank(),
        legend.position = "none",plot.margin = margin(5, 5, 5, 5))
dev.off()

# Reshape data into long format for plotting
dataset_long <- dataset %>%
  pivot_longer(cols = starts_with("fairness_distributive"),
               names_to = "Criterion",
               values_to = "Score") %>%
  mutate(Criterion = recode(Criterion,
                            "fairness_distributive1" = "Population",
                            "fairness_distributive2" = "Wealth",
                            "fairness_distributive3" = "Unemployment",
                            "fairness_distributive4" = "Costs",
                            "fairness_distributive5" = "Previous Intakes"))

# Compute means by country and criterion
df_distributive <- dataset_long %>%
  group_by(country, Criterion) %>%
  summarize(Score = mean(Score, na.rm = TRUE), .groups = "drop")

desired_country_order <- c("Denmark", "Germany", "Italy", "Greece", "Poland", "Hungary")

df_distributive <- df_distributive %>%
  mutate(country = factor(country, levels = desired_country_order))  # set factor order

# Plot distributive fairness
p1 <- ggplot(df_distributive, aes(x = reorder(Criterion, -Score), y = Score, fill = country)) +
  geom_col(position = position_dodge(), width = 0.7) +
  geom_hline(yintercept = 4, linetype = "dashed", color = "black") +
  coord_flip() +  # Horizontal bars
  scale_fill_manual(values = c("steelblue4", "steelblue", "slateblue3", "lightsteelblue", "skyblue3", "cadetblue"), name = NULL  # removes the legend title
  ) +
  labs(title = "Distributive fairness (mean scores)",
       x = NULL, y = "Mean support score") +
  theme_ipsum() +
  theme(legend.position = "bottom")

# ---- PROCEDURAL FAIRNESS ----

# Reshape data for procedural fairness
dataset_proc_long <- dataset %>%
  pivot_longer(cols = starts_with("fairness_procedural"),
               names_to = "Criterion",
               values_to = "Score") %>%
  mutate(Criterion = recode(Criterion,
                            "fairness_procedural1" = "EU-level key",
                            "fairness_procedural2" = "State choice",
                            "fairness_procedural3" = "Refugee choice",
                            "fairness_procedural4" = "First arrival",
                            "fairness_procedural5" = "Quota trading"))

# Compute means by country and criterion
df_procedural <- dataset_proc_long %>%
  group_by(country, Criterion) %>%
  summarize(Score = mean(Score, na.rm = TRUE), .groups = "drop")

df_procedural <- df_procedural %>%
  mutate(country = factor(country, levels = desired_country_order))  # set factor order

p2 <- ggplot(df_procedural, aes(x = reorder(Criterion, -Score), y = Score, fill = country)) +
  geom_col(position = position_dodge(width = 0.7), width = 0.7) +
  geom_hline(yintercept = 4, linetype = "dashed", color = "black") +
  coord_flip() +
  scale_fill_manual(values = c("steelblue4", "steelblue", "slateblue3", "lightsteelblue", "skyblue3", "cadetblue"),name = NULL  # removes the legend title
  ) +
  labs(title = "Procedural fairness (mean scores)",
       x = NULL, y = "Mean support score") +
  theme_ipsum() +
  theme(legend.position = "bottom")

# 1. Distributive fairness dummies

# Create dummy columns: 1 if value > 4, else 0 (for distributive)
dataset <- dataset %>%
  mutate(across(starts_with("fairness_distributive"), ~ as.integer(. > 4), .names = "dummy_{.col}"))

# Reshape dummy distributive fairness data to long format
dataset_distributive_dummy_long <- dataset %>%
  pivot_longer(cols = starts_with("dummy_fairness_distributive"),
               names_to = "Criterion",
               values_to = "Support") %>%
  mutate(Criterion = recode(Criterion,
                            "dummy_fairness_distributive1" = "Population",
                            "dummy_fairness_distributive2" = "Wealth",
                            "dummy_fairness_distributive3" = "Unemployment",
                            "dummy_fairness_distributive4" = "Costs",
                            "dummy_fairness_distributive5" = "Previous Intakes"))

# Compute support percentages by country and criterion
df_distributive_dummy <- dataset_distributive_dummy_long %>%
  group_by(country, Criterion) %>%
  summarize(Support = mean(Support, na.rm = TRUE) * 100, .groups = "drop")  # % support

df_distributive_dummy <- df_distributive_dummy %>%
  mutate(country = factor(country, levels = desired_country_order))

# Plot distributive fairness support (%)
p3 <- ggplot(df_distributive_dummy, aes(x = reorder(Criterion, -Support), y = Support, fill = country)) +
  geom_col(position = position_dodge(width = 0.7), width = 0.7) +
  coord_flip() +
  geom_hline(yintercept = 50, linetype = "dashed", color = "black") +
  scale_fill_manual(values = c("steelblue4", "steelblue", "slateblue3", 
                               "lightsteelblue", "skyblue3", "cadetblue"), name = NULL  # removes the legend title
  ) +
  labs(title = "Distributive fairness (support in %)",
       x = NULL, y = "Support (%)") +
  theme_ipsum() +
  theme(legend.position = "bottom")

# 2. Procedural fairness dummies

# Create dummy columns: 1 if value > 4, else 0 (for procedural)
dataset <- dataset %>%
  mutate(across(starts_with("fairness_procedural"), ~ as.integer(. > 4), .names = "dummy_{.col}"))

# Reshape dummy procedural fairness data to long format
dataset_procedural_dummy_long <- dataset %>%
  pivot_longer(cols = starts_with("dummy_fairness_procedural"),
               names_to = "Criterion",
               values_to = "Support") %>%
  mutate(Criterion = recode(Criterion,
                            "dummy_fairness_procedural1" = "EU-level key",
                            "dummy_fairness_procedural2" = "State choice",
                            "dummy_fairness_procedural3" = "Refugee choice",
                            "dummy_fairness_procedural4" = "First arrival",
                            "dummy_fairness_procedural5" = "Quota trading"))

# Compute support percentages by country and criterion
df_procedural_dummy <- dataset_procedural_dummy_long %>%
  group_by(country, Criterion) %>%
  summarize(Support = mean(Support, na.rm = TRUE) * 100, .groups = "drop")  # % support

df_procedural_dummy <- df_procedural_dummy %>%
  mutate(country = factor(country, levels = desired_country_order))

# Plot procedural fairness support (%)
p4 <- ggplot(df_procedural_dummy, aes(x = reorder(Criterion, -Support), y = Support, fill = country)) +
  geom_col(position = position_dodge(width = 0.7), width = 0.7) +
  coord_flip() +
  geom_hline(yintercept = 50, linetype = "dashed", color = "black") +
  
  scale_fill_manual(values = c("steelblue4", "steelblue", "slateblue3", 
                               "lightsteelblue", "skyblue3", "cadetblue"),name = NULL  # removes the legend title
  ) +
  labs(title = "Procedural fairness (support in %)",
       x = NULL, y = "Support (%)") +
  theme_ipsum() +
  theme(legend.position = "bottom")

# Display the plots
png("figureA5.png", width = 12, height = 14, units = "in", res = 600)
ggarrange(p1,p2, p3,p4, nrow=2,ncol=2)
dev.off()

# Prepare the data with dichotomized support (excluding neutrals)
dataset_support <- dataset %>%
  # Create dichotomized variables (support > 4, excluding 4)
  mutate(
    across(starts_with("fairness_distributive") | starts_with("fairness_procedural"),
           ~ case_when(
             .x > 4 ~ "Support",
             .x < 4 ~ "Oppose", 
             .x == 4 ~ NA_character_  # Exclude neutrals
           ), .names = "{.col}_binary")
  ) %>%
  # Select relevant columns
  dplyr::select(country, ends_with("_binary")) %>%
  # Pivot to long format
  pivot_longer(cols = ends_with("_binary"), 
               names_to = "indicator",
               values_to = "Response") %>%
  # Remove missing values (neutrals)
  filter(!is.na(Response)) %>%
  # Clean indicator names and create type variable
  mutate(
    Indicator = str_remove(indicator, "_binary"),
    Type = case_when(
      str_detect(indicator, "distributive") ~ "Distributive fairness",
      str_detect(indicator, "procedural") ~ "Procedural fairness"
    ),
    indicator = case_when(
      Type == "Distributive fairness" & str_detect(indicator, "1") ~ "Population",
      Type == "Distributive fairness" & str_detect(indicator, "2") ~ "Wealth",
      Type == "Distributive fairness" & str_detect(indicator, "3") ~ "Unemployment",
      Type == "Distributive fairness" & str_detect(indicator, "4") ~ "Costs",
      Type == "Distributive fairness" & str_detect(indicator, "5") ~ "Previous Intakes",
      Type == "Procedural fairness" & str_detect(indicator, "1") ~ "EU-level key",
      Type == "Procedural fairness" & str_detect(indicator, "2") ~ "State choice",
      Type == "Procedural fairness" & str_detect(indicator, "3") ~ "Refugee choice",
      Type == "Procedural fairness" & str_detect(indicator, "4") ~ "First arrival",
      Type == "Procedural fairness" & str_detect(indicator, "5") ~ "Quota trading"
    )
  )

# Function to create support plots with steelblue color scheme
plot_country_support <- function(df, fairness_type) {
  df %>%
    filter(Type == fairness_type) %>%
    # Calculate percentages
    count(country, indicator, Response) %>%
    group_by(country, indicator) %>%
    mutate(
      total = sum(n),
      percentage = n / total
    ) %>%
    ungroup() %>%
    # Create the plot
    ggplot(aes(x = indicator, y = percentage, fill = Response)) +
    geom_col(position = "stack", alpha = 0.8) +
    geom_hline(yintercept = 0.5, linetype = "dotted", color = "gray50", size = 0.8) +
    scale_fill_manual(
      values = c("Support" = "steelblue", "Oppose" = "lightsteelblue"),
      name = "Response"
    ) +
    scale_y_continuous(
      labels = scales::percent_format(),
      breaks = seq(0, 1, 0.25),
      expand = expansion(mult = c(0, 0.02))
    ) +
    facet_wrap(~country, ncol = 3) +
    labs(
      title = fairness_type,
      subtitle = "Proportion supporting vs. opposing (excluding neutral responses)",
      x = "Fairness indicator",
      y = "Proportion of responses",
      fill = "Response"
    ) +
    theme_ipsum(base_size = 12) +
    theme(
      axis.text.x = element_text(angle = 45, hjust = 1),
      legend.position = "bottom",
      strip.text = element_text(size = 11, face = "bold"),
      plot.title = element_text(size = 14, face = "bold"),
      panel.grid.minor.x = element_blank(),plot.margin = margin(5, 5, 5, 5),
      panel.grid.major.x = element_blank(),
      plot.subtitle = element_text(size = 11, color = "gray60")
    )
}

# Support-only version with gradient coloring based on support level
plot_country_support_only <- function(df, fairness_type) {
  support_data <- df %>%
    filter(Type == fairness_type) %>%
    # Calculate support percentages
    count(country, indicator, Response) %>%
    group_by(country, indicator) %>%
    mutate(
      total = sum(n),
      percentage = n / total * 100
    ) %>%
    filter(Response == "Support") %>%
    ungroup()
  
  support_data %>%
    ggplot(aes(x = indicator, y = percentage, fill = percentage)) +
    geom_col(alpha = 0.8, width = 0.7) +
    geom_hline(yintercept = 50, linetype = "dotted", color = "gray50", size = 0.8) +
    geom_text(aes(label = paste0(round(percentage, 1), "%")), 
              vjust = -0.5, size = 2.8, color = "gray30") +
    scale_fill_gradient(low = "lightsteelblue", high = "steelblue4") +
    scale_y_continuous(
      limits = c(0, 100),
      breaks = seq(0, 100, 25),
      expand = expansion(mult = c(0, 0.08))
    ) +
    facet_wrap(~country, ncol = 3) +
    labs(
      title = paste(fairness_type, ""),
      subtitle = "Percentage supporting each principle (excluding neutral responses)",
      x = "Fairness indicator",
      y = "Support (%)"
    ) +
    theme_ipsum(base_size = 12) +
    theme(
      axis.text.x = element_text(angle = 45, hjust = 1),
      strip.text = element_text(size = 11, face = "bold"),
      plot.title = element_text(size = 14, face = "bold"),
      panel.grid.minor.x = element_blank(),
      panel.grid.major.x = element_blank(),plot.margin = margin(5, 5, 5, 5),
      plot.subtitle = element_text(size = 11, color = "gray60"),
      legend.position = "none"  # Hide legend since color represents the y-axis values
    )
}

# Generate only the support-only plots
plot_distributive_support <- plot_country_support_only(dataset_support, "Distributive fairness")
plot_procedural_support <- plot_country_support_only(dataset_support, "Procedural fairness")

jpeg("figureA6.jpeg", width = 10, height = 14, units = "in", res = 800)
plot_distributive_support / plot_procedural_support
dev.off()

# Measurement Invariance: Multi-Group CFA
model <- '
  distributive =~ fairness_distributive1 + fairness_distributive2 + 
                  fairness_distributive3 + fairness_distributive4 + fairness_distributive5
  procedural   =~ fairness_procedural1 + fairness_procedural2 + 
                  fairness_procedural3 + fairness_procedural4 + fairness_procedural5
'

# Fit models
fit_config <- cfa(model, data = dataset, group = "country", estimator = "MLR")
fit_metric <- cfa(model, data = dataset, group = "country", group.equal = "loadings", estimator = "MLR")
fit_scalar <- cfa(model, data = dataset, group = "country", group.equal = c("loadings", "intercepts"), estimator = "MLR")

# Extract fit indices
get_fit <- function(x) fitMeasures(x, c("chisq", "df", "cfi", "tli", "rmsea", "srmr"))
f1 <- get_fit(fit_config); f2 <- get_fit(fit_metric); f3 <- get_fit(fit_scalar)

# Print results
cat(sprintf("Configural: ????(%d) = %.2f, CFI = %.2f, TLI = %.2f, RMSEA = %.2f, SRMR = %.2f\n",
            f1["df"], f1["chisq"], f1["cfi"], f1["tli"], f1["rmsea"], f1["srmr"]))
cat(sprintf("Metric:     ??CFI = %.3f, ??RMSEA = %+.3f\n", f2["cfi"]-f1["cfi"], f2["rmsea"]-f1["rmsea"]))
cat(sprintf("Scalar:     ??CFI = %.3f, ??RMSEA = %+.3f\n", f3["cfi"]-f2["cfi"], f3["rmsea"]-f2["rmsea"]))

# Rename fairness indicators for consistency with previous plots
fairness_corr_data <- dataset %>%
  dplyr::select(starts_with("fairness_distributive"), starts_with("fairness_procedural")) %>%
  rename(
    "Population" = fairness_distributive1,
    "Wealth" = fairness_distributive2,
    "Unemployment" = fairness_distributive3,
    "Costs" = fairness_distributive4,
    "Previous Intakes" = fairness_distributive5,
    "EU-level key" = fairness_procedural1,
    "State choice" = fairness_procedural2,
    "Refugee choice" = fairness_procedural3,
    "First arrival" = fairness_procedural4,
    "Quota trading" = fairness_procedural5
  )

# Compute correlation matrix
fairness_corr_matrix <- cor(fairness_corr_data, use = "pairwise.complete.obs")

# Remove Var1 and Var2 by setting blank labels
rownames(fairness_corr_matrix) <- colnames(fairness_corr_data)
colnames(fairness_corr_matrix) <- colnames(fairness_corr_data)

# Create correlation plot with correct labels, rotated axis text, and empty axis titles
jpeg("figureA7.jpeg", width = 8,, height = 7, units = "in", res = 800)
ggcorrplot(fairness_corr_matrix, 
           method = "square",  
           type = "lower",     
           lab = TRUE,         
           outline.color = "white",
           colors = c("darkorange", "white", "steelblue")) +  
  labs(x = "", y = "") +  # Empty axis labels
  theme_ipsum() +
  theme(axis.text.x = element_text(angle = 45, hjust = 1),plot.margin = margin(5, 5, 5, 5))
dev.off()

# Select and rename fairness indicators
fairness_vars <- c("fairness_distributive1", "fairness_distributive2", "fairness_distributive3",
                   "fairness_distributive4", "fairness_distributive5", "fairness_procedural1",
                   "fairness_procedural2", "fairness_procedural3", "fairness_procedural4",
                   "fairness_procedural5")

fairness_labels <- c("Population", "Wealth", "Unemployment", "Costs", "Previous Intakes",
                     "EU-level key", "State choice", "Refugee choice", "First arrival", "Quota trading")

# Function to get correlation matrix tidy for one country
get_corr_tidy <- function(df) {
  corr_mat <- cor(df, use = "pairwise.complete.obs")
  # Make a tidy data frame with all pairs
  corr_df <- as.data.frame(as.table(corr_mat))
  names(corr_df) <- c("Var1", "Var2", "Correlation")
  corr_df
}

# Build a combined data frame for all countries
all_corrs <- lapply(unique(dataset$country), function(ctry) {
  dat_ctry <- dataset %>%
    filter(country == ctry) %>%
    dplyr::select(all_of(fairness_vars)) %>%
    setNames(fairness_labels)
  
  get_corr_tidy(dat_ctry) %>%
    mutate(country = ctry)
}) %>%
  bind_rows()

# To mimic lower triangle plot, filter to only lower triangle (Var1 > Var2)
all_corrs <- all_corrs %>%
  mutate(Var1 = factor(Var1, levels = fairness_labels),
         Var2 = factor(Var2, levels = fairness_labels)) %>%
  filter(as.numeric(Var1) > as.numeric(Var2))

all_corrs <- all_corrs %>%
  mutate(
    country = factor(country, 
                     levels = c("Denmark", "Germany", "Italy", "Greece", "Poland", "Hungary"))
  )

# Plot
jpeg("figureA8.jpeg", width = 9,, height = 14, units = "in", res = 800)
ggplot(all_corrs, aes(x = Var2, y = Var1, fill = Correlation)) +
  geom_tile(color = "white") +
  geom_text(aes(label = round(Correlation, 2)), size = 3) +
  scale_fill_gradient2(low = "darkorange", mid = "white", high = "steelblue", midpoint = 0) +
  facet_wrap(~ country, ncol = 2) +
  coord_fixed() +
  labs(       x = NULL, y = NULL, fill = "Correlation") +
  theme_ipsum(base_size = 14) +
  theme(axis.text.x = element_text(angle = 45, hjust = 1),
        panel.grid = element_blank(),plot.margin = margin(5, 5, 5, 5),
        strip.text = element_text(face = "bold"),legend.position = "bottom",)
dev.off()

# Create refugee support groups (only two groups, exclude NAs completely)
dataset_analysis <- dataset %>%
  filter(!is.na(refsupp_norm)) %>%  # Remove NAs first
  mutate(
    refugee_support_group = case_when(
      refsupp_norm > 4 ~ "Pro-refugee respondents",
      refsupp_norm <= 4 ~ "Anti-refugee respondents"
    )
  )

# Calculate means and SDs for each fairness variable by group
fairness_summary <- dataset_analysis %>%
  dplyr::select(refugee_support_group, starts_with("fairness_")) %>%
  pivot_longer(cols = starts_with("fairness_"), 
               names_to = "fairness_var", 
               values_to = "score") %>%
  filter(!is.na(score)) %>%
  group_by(refugee_support_group, fairness_var) %>%
  summarise(
    n = n(),
    mean_score = mean(score),
    sd_score = sd(score),
    se_score = sd_score / sqrt(n),
    .groups = 'drop'
  ) %>%
  # Add variable labels
  mutate(
    fairness_type = case_when(
      str_detect(fairness_var, "distributive") ~ "Distributive",
      str_detect(fairness_var, "procedural") ~ "Procedural"
    ),
    fairness_label = case_when(
      fairness_var == "fairness_distributive1" ~ "Population",
      fairness_var == "fairness_distributive2" ~ "Wealth", 
      fairness_var == "fairness_distributive3" ~ "Unemployment",
      fairness_var == "fairness_distributive4" ~ "Costs",
      fairness_var == "fairness_distributive5" ~ "Previous Intakes",
      fairness_var == "fairness_procedural1" ~ "EU-level key",
      fairness_var == "fairness_procedural2" ~ "State choice",
      fairness_var == "fairness_procedural3" ~ "Refugee choice", 
      fairness_var == "fairness_procedural4" ~ "First arrival",
      fairness_var == "fairness_procedural5" ~ "Quota trading"
    )
  )
fairness_summary <- subset(fairness_summary, !is.na(fairness_summary$fairness_type))

overall_means <- fairness_summary %>%
  group_by(fairness_label, fairness_type) %>%
  summarise(overall_mean = mean(mean_score), .groups = 'drop') %>%
  arrange(fairness_type, desc(overall_mean))
overall_means <- subset(overall_means, !is.na(overall_means$fairness_label))

# Create refugee support groups (only two groups, exclude NAs completely)
dataset_analysis1 <- dataset %>%
  filter(!is.na(fairness_objective2)) %>%  # Remove NAs first
  mutate(
    support_group = case_when(
      fairness_objective2 > 4 ~ "Pro-fairness respondents",
      fairness_objective2 <= 4 ~ "Anti-fairness respondents"
    )
  )

# Calculate means and SDs for each fairness variable by group
fairness_summary1 <- dataset_analysis1 %>%
  dplyr::select(support_group, starts_with("fairness_")) %>%
  pivot_longer(cols = starts_with("fairness_"), 
               names_to = "fairness_var", 
               values_to = "score") %>%
  filter(!is.na(score)) %>%
  group_by(support_group, fairness_var) %>%
  summarise(
    n = n(),
    mean_score = mean(score),
    sd_score = sd(score),
    se_score = sd_score / sqrt(n),
    .groups = 'drop'
  ) %>%
  # Add variable labels
  mutate(
    fairness_type = case_when(
      str_detect(fairness_var, "distributive") ~ "Distributive",
      str_detect(fairness_var, "procedural") ~ "Procedural"
    ),
    fairness_label = case_when(
      fairness_var == "fairness_distributive1" ~ "Population",
      fairness_var == "fairness_distributive2" ~ "Wealth", 
      fairness_var == "fairness_distributive3" ~ "Unemployment",
      fairness_var == "fairness_distributive4" ~ "Costs",
      fairness_var == "fairness_distributive5" ~ "Previous Intakes",
      fairness_var == "fairness_procedural1" ~ "EU-level key",
      fairness_var == "fairness_procedural2" ~ "State choice",
      fairness_var == "fairness_procedural3" ~ "Refugee choice", 
      fairness_var == "fairness_procedural4" ~ "First arrival",
      fairness_var == "fairness_procedural5" ~ "Quota trading"
    )
  )
fairness_summary1 <- subset(fairness_summary1, !is.na(fairness_summary1$fairness_type))

overall_means1 <- fairness_summary1 %>%
  group_by(fairness_label, fairness_type) %>%
  summarise(overall_mean = mean(mean_score), .groups = 'drop') %>%
  arrange(fairness_type, desc(overall_mean))
overall_means <- subset(overall_means, !is.na(overall_means$fairness_label))

jpeg("figureA9.jpeg", width = 9, height = 6, units = "in", res = 800)
fairness_summary %>%
  # Add overall means for sorting
  left_join(overall_means, by = c("fairness_label", "fairness_type")) %>%
  # Reorder factor levels based on overall mean within each type
  mutate(
    fairness_label = factor(fairness_label, 
                            levels = overall_means$fairness_label),
    # Transform variables by subtracting 1 so bars start from 0
    mean_score_adj = mean_score - 1,
    se_score_adj = se_score  # SE doesn't need adjustment
  ) %>%
  ggplot(aes(x = fairness_label, y = mean_score_adj, fill = refugee_support_group)) +
  geom_col(position = "dodge", alpha = 0.8, width = 0.7) +
  geom_errorbar(aes(ymin = mean_score_adj - se_score_adj, ymax = mean_score_adj + se_score_adj),
                position = position_dodge(width = 0.7), width = 0.2, linewidth=0.2) +
  geom_text(aes(label = round(mean_score, 2)),  # Use original values for labels
            position = position_dodge(width = 0.7), vjust = -0.5, size = 2.5) +
  scale_fill_manual(values = c("Pro-refugee respondents" = "steelblue",
                               "Anti-refugee respondents" = "lightsteelblue")) +
  scale_y_continuous(limits = c(0, 5), 
                     breaks = 0:5, 
                     labels = 1:6,  # Display 1-6 but actual values are 0-5
                     expand = expansion(mult = c(0, 0.1))) +
  facet_wrap(~fairness_type, scales = "free_x") +
  labs(x = "Fairness dimension",
       y = "Mean score (1-6 scale)",  # Updated scale range
       fill = "Group") +
  theme_ipsum(base_size = 12) +
  theme(
    axis.text.x = element_text(angle = 45, hjust = 1),
    legend.position = "bottom",
    plot.margin = margin(5, 5, 5, 5),
    legend.title = element_blank(),
    panel.grid.major.x = element_blank(),
    panel.grid.minor.x = element_blank()
  )
dev.off()

## decriptive plot
dataset_long <- dataset %>%
  dplyr::select(
    country,
    population_share,
    gdp_share,
    unemployment_share,
    costs_share,
    previous_intakes_share
  ) %>%
  distinct() %>%
  pivot_longer(
    cols = -country,
    names_to = "criterion",
    values_to = "share"
  ) %>%
  mutate(
    criterion = gsub("_share", "", criterion),
    criterion = factor(
      criterion,
      levels = c("population", "gdp", "unemployment", "costs", "previous_intakes")
    )
  )

# Map to nice labels
criterion_labels <- c(
  population = "Population size",
  gdp = "National wealth",
  unemployment = "Unemployment",
  costs = "Reception costs",
  previous_intakes = "Previous intakes"
)

png("figureA10.png", width = 8, height = 5, units = "in", res = 800)
ggplot(dataset_long, aes(
  x = country,
  y = share,
  fill = criterion
)) +
  geom_bar(stat = "identity", position = "dodge") +
  labs(
    x = "Country",
    y = "Fair-share (in %)",
    fill = ""
  ) +
  scale_y_continuous(labels = label_percent(accuracy = 1)) +
  scale_fill_manual(
    values = c("steelblue4", "steelblue", "slateblue3", "lightsteelblue", "skyblue3"),
    labels = criterion_labels
  ) +
  theme_ipsum() +
  theme(
    legend.position = c(0.5, 1.045),          # centered horizontally, near top inside panel
    legend.justification = c(0.5, 1),         # anchor legend box at its top center
    legend.direction = "horizontal",
    legend.background = element_rect(fill = alpha("white", 0.75), color = NA),
    legend.key.size = unit(0.4, "cm"),
    legend.title = element_text(size = 9),
    legend.text = element_text(size = 14),
    panel.grid.major.x = element_blank(),
    panel.grid.minor.x = element_blank(),
    plot.margin = margin(t = 10, r = 10, b = 0, l = 10),
    axis.text.x = element_text(margin = margin(t = 10))
  ) +
  guides(fill = guide_legend(nrow = 1, byrow = TRUE))
dev.off()

# Apply tidy_clustered for each
model_results <- bind_rows(
  tidy_clustered(model1, "country", "Distribution key"),
  tidy_clustered(model2, "country", "State choice"),
  tidy_clustered(model3, "country", "Refugee choice"),
  tidy_clustered(model5, "country", "Quota trading")
)

# Filter for the "unfair" variable
model_results_unfair <- model_results %>% 
  filter(term == "unfair")

figA11a <- ggplot(model_results_unfair, aes(x = estimate, y = reorder(model, estimate), color = model)) +
  geom_point(size = 4, alpha = 0.9) +
  geom_errorbarh(aes(xmin = estimate - 1.96 * std.error, 
                     xmax = estimate + 1.96 * std.error), 
                 height = 0.15, alpha = 0.9, linewidth = 1.2) +
  geom_vline(xintercept = 0, linetype = "dashed", color = "gray40", linewidth = 0.8) +
  scale_color_manual(values = c("steelblue", "steelblue", "steelblue", "steelblue")) +
  labs(title = "Dichotomous support variable",
       x = "Coefficient estimate",
       y = NULL,
  ) +
  theme_ipsum() +
  theme(
    legend.position = "none",
    panel.grid.major.y = element_blank(),
    panel.grid.minor = element_blank(),
    panel.grid.major.x = element_line(color = "gray90", linewidth = 0.5),
    axis.text.y = element_text(size = 11, color = "gray20"),
    axis.text.x = element_text(size = 10, color = "gray20"),
    axis.title.x = element_text(size = 12, color = "gray10"),
    plot.title = element_text(size = 15, face = "bold", color = "gray10"),
    plot.subtitle = element_text(size = 11, color = "gray30"),
    plot.caption = element_text(size = 9, color = "gray50"),
    plot.margin = margin(15, 15, 15, 15)
  )

dataset <- dataset %>%
  mutate(
    pref_diff_proc1 = fairness_procedural1 - fairness_procedural4,
    pref_diff_proc2 = fairness_procedural2 - fairness_procedural4,
    pref_diff_proc3 = fairness_procedural3 - fairness_procedural4,
    pref_diff_proc5 = fairness_procedural5 - fairness_procedural4
  )

# All models
model1 <- lm(pref_diff_proc1 ~ unfair + age + gender + edu + refsupp_norm + country, 
             data = dataset)
model2 <- lm(pref_diff_proc2 ~ unfair + age + gender + edu + refsupp_norm + country, 
             data = dataset)
model3 <- lm(pref_diff_proc3 ~ unfair + age + gender + edu + refsupp_norm + country, 
             data = dataset)
model5 <- lm(pref_diff_proc5 ~ unfair + age + gender + edu + refsupp_norm + country, 
             data = dataset)

# Function to get clustered results
get_unfair_coef <- function(model, model_name) {
  clustered_se <- vcovCL(model, cluster = dataset$country)
  results <- coeftest(model, vcov = clustered_se)
  unfair_coef <- results["unfair", "Estimate"]
  unfair_se <- results["unfair", "Std. Error"]
  unfair_p <- results["unfair", "Pr(>|t|)"]
  cat(model_name, "- Unfair coefficient:", round(unfair_coef, 4), 
      "SE:", round(unfair_se, 4), "p:", round(unfair_p, 4), "\n")
  return(data.frame(
    model = model_name,
    estimate = unfair_coef,
    se = unfair_se,
    p_value = unfair_p,
    lower = unfair_coef - 1.96 * unfair_se,
    upper = unfair_coef + 1.96 * unfair_se
  ))
}

# Get results for all models
results_list <- list(
  get_unfair_coef(model1, "Distribution key"),
  get_unfair_coef(model2, "State choice"),
  get_unfair_coef(model3, "Refugee choice"),
  get_unfair_coef(model5, "Quota trading")
)

# Combine results
all_results <- do.call(rbind, results_list)

# Plot all coefficients
figA11b <- ggplot(all_results, aes(x = estimate, y = reorder(model, estimate), color = model)) +
  geom_point(size = 4, alpha = 0.9) +
  geom_errorbarh(
    aes(xmin = lower, xmax = upper),
    height = 0.15,
    alpha = 0.9,
    linewidth = 1.2
  ) +
  geom_vline(xintercept = 0, linetype = "dashed", color = "gray40", linewidth = 0.8) +
  scale_color_manual(values = rep("steelblue", nrow(all_results))) +
  labs(
    title = "Continous support variable",
    subtitle = "95% confidence intervals with country-clustered standard errors",
    x = "Coefficient estimate",
    y = NULL
  ) +
  theme_ipsum() +
  theme(
    legend.position = "none",
    panel.grid.major.y = element_blank(),
    panel.grid.minor = element_blank(),
    panel.grid.major.x = element_line(color = "gray90", linewidth = 0.5),
    axis.text.y = element_text(size = 11, color = "gray20"),
    axis.text.x = element_text(size = 10, color = "gray20"),
    axis.title.x = element_text(size = 12, color = "gray10"),
    plot.title = element_text(size = 15, face = "bold", color = "gray10"),
    plot.subtitle = element_text(size = 11, color = "gray30"),
    plot.caption = element_text(size = 9, color = "gray50"),
    plot.margin = margin(15, 15, 15, 15)
  )

png("figureA11.png", width = 12, height = 3, units = "in", res = 800)
ggarrange(figA11a,figA11b)
dev.off()

dataset_long <- dataset %>%
  pivot_longer(
    cols = starts_with("fairness_distributive"),
    names_to = "principle",
    values_to = "support"
  ) %>%
  mutate(
    share = case_when(
      principle == "fairness_distributive1" ~ population_share,
      principle == "fairness_distributive2" ~ gdp_share,
      principle == "fairness_distributive3" ~ unemployment_share,
      principle == "fairness_distributive4" ~ costs_share,
      principle == "fairness_distributive5" ~ previous_intakes_share
    ),
    principle = factor(principle)
  )

# base model
model_base <- feols(
  support ~ share | respondent_id,
  data = dataset_long
)
# Cluster by both respondent_id and country directly in summary
summary(model_base, cluster = c("respondent_id"))

## robustness checks

# Add a small constant to avoid log(0)
epsilon <- 1e-6

dataset_long <- dataset_long %>%
  mutate(
    share_log = log(share + epsilon)
  )

# 1. Log-transformed shares
model_fe_log <- feols(
  support ~ share_log | respondent_id,
  data = dataset_long
)

summary(model_fe_log, cluster = "respondent_id")

# 2. Ranked shares
# Create ranks across unique country ?? principle fair-shares
share_ranks <- dataset_long %>%
  distinct(country, principle, share) %>%
  group_by(country) %>%
  arrange(share) %>%
  mutate(
    share_rank_val = rank(share) / max(rank(share))  # scaled 0-1 within country
  ) %>%
  ungroup()

# Join ranks back to the long data
dataset_long <- dataset_long %>%
  left_join(share_ranks, by = c("country", "principle", "share"))

# Fit FE model using ranked shares
model_fe_rank <- feols(
  support ~ share_rank_val | respondent_id,
  data = dataset_long
)

summary(model_fe_rank, cluster = "respondent_id")

## export
models <- list(
  "Baseline (linear)" = model_base,
  "Log-transformed share" = model_fe_log,
  "Ranked share" = model_fe_rank
)

# Export LaTeX table (Table A3)
texreg(
  models,
  file = "tableA3.tex",
  stars = c(0.001, 0.01, 0.05),
  custom.coef.map = list(
    share = "Baseline (linear)",
    share_log = "Log-transformed share",
    share_rank_val = "Rank share"
  ),
  caption = "Fairness bias across alternative specifications"
)

# --- 1. Pooled (overall) FE model for reference ---
pooled_model <- feols(support ~ share | respondent_id, data = dataset_long)
pooled_est <- coef(pooled_model)["share"]
pooled_se  <- sqrt(vcov(pooled_model, cluster = "respondent_id")["share", "share"])
pooled_lower <- pooled_est - 1.96 * pooled_se
pooled_upper <- pooled_est + 1.96 * pooled_se

# --- 2. Separate FE model per country, extract clustered SEs ---
countries <- unique(dataset_long$country)

country_results <- map_df(countries, function(ctry) {
  dsub <- filter(dataset_long, country == ctry)
  # require at least some respondents
  if(nrow(dsub) < 50) return(tibble(country = ctry, estimate = NA_real_, se = NA_real_, n = nrow(dsub)))
  m <- feols(support ~ share | respondent_id, data = dsub)
  est <- coef(m)["share"]
  vc <- vcov(m, cluster = "respondent_id")
  se  <- sqrt(vc["share", "share"])
  tibble(country = ctry, estimate = as.numeric(est), se = as.numeric(se), n = nrow(dsub))
})

country_results <- country_results %>%
  mutate(
    lower = estimate - 1.96 * se,
    upper = estimate + 1.96 * se
  )

# --- 3. Plot country-specific slopes with 95% CIs and pooled reference ---
png("figureA12.png", width = 10, height = 3, units = "in", res = 800)
ggplot(country_results, aes(x = reorder(country, estimate), y = estimate)) +
  geom_hline(yintercept = 0, color = "gray70", linetype = "dashed") +
  geom_errorbar(aes(ymin = lower, ymax = upper), width = 0.2, color = "steelblue", size = 0.8, alpha = 0.9) +
  geom_point(color = "steelblue4", size = 3) +
  geom_hline(yintercept = pooled_est, color = "red", linetype = "longdash", size = 0.8) +
  annotate("text", x = Inf, y = pooled_est, label = paste0("Pooled = ", round(pooled_est, 2)),
           hjust = 1.05, vjust = -0.5, color = "red", size = 3.5) +
  coord_flip() +
  labs(
    subtitle = "Separate FE per country: support ~ share | respondent_id (clustered SEs)",
    x = "Country (ordered by slope)",
    y = "Coefficient on share (negative = stronger fairness bias)",
    caption = "Points = estimates; bars = 95% CI; red dashed = pooled estimate"
  ) +
  theme_ipsum() +
  theme(plot.title = element_text(face = "bold"), plot.margin = margin(5, 5, 5, 5))
dev.off()


# Vector of items to compare with P4
alts <- c("fairness_procedural1", 
          "fairness_procedural2", 
          "fairness_procedural3", 
          "fairness_procedural5")

# More informative labels
alt_labels <- c(
  "EU-level distribution key",
  "State choice",
  "Refugee choice",
  "Quota trading"
)

# Create pairwise comparison long data
df_long <- dataset %>%
  mutate(id = row_number()) %>%
  select(id, fairness_procedural4, all_of(alts)) %>%
  pivot_longer(cols = all_of(alts),
               names_to = "alternative",
               values_to = "alt_value") %>%
  mutate(
    comparison = case_when(
      alt_value > fairness_procedural4 ~ "Prefer alternative",
      alt_value < fairness_procedural4 ~ "Prefer status quo",
      TRUE ~ "No preference"
    ),
    # reversed order for the bars
    comparison = factor(comparison,
                        levels = c("Prefer status quo",
                                   "No preference",
                                   "Prefer alternative")),
    alternative = factor(alternative,
                         levels = alts,
                         labels = alt_labels)
  )

# Compute shares
df_plot <- df_long %>%
  count(alternative, comparison) %>%
  group_by(alternative) %>%
  mutate(prop = n / sum(n))

# Colors
cols <- c(
  "Prefer alternative"     = "steelblue4",
  "No preference"          = "steelblue",
  "Prefer status quo"      = "slateblue3"
)

# Compute share preferring the alternative
alt_order <- df_plot %>%
  filter(comparison == "Prefer alternative") %>%
  arrange(prop) %>%
  pull(alternative)

# Reorder factor levels
df_plot <- df_plot %>%
  mutate(alternative = factor(alternative, levels = alt_order))

# Horizontal stacked bar plot
p <- ggplot(df_plot, aes(y = alternative, x = prop, fill = comparison)) +
  geom_bar(stat = "identity", color = "white") +
  scale_fill_manual(
    values = cols,
    name = "",
    guide = guide_legend(reverse = TRUE)
  ) +
  labs(
    y = "Alternative allocation procedures",
    x = "Share of respondents"
  ) +
  geom_vline(xintercept = 0.5, linetype = "dashed", color = "black", size = 0.5) + scale_x_continuous(labels = scales::percent_format()) +
  coord_cartesian(expand = FALSE) +
  theme_ipsum(base_size = 14) +
  theme(
    legend.position = "top",
    panel.grid.minor = element_blank(),
    plot.margin = unit(rep(15, 4), "pt")  
  )

ggsave(filename = "figureA13.jpeg", plot = p, width = 10, height = 4, dpi = 800, units = "in", device = "jpeg")

## current distribution of asylum-applications
df <- read_excel("migr_asyapp.xlsx", sheet = 2)

# Countries to highlight
highlight <- c("Denmark", "Germany", "Italy", "Greece", "Poland", "Hungary")

# Prepare data
df_plot <- df %>%
  mutate(
    country = ifelse(
      country == "European Union - 27 countries (from 2020)",
      "EU27",
      country
    ),
    country = factor(country),
    highlight = ifelse(country %in% highlight, "highlight", "other"),
    country = fct_reorder(country, -aslapp)   
  )

# Colors
cols <- c("highlight" = "steelblue", "other" = "grey80")

# Plot
jpeg("figureA14.jpeg", width = 10, height = 5, units = "in", res = 800)
ggplot(df_plot, aes(x = country, y = aslapp, fill = highlight)) +
  geom_col() +
  scale_fill_manual(values = cols, guide = "none") +
  labs(x = "Country", y = "Asylum applications (per 1000 persons)") +
  theme_ipsum(base_size = 14) +
  theme(
    axis.text.x = element_text(angle = 60, hjust = 1),
    panel.grid.major.x = element_blank(),   
    panel.grid.minor.x = element_blank()   
  )
dev.off()


### Robustness check: Attention check exclusions
# --- Descriptive comparison ---
dist_items <- paste0("fairness_distributive", 1:5)
proc_items <- paste0("fairness_procedural", 1:4)
dist_labels <- c("Population", "Wealth", "Unemployment", "Costs", "Previous intakes")
proc_labels <- c("EU-level key", "State choice", "Refugee choice", "First arrival")

pct_support <- function(data, items, labels) {
  sapply(seq_along(items), function(i) {
    x <- data[[items[i]]]
    round(mean(x[x != 4] > 4, na.rm = TRUE) * 100, 1)
  }) |> setNames(labels)
}

cat("\n=== % Support: Main vs Full ===\n")
cat("Distributive:\n")
print(rbind(Main = pct_support(dataset, dist_items, dist_labels),
            Full = pct_support(dataset_extended, dist_items, dist_labels)))
cat("\nProcedural:\n")
print(rbind(Main = pct_support(dataset, proc_items, proc_labels),
            Full = pct_support(dataset_extended, proc_items, proc_labels)))

# --- OLS models (full sample) ---
run_ols <- function(dv, data) {
  lm(as.formula(paste(dv, "~ fairness_objective1 + fairness_objective2 + factor(country)")), data)
}

cat("\n=== OLS: Full sample (clustered SEs) ===\n")
for (dv in c(dist_items, proc_items)) {
  m <- run_ols(dv, dataset_extended)
  se <- sqrt(diag(vcovCL(m, ~country)))
  cat(sprintf("%s: obj1=%.3f(%.3f), obj2=%.3f(%.3f)\n", dv,
              coef(m)["fairness_objective1"], se["fairness_objective1"],
              coef(m)["fairness_objective2"], se["fairness_objective2"]))
}

# --- OLS tables (full sample) ---
ols_dist_ext <- lapply(dist_items, function(dv) run_ols(dv, dataset_extended))
ols_proc_ext <- lapply(proc_items, function(dv) run_ols(dv, dataset_extended))

# Compute clustered SEs
cl_se_dist <- lapply(ols_dist_ext, function(m) sqrt(diag(vcovCL(m, ~country))))
cl_se_proc <- lapply(ols_proc_ext, function(m) sqrt(diag(vcovCL(m, ~country))))

stargazer(ols_dist_ext, type = "latex", out = "table_robustness_OLS_distributive.tex",
          se = cl_se_dist, column.labels = dist_labels, dep.var.labels.include = FALSE,
          keep = c("fairness_objective1", "fairness_objective2"),
          covariate.labels = c("Self-interest", "Fairness"),
          omit.stat = c("f", "ser"), star.cutoffs = c(0.05, 0.01, 0.001),
          notes = "Clustered standard errors by country in parentheses.")

stargazer(ols_proc_ext, type = "latex", out = "tableA4.tex",
          se = cl_se_proc, column.labels = proc_labels, dep.var.labels.include = FALSE,
          keep = c("fairness_objective1", "fairness_objective2"),
          covariate.labels = c("Self-interest", "Fairness"),
          omit.stat = c("f", "ser"), star.cutoffs = c(0.05, 0.01, 0.001),
          notes = "Clustered standard errors by country in parentheses.")

# --- Logistic models (full sample) ---
dataset_extended <- dataset_extended %>%
  mutate(
    prefers_proc1 = as.integer(fairness_procedural1 > fairness_procedural4),
    prefers_proc2 = as.integer(fairness_procedural2 > fairness_procedural4),
    prefers_proc3 = as.integer(fairness_procedural3 > fairness_procedural4),
    prefers_proc5 = as.integer(fairness_procedural5 > fairness_procedural4),
    unfair = (fairness_perc * -1) + 8
  )

cat("\n=== Logistic: Full sample ===\n")
for (dv in c("prefers_proc1", "prefers_proc2", "prefers_proc3", "prefers_proc5")) {
  m <- glm(as.formula(paste(dv, "~ unfair + age + gender + edu + refsupp_norm + country")),
           family = binomial, data = dataset_extended)
  cat(sprintf("%s: unfair=%.3f (p=%.4f)\n", dv, coef(m)["unfair"],
              summary(m)$coefficients["unfair", 4]))
}

# --- Logistic table (full sample) ---
log_dvs <- c("prefers_proc1", "prefers_proc2", "prefers_proc3", "prefers_proc5")
log_labels <- c("Distribution key", "State choice", "Refugee choice", "Quota trading")
log_models_ext <- lapply(log_dvs, function(dv) {
  glm(as.formula(paste(dv, "~ unfair + age + gender + edu + refsupp_norm + country")),
      family = binomial, data = dataset_extended)
})

# Compute clustered SEs
cl_se_log <- lapply(log_models_ext, function(m) sqrt(diag(vcovCL(m, ~country))))

stargazer(log_models_ext, type = "latex", out = "tableA5.tex",
          se = cl_se_log, column.labels = log_labels, dep.var.labels.include = FALSE,
          keep = c("unfair", "age", "gender", "edu", "refsupp_norm"),
          covariate.labels = c("Perceived unfairness", "Age", "Gender (male)", "Education (low)", "Refugee attitudes"),
          omit.stat = c("aic", "ll"), star.cutoffs = c(0.05, 0.01, 0.001),
          notes = "Clustered standard errors by country in parentheses.")

# --- Fixed-effects model (full sample) ---
dataset_extended <- dataset_extended %>% mutate(respondent_id = row_number())

dataset_extended_long <- dataset_extended %>%
  pivot_longer(cols = starts_with("fairness_distributive"), names_to = "principle", values_to = "support") %>%
  mutate(share = case_when(
    principle == "fairness_distributive1" ~ population_share,
    principle == "fairness_distributive2" ~ gdp_share,
    principle == "fairness_distributive3" ~ unemployment_share,
    principle == "fairness_distributive4" ~ costs_share,
    principle == "fairness_distributive5" ~ previous_intakes_share
  ))

model_fe_ext <- feols(support ~ share | respondent_id, data = dataset_extended_long)

cat("\n=== Fixed-effects: Main vs Full ===\n")
cat(sprintf("Main: b=%.3f, SE=%.3f\n", coef(model_fe)["share"], se(model_fe)["share"]))
cat(sprintf("Full: b=%.3f, SE=%.3f\n", coef(model_fe_ext)["share"], se(model_fe_ext)["share"]))

# --- T-tests: Main vs Full sample ---
fairness_vars <- c(dist_items, paste0("fairness_procedural", 1:5))
fairness_labels <- c(dist_labels, "EU-level key", "State choice", "Refugee choice", "First arrival", "Quota trading")

cat("\n=== T-tests: Main vs Full ===\n")
for (i in seq_along(fairness_vars)) {
  tt <- t.test(dataset[[fairness_vars[i]]], dataset_extended[[fairness_vars[i]]])
  sig <- ifelse(tt$p.value < 0.001, "***", ifelse(tt$p.value < 0.01, "**", ifelse(tt$p.value < 0.05, "*", "")))
  cat(sprintf("%-20s diff=%.3f p=%.4f %s\n", fairness_labels[i],
              mean(dataset[[fairness_vars[i]]], na.rm=T) - mean(dataset_extended[[fairness_vars[i]]], na.rm=T),
              tt$p.value, sig))
}

# --- Figure A15: Mean comparison plot ---
compute_summary <- function(data, vars, labels, sample_name) {
  bind_rows(lapply(seq_along(vars), function(i) {
    x <- na.omit(data[[vars[i]]])
    data.frame(Variable = labels[i], Mean = mean(x), 
               CI_low = mean(x) - 1.96*sd(x)/sqrt(length(x)),
               CI_high = mean(x) + 1.96*sd(x)/sqrt(length(x)), Sample = sample_name)
  }))
}

df_plot <- bind_rows(
  compute_summary(dataset, fairness_vars, fairness_labels, "Main sample (N = 10,200)"),
  compute_summary(dataset_extended, fairness_vars, fairness_labels, "Full sample (N = 11,937)")
) %>% mutate(Variable = factor(Variable, levels = rev(fairness_labels)))

png("figureA15.png", width = 8, height = 6, units = "in", res = 800)
ggplot(df_plot, aes(x = Mean, y = Variable, color = Sample, shape = Sample)) +
  geom_pointrange(aes(xmin = CI_low, xmax = CI_high), position = position_dodge(0.5), size = 0.5) +
  scale_color_manual(values = c("steelblue4", "lightsteelblue3")) +
  labs(x = "Mean score (1-7)", y = NULL) +
  theme_ipsum(base_size = 11) + theme(legend.position = "bottom")
dev.off()
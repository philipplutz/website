## Replication Code
## Title: Europe’s immigration divide: Multi-dimensional responsibility-sharing as a solution?
## Authors: Philipp Lutz & Maud Bachelet, University of Geneva

# Date: 16.02.2026

# Load required packages
required_packages <- c(
  "foreign", "Hmisc", "ggplot2", "readstata13", "corrplot",
  "sjPlot", "sjmisc", "sjstats", "lme4", "haven",
  "performance", "countrycode", "reshape2", "ggpubr",
  "stargazer", "sf", "jtools", "gridExtra", "ggrepel",
  "scales", "RColorBrewer", "eurostat", "readxl",
  "psych", "GPArotation", "ggcorrplot", "gtools",
  "dendextend", "dplyr",  "tidyr", "lmtest", "modelsummary",
  "ggtext", "stringr", "ggeffects", "knitr",
  "kableExtra", "clubSandwich", "MASS", "emmeans",
  "broom", "purrr", "sandwich", "multiwayvcov",
  "dotwhisker", "effects", "cjoint", "hrbrthemes"
)
# Note: hrbrthemes is removed from CRAN; install from GitHub if needed:
#   install.packages("remotes")
#   remotes::install_github("hrbrmstr/hrbrthemes")

# Install any missing packages automatically
installed <- rownames(installed.packages())
for (pkg in required_packages) {
  if (!(pkg %in% installed)) {
    install.packages(pkg)
  }
  library(pkg, character.only = TRUE)
}

## load data
dataset <- read.csv("dataset.csv")


# prepare variables of responsibility-sharing preferences 
dataset$control <- (dataset$control_eu + dataset$control_int)/2
dataset$protect <- (dataset$ref_norms_eu + dataset$ref_money_eu + dataset$ref_people_eu + dataset$ref_norms_int + dataset$ref_money_int + dataset$ref_people_int)/6
dataset$cont_eu <- (dataset$ref_norms_eu + dataset$ref_money_eu + dataset$ref_people_eu + as.numeric(dataset$control_eu))/4
dataset$cont_int <- (dataset$ref_norms_int + dataset$ref_money_int + dataset$ref_people_int + dataset$control_int)/4
dataset$ref_norms <- (dataset$ref_norms_eu + dataset$ref_norms_int)/2
dataset$ref_money <- (dataset$ref_money_eu + dataset$ref_money_int)/2
dataset$ref_people <- (dataset$ref_people_eu + dataset$ref_people_int)/2
# prepare ideology variables
dataset$Cosmopolitan <- ((dataset$immig_preference-1) + (dataset$european_union-1))/20
dataset$lrs <- (dataset$lrs-1)/10

# create dummy variables of support
convert_to_dummy <- function(x) {
  as.numeric(as.numeric(x) > 4) #
}
convert_to_dummy <- function(x) {
  case_when(
    x >= 1 & x <= 3 ~ 0,  # Values 1-3 become 0
    x >= 5 & x <= 7 ~ 1,  # Values 5-7 become 1
    x == 4 ~ NA_real_      # Value 4 becomes NA
  )
}

# create dummy variables of support
dataset <- dataset %>%
  mutate(
    ref_norms_dummy  = convert_to_dummy(ref_norms),
    ref_money_dummy  = convert_to_dummy(ref_money),
    ref_people_dummy = convert_to_dummy(ref_people),
    cont_eu_dummy = convert_to_dummy(cont_eu),
    cont_int_dummy = convert_to_dummy(cont_int),
    control_dummy = convert_to_dummy(control),
    protect_dummy = convert_to_dummy(protect)
  )

### main analysis

# descriptive analysis of responsibility-sharing support
means1 <- dataset %>%
  dplyr::select(country, control_dummy, protect_dummy) %>%      
  pivot_longer(
    cols = c(control_dummy, protect_dummy),
    names_to = "treatment",
    values_to = "value"
  ) %>%
  group_by(country, treatment) %>%
  summarise(
    mean_value = mean(value, na.rm = TRUE),
    .groups = "drop"
  ) %>%
  mutate(
    country = factor(country, levels = c("Germany", "Denmark", "Italy", "Greece", "Poland", "Hungary"))
  )

fig1a <- ggplot(means1, aes(x = country, y = mean_value, fill = treatment)) +
  geom_bar(stat = "identity", position = position_dodge()) +  
  labs(
    title = "A. Field of responsibility-sharing",
    x = "Country",
    y = "Support Responsibility-Sharing (in %)"
  ) +
  scale_fill_manual(
    values = c("control_dummy" = "#1f77b4", "protect_dummy" = "#ff7f0e"),
    labels = c("control_dummy" = "Control", "protect_dummy" = "Protection"),
    name = NULL
  ) +
  theme_ipsum() +
  theme(
    legend.position = "top",
    panel.grid.major.x = element_blank(),  
    panel.grid.minor.x = element_blank(),   
    plot.margin = margin(5, 5, 5, 5) 
  ) +
  geom_hline(yintercept = 0.5, linetype = "solid", color = "gray20", alpha=0.5, lwed=0.4) +  
  scale_y_continuous(labels = scales::percent_format(accuracy = 1)) +
  geom_vline(xintercept = c(2.5, 4.5), linetype = "dotted", color = "black") +
  annotate("text", x = 1.5, y = 1.05, label = "North", fontface = "bold", size = 4) +
  annotate("text", x = 3.5, y = 1.05, label = "South", fontface = "bold", size = 4) +
  annotate("text", x = 5.5, y = 1.05, label = "East", fontface = "bold", size = 4)

means2 <- dataset %>%
  dplyr::select(country, cont_eu_dummy, cont_int_dummy) %>%       
  pivot_longer(
    cols = c(cont_eu_dummy, cont_int_dummy),
    names_to = "treatment",
    values_to = "value"
  ) %>%
  group_by(country, treatment) %>%
  summarise(
    mean_value = mean(value, na.rm = TRUE),
    .groups = "drop"
  ) %>%
  mutate(
    country = factor(country, levels = c("Germany", "Denmark", "Italy", "Greece", "Poland", "Hungary"))
  )

fig1b <- ggplot(means2, aes(x = country, y = mean_value, fill = treatment)) +
  geom_bar(stat = "identity", position = position_dodge()) +
  labs(
    title = "B. Level of responsibility-sharing",
    x = "Country",
    y = "Support Responsibility-Sharing (in %)"
  ) +
  scale_fill_manual(
    values = c("cont_eu_dummy" = "#1f77b4", "cont_int_dummy" = "#ff7f0e"),
    labels = c("cont_eu_dummy" = "European", "cont_int_dummy" = "International"),
    name = NULL
  ) +
  theme_ipsum() +
  theme(
    legend.position = "top",
    panel.grid.major.x = element_blank(),
    panel.grid.minor.x = element_blank(),
    plot.margin = margin(5, 5, 5, 5) 
  ) +
  geom_hline(yintercept = 0.5, linetype = "solid", color = "gray20", alpha=0.5, lwd = 0.4) +
  scale_y_continuous(labels = scales::percent_format(accuracy = 1)) +
  geom_vline(xintercept = c(2.5, 4.5), linetype = "dotted", color = "black") +
  annotate("text", x = 1.5, y = 1.05, label = "North", fontface = "bold", size = 4) +
  annotate("text", x = 3.5, y = 1.05, label = "South", fontface = "bold", size = 4) +
  annotate("text", x = 5.5, y = 1.05, label = "East", fontface = "bold", size = 4)

means3 <- dataset %>%
  dplyr::select(country, ref_norms_dummy, ref_money_dummy, ref_people_dummy) %>%
  pivot_longer(
    cols = c(ref_norms_dummy, ref_money_dummy, ref_people_dummy),
    names_to = "treatment",
    values_to = "value"
  ) %>%
  mutate(
    treatment = recode(treatment,
                       ref_norms_dummy  = "ref_norms",
                       ref_money_dummy  = "ref_money",
                       ref_people_dummy = "ref_people")
  ) %>%
  group_by(country, treatment) %>%
  summarise(
    mean_value = mean(value, na.rm = TRUE),
    .groups = "drop"
  ) %>%
  mutate(
    country = factor(country, levels = c("Germany", "Denmark", "Italy", "Greece", "Poland", "Hungary"))
  )

fig1c <- ggplot(means3, aes(x = country, y = mean_value, fill = treatment)) +
  geom_bar(stat = "identity", position = position_dodge()) +
  labs(title = "C. Mode of responsibility-sharing", x = "Country", y = "Support Responsibility-Sharing (in %)") +
  scale_fill_manual(
    values = c("ref_norms" = "#1f77b4", "ref_money" = "#ff7f0e", "ref_people" = "#2ca02c"),  
    labels = c("ref_norms" = "Norms", "ref_money" = "Money", "ref_people" = "People"),  
    name = NULL 
  ) +
  geom_hline(yintercept = 0.5, linetype = "solid", color = "gray20", alpha=0.5, lwed=0.4) +  
  scale_y_continuous(labels = scales::percent_format(accuracy = 1)) +
  theme_ipsum() +
  theme(legend.position = "top",
        panel.grid.major.x = element_blank(),  
        panel.grid.minor.x = element_blank(),  
        plot.margin = margin(5, 5, 5, 5) 
  ) +
  geom_vline(xintercept = c(2.5, 4.5), linetype = "dotted", color = "black") +
  annotate("text", x = 1.5, y = 1.05, label = "North", fontface = "bold", size = 4) +
  annotate("text", x = 3.5, y = 1.05, label = "South", fontface = "bold", size = 4) +
  annotate("text", x = 5.5, y = 1.05, label = "East", fontface = "bold", size = 4)

jpeg("figure1.jpeg", width = 18000, height = 6400, res = 1200)
ggarrange(fig1a, fig1b, fig1c, ncol = 3, nrow = 1)
dev.off()

## Descriptive analysis of responsibility-sharing support (original scale)
means1 <- dataset %>%
  dplyr::select(country, control, protect) %>%
  tidyr::pivot_longer(
    cols = c(control, protect),
    names_to = "treatment",
    values_to = "value"
  ) %>%
  dplyr::group_by(country, treatment) %>%
  dplyr::summarise(
    mean_value = mean(value, na.rm = TRUE),  
    .groups = "drop"
  ) %>%
  mutate(
    country = factor(country, levels = c("Germany", "Denmark", "Italy", "Greece", "Poland", "Hungary"))
  )

means2 <- dataset %>%
  dplyr::select(country, cont_eu, cont_int) %>%
  tidyr::pivot_longer(
    cols = c(cont_eu, cont_int),
    names_to = "treatment",
    values_to = "value"
  ) %>%
  dplyr::group_by(country, treatment) %>%
  dplyr::summarise(
    mean_value = mean(value, na.rm = TRUE), 
    .groups = "drop"
  ) %>%
  mutate(
    country = factor(country, levels = c("Germany", "Denmark", "Italy", "Greece", "Poland", "Hungary"))
  )

means3 <- dataset %>%
  dplyr::select(country, ref_norms, ref_money, ref_people) %>%
  pivot_longer(
    cols = c(ref_norms, ref_money, ref_people),
    names_to = "treatment",
    values_to = "value"
  ) %>%
  group_by(country, treatment) %>%
  summarise(
    mean_value = mean(value, na.rm = TRUE),
    .groups = "drop"
  ) %>%
  mutate(
    country = factor(country, levels = c("Germany", "Denmark", "Italy", "Greece", "Poland", "Hungary"))
  )

# Rescale data to 0–6
means1 <- means1 %>% mutate(mean_value_scaled = mean_value - 1)
means2 <- means2 %>% mutate(mean_value_scaled = mean_value - 1)
means3 <- means3 %>% mutate(mean_value_scaled = mean_value - 1)

figA1a <- ggplot(means1, aes(x = country, y = mean_value_scaled, fill = treatment)) +
  geom_bar(stat = "identity", position = position_dodge()) +
  labs(title = "A. Field of responsibility-sharing",
       x = "Country",
       y = "Mean support (1-7 scale)") +
  scale_fill_manual(values = c("control" = "#1f77b4", "protect" = "#ff7f0e"),
                    labels = c("Control", "Protection"),  name = NULL) +
  coord_cartesian(ylim = c(0, 5.5)) +  
  scale_y_continuous(
    breaks = 0:5,
    labels = 1:6  # show original scale
  ) +
  theme_ipsum() +
  theme(
    legend.position = "top",
    panel.grid.major.x = element_blank(),
    panel.grid.minor.x = element_blank(),
    panel.grid.minor.y = element_blank(),  
    plot.margin = margin(5, 5, 5, 5)
  ) +
  geom_hline(yintercept = 3, linetype = "solid", color = "gray20", alpha = 0.5, linewidth = 0.4) +
  geom_vline(xintercept = c(2.5, 4.5), linetype = "dotted", color = "black") +
  annotate("text", x = 1.5, y = 5.7, label = "North", fontface = "bold", size = 4) +
  annotate("text", x = 3.5, y = 5.7, label = "South", fontface = "bold", size = 4) +
  annotate("text", x = 5.5, y = 5.7, label = "East", fontface = "bold", size = 4)


figA1b <- ggplot(means2, aes(x = country, y = mean_value_scaled, fill = treatment)) +
  geom_bar(stat = "identity", position = position_dodge()) +
  labs(title = "B. Level of responsibility-sharing", x = "Country", y = "Mean support (1-7 scale)") +
  scale_fill_manual(
    values = c("cont_eu" = "#1f77b4", "cont_int" = "#ff7f0e"), 
    labels = c("cont_eu" = "European", "cont_int" = "International"),  
    name = NULL)  + 
    coord_cartesian(ylim = c(0, 5.5)) +  
      scale_y_continuous(
        breaks = 0:5,
        labels = 1:6  # show original scale
      ) +
  theme_ipsum() +
  theme(
    legend.position = "top",
    panel.grid.major.x = element_blank(),  
    panel.grid.minor.x = element_blank(),  
    panel.grid.minor.y = element_blank(),  
    plot.margin = margin(5, 5, 5, 5) 
  ) +
  geom_hline(yintercept = 3, linetype = "solid", color = "gray20", alpha=0.5, lwed=0.4) + 
  geom_vline(xintercept = c(2.5, 4.5), linetype = "dotted", color = "black") +
  annotate("text", x = 1.5, y = 5.7, label = "North", fontface = "bold", size = 4) +
  annotate("text", x = 3.5, y = 5.7, label = "South", fontface = "bold", size = 4) +
  annotate("text", x = 5.5, y = 5.7, label = "East", fontface = "bold", size = 4)

figA1c <- ggplot(means3, aes(x = country, y = mean_value_scaled, fill = treatment)) +
  geom_bar(stat = "identity", position = position_dodge()) +
  labs(title = "C. Mode of responsibility-sharing", x = "Country", y = "Mean support (1-7 scale)") +
  scale_fill_manual(
    values = c("ref_norms" = "#1f77b4", "ref_money" = "#ff7f0e", "ref_people" = "#2ca02c"), 
    labels = c("ref_norms" = "Norms", "ref_money" = "Money", "ref_people" = "People"),  
    name = NULL  
  ) +
  coord_cartesian(ylim = c(0, 5.5)) +  # <- sets axis without dropping data
  scale_y_continuous(
    breaks = 0:5,
    labels = 1:6  # show original scale
  ) +
  theme_ipsum() +
  theme(
    legend.position = "top",
    panel.grid.major.x = element_blank(),  
    panel.grid.minor.x = element_blank(),  
    panel.grid.minor.y = element_blank(),  
    plot.margin = margin(5, 5, 5, 5) 
  ) +
  geom_hline(yintercept = 3, linetype = "solid", color = "gray20", alpha=0.5, lwed=0.4) + 
  geom_vline(xintercept = c(2.5, 4.5), linetype = "dotted", color = "black") +
  annotate("text", x = 1.5, y = 5.7, label = "North", fontface = "bold", size = 4) +
  annotate("text", x = 3.5, y = 5.7, label = "South", fontface = "bold", size = 4) +
  annotate("text", x = 5.5, y = 5.7, label = "East", fontface = "bold", size = 4)

jpeg("figureA1.jpeg", width = 18000, height = 6400, res = 1200)
ggarrange(figA1a, figA1b, figA1c, ncol=3,nrow=1)
dev.off()

## Principled versus conditional support

# ---- Define preference type ----
dataset$preference_type <- "some"
dataset$preference_type[
  dataset$ref_norms_eu < 5 & dataset$ref_norms_int < 5 &
    dataset$ref_money_eu < 5 & dataset$ref_money_int < 5 &
    dataset$ref_people_eu < 5 & dataset$ref_people_int < 5 &
    dataset$control_eu < 5 & dataset$control_int < 5
] <- "none"
dataset$preference_type[
  dataset$ref_norms_eu >= 5 & dataset$ref_norms_int >= 5 &
    dataset$ref_money_eu >= 5 & dataset$ref_money_int >= 5 &
    dataset$ref_people_eu >= 5 & dataset$ref_people_int >= 5 &
    dataset$control_eu >= 5 & dataset$control_int >= 5
] <- "all"

# ---- Prepare data ----
df_pref <- as.data.frame(table(dataset$preference_type, dataset$country))
colnames(df_pref) <- c("Preference", "Country", "Count")

# Factor order for correct stacking
df_pref <- df_pref %>%
  mutate(Preference = factor(Preference, levels = c("all", "some", "none")))

# Sort countries by "all" share
country_order <- df_pref %>%
  filter(Preference == "all") %>%
  arrange(desc(Count)) %>%
  pull(Country)

df_pref <- df_pref %>%
  mutate(Country = factor(Country, levels = country_order))

jpeg("figure2.jpeg", width = 7200, height = 4800, res = 1200)
ggplot(
  df_pref %>%
    group_by(Country) %>%
    mutate(prop = Count / sum(Count)),
  aes(x = Country, y = Count, fill = Preference)
) +
  geom_bar(stat = "identity", position = "fill") +
  geom_text(
    aes(
      label = percent(prop, accuracy = 1)
    ),
    position = position_fill(vjust = 0.5),
    color = "white",
    size = 3.5
  ) +
  scale_fill_brewer(palette = "Dark2", direction = 1) +
  labs(
    x = "Country",
    y = "Proportion",
    fill = "Preferred contributions"
  ) +
  theme_ipsum() +
  theme(
    plot.margin = margin(15, 15, 15, 15),
    legend.position = "top"
  ) +
  guides(fill = guide_legend(reverse = TRUE)) +
  coord_flip() +
  scale_y_continuous(
    labels = scales::percent_format(accuracy = 1),
    expand = expansion(mult = c(0, 0))
  )
dev.off()


## Anaylsis of relative support

# Rename variables for readability
variable_labels <- c(
  "ref_norms_eu"  = "Norm-sharing (EU)",
  "ref_norms_int" = "Norm-sharing (int.)",
  "ref_money_eu"  = "Money-sharing (EU)",
  "ref_money_int" = "Money-sharing (int.)",
  "ref_people_eu" = "People-sharing (EU)",
  "ref_people_int"= "People-sharing (int.)",
  "control_eu"    = "Border control (EU)",
  "control_int"   = "Border control (int.)"
)
indicator_labels <- names(variable_labels)
# Convert all indicator variables to numeric
dataset <- dataset %>%
  mutate(across(all_of(indicator_labels), ~as.numeric(.x)))

# Compute cluster-level summary statistics
summary_stats <- dataset %>%
  group_by(cluster) %>%
  summarise(across(all_of(indicator_labels), 
                   list(mean = ~mean(.x, na.rm = TRUE)), 
                   .names = "{.col}_mean")) %>%
  pivot_longer(cols = -cluster, 
               names_to = "variable",
               names_pattern = "(.+)_mean",
               values_to = "mean_cluster")

# Compute overall mean for each variable
overall_means <- dataset %>%
  summarise(across(all_of(indicator_labels), 
                   ~mean(.x, na.rm = TRUE), 
                   .names = "{.col}_mean")) %>%
  pivot_longer(cols = everything(), 
               names_to = "variable",
               names_pattern = "(.+)_mean",
               values_to = "mean_overall")

# Merge summary_stats with overall_means
summary_stats <- left_join(summary_stats, overall_means, by = "variable") %>%
  mutate(relative_mean = mean_cluster - mean_overall) %>%
  mutate(variable = factor(variable, levels = names(variable_labels), labels = variable_labels))

# Reverse sorting: lowest to highest overall mean
variable_order <- overall_means %>%
  arrange(mean_overall) %>%
  pull(variable) %>%
  factor(levels = ., labels = variable_labels[.])  # Ensure labels match

# Apply the sorted order to the variable column
summary_stats1 <- summary_stats %>%
  mutate(variable = factor(variable, levels = levels(variable_order)))

# Create horizontal bar plots for each cluster with diverging colors
plots_between <- ggplot(summary_stats1, aes(y = variable, x = relative_mean, fill = relative_mean)) +
  geom_col() +
  facet_wrap(~cluster) +  
  scale_fill_gradient2(low = "firebrick3", mid = "grey80", high = "darkgreen", midpoint = 0, breaks = c(-0.5, 0, 0.5, 1), limits = c(-0.7, 1.2)) + #fix the legend scale
  geom_bar(aes(fill = relative_mean), stat = "identity", color = "black", linewidth = 0.3) +
  labs(title = "Relative support between regions",
       x = "Difference from overall mean",
       y = "Dimension",
       fill = "Deviation") +
  theme_ipsum() +
  theme(axis.text.y = element_text(size = 10),
        panel.grid.major.y = element_line(linetype = "dotted"),
        panel.grid.minor.y = element_blank(),
        plot.title.position = "plot",  
        plot.title = element_text(hjust = 0),  
        plot.margin = margin(5, 5, 5, 5) 
  )  

## same but within clusters

# Ensure 'cluster' is a factor
dataset <- dataset %>%
  mutate(cluster = as.factor(cluster))
# Compute cluster-level summary statistics
summary_stats <- dataset %>%
  group_by(cluster) %>%
  summarise(across(all_of(indicator_labels), 
                   list(mean = ~mean(.x, na.rm = TRUE)), 
                   .names = "{.col}_mean")) %>%
  pivot_longer(cols = -cluster, 
               names_to = "variable",
               names_pattern = "(.+)_mean",
               values_to = "mean_cluster")

# Compute the mean of all variables within each cluster
cluster_means <- summary_stats %>%
  group_by(cluster) %>%
  summarise(cluster_mean = mean(mean_cluster, na.rm = TRUE))

# Merge summary_stats with cluster_means
summary_stats <- left_join(summary_stats, cluster_means, by = "cluster") %>%
  mutate(relative_mean = mean_cluster - cluster_mean)  %>%
  mutate(variable = factor(variable, levels = names(variable_labels), labels = variable_labels))

# Reverse sorting: lowest to highest mean within clusters
variable_order <- summary_stats %>%
  group_by(variable) %>%
  summarise(mean_value = mean(mean_cluster, na.rm = TRUE)) %>%
  arrange(mean_value) %>%
  pull(variable) %>%
  factor(levels = ., labels = variable_labels[.])

# Apply the sorted order to the variable column
summary_stats2 <- summary_stats %>%
  mutate(variable = factor(variable, levels = levels(variable_order)))

# Create horizontal bar plots for each cluster with diverging colors
plots_within <- ggplot(summary_stats2, aes(y = variable, x = relative_mean, fill = relative_mean)) +
  geom_col() +
  facet_wrap(~cluster) +  
  scale_fill_gradient2(low = "firebrick3", mid = "grey80", high = "darkgreen", midpoint = 0) +
  geom_bar(aes(fill = relative_mean), stat = "identity", color = "black", linewidth = 0.3) +
  labs(
    title = "Relative support within regions",
    x = "Difference from region mean",
    y = "Dimension",
    fill = "Deviation"
  ) +
  theme_ipsum() +
  theme(
    axis.text.y = element_text(size = 10),
    panel.grid.major.y = element_line(linetype = "dotted"),
    panel.grid.minor.y = element_blank(),
    plot.title.position = "plot",  # 
    plot.title = element_text(hjust = 0),
    plot.margin = margin(5, 5, 5, 5) 
  )

jpeg("figure3.jpeg", width = 12800, height = 6800, res = 1200)
ggarrange(plots_between, plots_within, ncol=1)
dev.off()

## Model estimates

# rescale alll DVs to a common 0-1 scale for comparability
vars_to_rescale <- c("protect", "control", "cont_eu", "cont_int",
                     "ref_norms", "ref_money", "ref_people")
dataset[vars_to_rescale] <- lapply(dataset[vars_to_rescale], \(x) {
  if (is.numeric(x)) (x - min(x, na.rm = TRUE)) / (max(x, na.rm = TRUE) - min(x, na.rm = TRUE))
  else x
})

# calculate ICC
null1 <- lmer(protect ~ 1 + (1 | country), data = dataset)
null2 <- lmer(control ~ 1 + (1 | country), data = dataset)
null3 <- lmer(cont_eu ~ 1 + (1 | country), data = dataset)
null4 <- lmer(cont_int ~ 1 + (1 | country), data = dataset)
null5 <- lmer(ref_norms ~ 1 + (1 | country), data = dataset)
null6 <- lmer(ref_money ~ 1 + (1 | country), data = dataset)
null7 <- lmer(ref_people ~ 1 + (1 | country), data = dataset)
sapply(list(null1, null2, null3, null4, null5, null6, null7), function(m) icc(m)$ICC_unadjusted)

# base models (multilevel)
model1 <- lmer(protect ~ East + South + Cosmopolitan + (1 | country), data = dataset)
summary(model1)
model2 <- lmer(control ~ East + South + Cosmopolitan + (1 | country), data = dataset)
summary(model2)
model3 <- lmer(cont_eu ~ East + South + Cosmopolitan + (1 | country), data = dataset)
summary(model3)
model4 <- lmer(cont_int ~ East + South + Cosmopolitan + (1 | country), data = dataset)
summary(model4)
model5 <- lmer(ref_norms ~ East + South + Cosmopolitan + (1 | country), data = dataset)
summary(model5)
model6 <- lmer(ref_money ~ East + South + Cosmopolitan + (1 | country), data = dataset)
summary(model6)
model7 <- lmer(ref_people ~ East + South + Cosmopolitan + (1 | country), data = dataset)
summary(model7)

# Table A2 (model ouput)
stargazer(model1, model2, model3, model4, model5, model6, model7,
          type = "latex",  # 
          title = "Multivariate regression model estimates", 
          dep.var.labels = c("Refugee protection", "Migration control", 
                             "European Union", "International", 
                             "Norm sharing", "Money sharing", "People sharing"), 
          covariate.labels = c("East", "South", "Cosmopolitan"),
          dep.var.caption = "",
          model.numbers = TRUE,
          star.cutoffs = c(0.05, 0.01, 0.001),
          omit.stat = c("f", "ser"),  # 
          notes.append = TRUE,
          notes.align = "l",
          digits = 2,  
          align = TRUE,  
          no.space = TRUE,  
          column.sep.width = "3pt"  
)

# Panel A: Field of responsibility-sharing
models_pc <- list(
  "Protection" = model1,
  "Control"    = model2
)

p1 <-modelplot(models_pc,
                      coef_omit = "(Intercept)",
                      coef_map = c(
                        "Cosmopolitan" = "Cosmopolitan\n(vs. Communitarian)",
                        "South" = "South\n(vs. North)",
                        "East"  = "East\n(vs. North)"
                      )) +
  labs(color = "", title = "A. Field of responsibility-sharing") +
  scale_color_manual(
    values = c("Control" = "#1f77b4", "Protection" = "#ff7f0e"),
    labels = c("Protection", "Control")
  ) +
  geom_vline(xintercept = 0, linetype = "solid", color = "black", linewidth = 0.8) +
  theme_ipsum() +
  theme(
    plot.margin = margin(5, 5, 5, 5),
    axis.text.y = element_text(size = 12),  # <- replace element_markdown()
    legend.position = "top",
    plot.title.position = "plot",
    panel.grid.major.y = element_line(linetype = "dotted", color = "grey60")
  )


# Panel B: Level of responsibility-sharing
modelsB <- list(
  "EU"  = model3,
  "International"  = model4
)

p2 <- modelplot(modelsB,
                coef_omit = "(Intercept)",
                coef_map = c(
                  "Cosmopolitan" = "Cosmopolitan\n(vs. Communitarian)",
                  "South"        = "South\n(vs. North)",
                  "East"         = "East\n(vs. North)"
                )) +
  labs(color = "", title = "B. Level of responsibility-sharing") +
  scale_color_manual(
    values = c("EU" = "#1f77b4", "International" = "#ff7f0e"),
    labels = c("EU", "International")
  ) +
  geom_vline(xintercept = 0, linetype = "solid", color = "black", linewidth = 0.8) +
  theme_ipsum() +
  theme(
    plot.margin = margin(5, 5, 5, 5),
    axis.text.y = element_text(size = 12),  # <- no markdown
    legend.position = "top",
    plot.title.position = "plot",
    panel.grid.major.y = element_line(linetype = "dotted", color = "grey60")
  )

# Panel C: Mode of responsibility-sharing
modelsC <- list(
  "Norms"  = model5,
  "Money"  = model6,
  "People" = model7
)

p3 <- modelplot(modelsC,
                coef_omit = "(Intercept)",
                coef_map = c(
                  "Cosmopolitan" = "Cosmopolitan\n(vs. Communitarian)",
                  "South"        = "South\n(vs. North)",
                  "East"         = "East\n(vs. North)"
                )) +
  labs(color = "", title = "C. Mode of responsibility-sharing") +
  scale_color_manual(
    values = c("Norms" = "#1f77b4", "Money" = "#ff7f0e", "People" = "#2ca02c"),
    labels = c("Norms", "Money", "People")
  ) +
  geom_vline(xintercept = 0, linetype = "solid", color = "black", linewidth = 0.8) +
  theme_ipsum() +
  theme(
    plot.title.position = "plot",
    plot.margin = margin(5, 5, 5, 5),
    axis.text.y = element_text(size = 12),  # <- replace markdown
    legend.position = "top",
    panel.grid.major.y = element_line(linetype = "dotted", color = "grey60")
  )

# Combine and save
jpeg("figure4.jpeg", width = 15200, height = 3800, res = 1200)
#grid.arrange(p1, p2, p3, ncol = 3)
library(patchwork)
p1+p2+p3+plot_layout(axis_titles = "collect_x")
dev.off()

## Conjoint experiment

# Create conjoint dataset
dataset_long <- dataset %>%
  mutate(Respondent_ID = row_number()) %>%
  mutate(across(starts_with("profile"), as.numeric)) %>%
  pivot_longer(
    cols = starts_with("profile"),
    names_to = "Profile",
    values_to = "Choice"
  ) %>%
  mutate(
    protect = case_when(
      Profile == "profile1A" ~ protectA,
      Profile == "profile1B" ~ protectB,
      Profile == "profile2C" ~ protectC,
      Profile == "profile2D" ~ protectD
    ),
    rules = case_when(
      Profile == "profile1A" ~ rulesA,
      Profile == "profile1B" ~ rulesB,
      Profile == "profile2C" ~ rulesC,
      Profile == "profile2D" ~ rulesD
    ),
    border = case_when(
      Profile == "profile1A" ~ borderA,
      Profile == "profile1B" ~ borderB,
      Profile == "profile2C" ~ borderC,
      Profile == "profile2D" ~ borderD
    ),
    Choice = as.numeric(Choice)
  ) %>%
  dplyr::select(country, Respondent_ID, Cosmopolitan, Profile, Choice, protect, rules, border)

# Convert categorical variables to factors
dataset_long <- dataset_long %>%
  mutate(
    protect = as.factor(protect),
    rules = as.factor(rules),
    border = as.factor(border),
    Choice = as.numeric(Choice)  
  )

# multilevel model
model_conjoint <- lmer(Choice ~ protect + border + rules + factor(country) + (1 | Respondent_ID), data = dataset_long)
summary(model_conjoint)

# Table A7
stargazer(model_conjoint,
          title = "Multivariate regression model estimates",
          dep.var.labels = c("Choice"),
          covariate.labels = c("Protection", "Control", "Voluntary rules", "Country: Denmark", 
                               "Country: Germany", "Country: Greece", 
                               "Country: Hungary", "Country: Italy", "Country: Poland"),
          dep.var.caption = "",
          model.numbers = TRUE,
          star.cutoffs = c(0.05, 0.01, 0.001))

## AMCE plot

# Extract coefficients
coef_summary <- summary(model_conjoint)$coefficients

# Get reference levels
ref_protect <- levels(dataset_long$protect)[1]
ref_border <- levels(dataset_long$border)[1]
ref_rules <- levels(dataset_long$rules)[1]

# Create AMCE results for non-reference categories
amce_results <- data.frame(
  term = rownames(coef_summary),
  estimate = coef_summary[, "Estimate"],
  std_error = coef_summary[, "Std. Error"],
  stringsAsFactors = FALSE
) %>%
  filter(term != "(Intercept)", !grepl("^factor\\(country\\)", term)) %>%
  mutate(
    estimate_pct = estimate * 100,
    conf.low_pct = (estimate - 1.96 * std_error) * 100,
    conf.high_pct = (estimate + 1.96 * std_error) * 100,
    # Clean up term names
    term_clean = case_when(
      term == "protectpeople" ~ "People-sharing",
      term == "protectnorms" ~ "Norm-sharing",
      term == "borderinternational" ~ "International",
      term == "rulesvoluntary" ~ "Voluntary",
      TRUE ~ term
    ),
    # Assign factor groups
    factor_group = case_when(
      grepl("^protect", term) ~ "Refugee protection",
      grepl("^border", term) ~ "Border control",
      grepl("^rules", term) ~ "Bindingness",
      TRUE ~ NA_character_
    )
  ) %>%
  filter(!is.na(factor_group))

# Add reference categories (with estimate = 0)
ref_categories <- data.frame(
  term = c(paste0("protect", ref_protect), paste0("border", ref_border), paste0("rules", ref_rules)),
  estimate = c(0, 0, 0),
  std_error = c(0, 0, 0),
  estimate_pct = c(0, 0, 0),
  conf.low_pct = c(0, 0, 0),
  conf.high_pct = c(0, 0, 0),
  term_clean = c(
    "Money-sharing (ref.)",
    paste0(toupper(substring(ref_border, 1, 1)), substring(ref_border, 2), " (ref.)"),
    paste0(toupper(substring(ref_rules, 1, 1)), substring(ref_rules, 2), " (ref.)")
  ),
  factor_group = c("Refugee protection", "Border control", "Bindingness"),
  stringsAsFactors = FALSE
)

# Combine and set factor levels for ordering 
full_results <- bind_rows(amce_results, ref_categories) %>%
  mutate(
    factor_group = factor(factor_group, levels = c("Refugee protection", "Border control", "Bindingness")),
    term_clean = factor(term_clean, levels = rev(c(
      # Refugee protection
      "Money-sharing (ref.)", "People-sharing", "Norm-sharing",
      # Border control
      ref_categories$term_clean[2], "International",
      # Bindingness
      ref_categories$term_clean[3], "Voluntary"
    )))
  ) %>%
  arrange(factor_group, term_clean)

amce_plot <- ggplot(full_results, aes(x = term_clean, y = estimate_pct, color = factor_group)) +
  geom_point(size = 3) +
  geom_errorbar(aes(ymin = conf.low_pct, ymax = conf.high_pct), width = 0.2, linewidth = 0.8) +
  geom_hline(yintercept = 0, linetype = "dashed", color = "gray50") +
  coord_flip() +
  scale_color_manual(
    values = c(
      "Border control" = "#1f77b4",
      "Bindingness" = "#ff7f0e",
      "Refugee protection" = "#2ca02c"
    )
  ) +
  labs(
    title = "A. Average marginal component effects (AMCEs)",
    x = "Feature",
    y = "AMCE (Percentage points)",
    color = "Dimension"
  ) +
  theme_ipsum() +
  theme(
    axis.text = element_text(size = 10),
    plot.title = element_text(size = 18, face = "bold", hjust = 0),
    plot.title.position = "plot",
    legend.position = "top",
    panel.grid.major.y = element_line(linetype = "dotted", color = "gray80"),
    plot.margin = margin(5, 5, 5, 5)
  )

# Get marginal means for each factor separately from the multilevel model
emm_protect   <- as.data.frame(emmeans(model_conjoint, ~ protect))
emm_rules  <- as.data.frame(emmeans(model_conjoint, ~ rules))
emm_border <- as.data.frame(emmeans(model_conjoint, ~ border))

# Add identifying columns
emm_protect <- emm_protect %>%
  mutate(Factor = "protect", Predictor = as.character(protect))
emm_rules <- emm_rules %>%
  mutate(Factor = "rules", Predictor = as.character(rules))
emm_border <- emm_border %>%
  mutate(Factor = "border", Predictor = as.character(border))

# Combine all results
pred_all <- bind_rows(emm_protect, emm_rules, emm_border) %>%
  mutate(Factor = factor(Factor, levels = c("protect", "border", "rules")))

# Create facet labels
facet_labels <- c(
  protect = "Refugee protection",
  border = "Border control",
  rules = "Bindingness"
)

pred_plot <- ggplot(pred_all, aes(x = Predictor, y = emmean, color = Factor)) +
  geom_point(size = 3) +
  geom_errorbar(aes(ymin = asymp.LCL, ymax = asymp.UCL), width = 0.2, linewidth = 0.8) +
  facet_wrap(~ Factor, scales = "free_x", labeller = as_labeller(facet_labels)) +
  scale_color_manual(
    values = c("protect" = "#2ca02c", "border" = "#1f77b4", "rules" = "#ff7f0e")
  ) +
  labs(
    title = "B. Marginal means (predicted support)",
    y = "Predicted support (marginal mean)",
    color = ""
  ) +
  theme_ipsum() +
  theme(
    axis.title.x = element_blank(),
    legend.position = "none",
    plot.title = element_text(size = 18, face = "bold", hjust = 0),
    panel.grid.major = element_line(linetype = "dotted", color = "grey60"),
    panel.grid.major.x = element_blank(),
    plot.margin = margin(5, 5, 5, 5),
    plot.title.position = "plot"
  )

jpeg("figure5.jpeg", width = 16000, height = 6000, res = 1200)
ggarrange(amce_plot,pred_plot)
dev.off()


### Appendix: Additional analyses

## Dendrogram

# Ensure variables are numeric
variable_matrix <- dataset %>%
  dplyr::select(all_of(names(variable_labels))) %>%
  tidyr::drop_na() %>%
  as.matrix()

# Compute distance matrix and hierarchical clustering
dist_variables <- dist(t(variable_matrix))  # Transpose to cluster variables
hc_variables <- hclust(dist_variables, method = "ward.D2")

# Convert to dendrogram
dend <- as.dendrogram(hc_variables)

# Assign correct labels from variable_labels
labels(dend) <- variable_labels[labels(dend)]

# Define a color palette for four clusters
dend <- color_branches(dend, k = 4)  # Four clusters
dend <- color_labels(dend, k = 4)    # Color the labels accordingly

# Prepare the data matrix
variable_matrix <- dataset %>%
  dplyr::select(all_of(names(variable_labels))) %>%
  tidyr::drop_na() %>%
  as.matrix()

# Compute distance matrix and hierarchical clustering
dist_variables <- dist(t(variable_matrix))  # Transpose to cluster variables
hc_variables <- hclust(dist_variables, method = "ward.D2")

# Convert to dendrogram
dend <- as.dendrogram(hc_variables)

# Assign correct labels from variable_labels
labels(dend) <- variable_labels[labels(dend)]

# Define custom color palette using your colors
# Create a gradient from blue to orange for the clusters
cluster_colors <- c("#1f77b4", "#2ca02c", "#d62728", "#ff7f0e")

# Color branches and labels with 4 clusters
dend <- color_branches(dend, k = 4, col = cluster_colors)
dend <- color_labels(dend, k = 4, col = cluster_colors)

jpeg("figureA2.jpeg", width = 7800, height = 5200, res = 1200)
par(mar = c(5, 1, 1, 7), family = "sans", cex = 1, lwd = 3)
plot(dend, 
     horiz = TRUE,
     nodePar = list(lab.cex = 0.9, pch = NA, col = "#2C3E50"),
     edgePar = list(lwd = 3.5),
     xlab = "Height (Ward's Distance)",
     cex.lab = 1.1,
     col.lab = "#2C3E50")
abline(v = seq(0, max(dist_variables), length.out = 10), 
       col = "gray90", lty = 2, lwd = 0.5)
dev.off()

# ---- Asylum-only ----
dataset$preference_type_asylum <- "some"
dataset$preference_type_asylum[
  dataset$ref_norms_eu < 5 & dataset$ref_norms_int < 5 &
    dataset$ref_money_eu < 5 & dataset$ref_money_int < 5 &
    dataset$ref_people_eu < 5 & dataset$ref_people_int < 5
] <- "none"
dataset$preference_type_asylum[
  dataset$ref_norms_eu >= 5 & dataset$ref_norms_int >= 5 &
    dataset$ref_money_eu >= 5 & dataset$ref_money_int >= 5 &
    dataset$ref_people_eu >= 5 & dataset$ref_people_int >= 5
] <- "all"

df_pref2 <- as.data.frame(table(dataset$preference_type_asylum, dataset$country))
colnames(df_pref2) <- c("Preference", "Country", "Count")

df_pref2 <- df_pref2 %>%
  mutate(
    Preference = factor(Preference, levels = c("all", "some", "none")),
    Country = factor(Country, levels = country_order)
  )

p2 <- ggplot(
  df_pref2 %>%
    group_by(Country) %>%
    mutate(prop = Count / sum(Count)),
  aes(x = Country, y = Count, fill = Preference)
) +
  geom_bar(stat = "identity", position = "fill") +
  geom_text(
    aes(label = percent(prop, accuracy = 1)),
    position = position_fill(vjust = 0.5),
    color = "white",
    size = 3.5
  ) +
  scale_y_continuous(
    labels = percent_format(accuracy = 1),
    expand = expansion(mult = c(0, 0))
  ) +
  scale_fill_brewer(palette = "Dark2", direction = 1) +
  labs(
    x = "Country",
    y = "Proportion",
    fill = "Preferred contributions"
  ) +
  theme_ipsum(base_size = 14) +
  theme(
    plot.margin = margin(5, 5, 5, 5),
    legend.position = "right"
  ) +
  guides(fill = guide_legend(reverse = TRUE)) +
  coord_flip()

jpeg("figureA3.jpeg", width = 8000, height = 4000, res = 1200)
p2 +
  scale_y_continuous(
    labels = scales::percent_format(accuracy = 1),
    expand = expansion(mult = c(0, 0))
  )
dev.off()

# Enhanced function to create dendrogram with custom colors
create_dendrogram <- function(df) {
  # Subset only the 8 variables
  df_vars <- df[, intersect(names(df), names(variable_labels)), drop = FALSE]
  
  # Convert to numeric and drop rows with NAs
  df_vars[] <- lapply(df_vars, function(x) as.numeric(as.character(x)))
  df_vars <- na.omit(df_vars)
  
  # Scale and compute variable correlations
  scaled_vars <- scale(df_vars)
  cor_vars <- cor(scaled_vars, use = "pairwise.complete.obs")
  
  # Distance matrix and clustering
  dist_vars <- as.dist(1 - cor_vars)
  hc <- hclust(dist_vars, method = "ward.D2")
  dend <- as.dendrogram(hc)
  
  # Relabel variable names with descriptive labels
  labels(dend) <- variable_labels[labels(dend)]
  
  # Color branches and labels (3 clusters for better visualization)
  cluster_colors <- c("#1f77b4", "#2ca02c", "#ff7f0e")
  dend <- color_branches(dend, k = 3, col = cluster_colors, lwd = 3)  # Add lwd here
  dend <- color_labels(dend, k = 3, col = cluster_colors)
  
  return(dend)
}

# Split data and apply function
country_dendrograms <- split(dataset, dataset$country)
country_dendrograms <- lapply(country_dendrograms, create_dendrogram)

jpeg("figureA4.jpeg", width = 12000, height = 6800, res = 1200)
par(mfrow = c(2, 3),                # Layout for 6 plots
    mar = c(5, 2, 2, 8),           # Increased right margin
    family = "sans",                 # Clean font
    oma = c(0, 0, 2, 0))            # Outer margin for overall title
# Plot each country dendrogram
for (country in names(country_dendrograms)) {
  plot(country_dendrograms[[country]],
       horiz = TRUE,
       main = country,
       cex.main = 1.3,              # Larger title
       col.main = "#2C3E50",        # Professional title color
       nodePar = list(
         lab.cex = 0.85,            # Label size
         pch = NA,                  # No points at nodes
         col = "#2C3E50"            # Node color
       ),
       xlab = "Height (Ward's Distance)",
       cex.lab = 1,                 # Axis label size
       col.lab = "#2C3E50")         # Axis label color
  # Add subtle grid
  abline(v = seq(0, par("usr")[2], length.out = 8), 
         col = "gray90", 
         lty = 2, 
         lwd = 0.5)
}
dev.off()

## factor analysis
myvars <- c("ref_norms_eu", "ref_norms_int", "ref_money_eu", "ref_money_int", "ref_people_eu", "ref_people_int", "control_eu", "control_int")
resp_pref <- dataset[myvars]

# Compute correlation matrix for all responsibility-sharing items

# Rename variables for better readability
colnames(resp_pref) <- c("EU norms", "Int. norms", 
                         "EU money", "Int. money", 
                         "EU people", "Int. people",
                         "EU control", "Int. control")
colnames(resp_pref) <- c("Norm-sharing (EU)", "Norm-sharing (int.)", 
                         "Money-sharing (EU)", "Money-sharing (int.)", 
                         "People-sharing (EU)", "People-sharing (int.)",
                         "Border control (EU)", "Border control (int.)")

cor_matrix <- cor(resp_pref, use = "pairwise.complete.obs")

# Convert all columns to numeric (if they are factors/characters)
resp_pref_num <- resp_pref %>%
  mutate(across(everything(), ~ as.numeric(as.character(.))))

# Now scale
resp_pref_std <- scale(resp_pref_num)

# Run factor analysis
fa_result <- fa(resp_pref_std, nfactors = 4, rotate = "oblimin", fm = "ml")

# Extract loadings into a dataframe
loadings_df <- as.data.frame(round(fa_result$loadings[,], 2))

# Table A1
kable(loadings_df, format = "latex", booktabs = TRUE,
      caption = "Factor Loadings for Responsibility-sharing Preferences") %>%
  kable_styling()

# Define a stronger pastel color gradient for contrast
pastel_colors <- colorRampPalette(c("#F1948A", "#FDFEFE", "#5DADE2"))(200)  

# Set up theme_ipsum-inspired styling
par(family = "Arial", mar = c(2, 2, 2, 2))

# Function to calculate correlation p-values
cor.mtest <- function(mat, conf.level = 0.95) {
  mat <- as.matrix(mat)
  n <- ncol(mat)
  p.mat <- matrix(NA, n, n)
  diag(p.mat) <- 0
  
  for (i in 1:(n - 1)) {
    for (j in (i + 1):n) {
      tmp <- cor.test(mat[, i], mat[, j], conf.level = conf.level)
      p.mat[i, j] <- p.mat[j, i] <- tmp$p.value
    }
  }
  colnames(p.mat) <- rownames(p.mat) <- colnames(mat)
  return(list(p = p.mat))
}

# Calculate p-values for significance testing
cor_test <- cor.mtest(resp_pref, conf.level = 0.95)

# Set up plotting parameters for better spacing
par(mar = c(1, 1, 2, 1), family = "sans")

# Enhanced diverging color palette
enhanced_colors <- colorRampPalette(c("#1f77b4", "#7FB3D5", "#BFD9E8", "#E6F2F8",
                                      "white", 
                                      "#FFE5CC", "#FFCB99", "#FFB266", "#ff7f0e"))(200)
# Create the enhanced correlation plot
jpeg("figureA5.jpeg", width = 8000, height = 7200, res = 1200)
corrplot(cor_matrix, 
         method = "color",         # Use color squares (can also try "ellipse" or "circle")
         type = "lower",           # Show lower triangle only
         order = "hclust",         # Hierarchical clustering
         hclust.method = "ward.D2", # Ward's method for clustering
         # Label styling
         tl.col = "#2C3E50",       # Darker, more professional label color
         tl.srt = 45,              # 45-degree angle
         tl.cex = 0.9,             # Label size
         tl.pos = "ld",            # Labels on left and diagonal
         # Color scheme
         col = enhanced_colors,     # Diverging color palette
         # Correlation coefficients
         addCoef.col = "#2C3E50",  # Coefficient color
         number.cex = 0.7,         # Smaller coefficients
         number.digits = 2,        # Two decimal places
         # Legend/color bar
         cl.pos = "b",             # Position below
         cl.cex = 0.9,             # Legend text size
         cl.ratio = 0.15,          # Narrower color bar
         cl.align.text = "l",      # Align text left
         cl.col = "#2C3E50",       # Legend text color
         # Visual enhancements
         diag = FALSE,             # Hide diagonal
         addgrid.col = "gray90",   # Subtle grid lines
         # Title (optional)
         #title = "Correlation Matrix with Hierarchical Clustering",
         mar = c(0, 0, 2, 0))      # Margins
dev.off()

## Density plot region and ideology
cluster_means <- dataset %>%
  group_by(cluster) %>%
  summarise(mean_cosmo = mean(Cosmopolitan, na.rm = TRUE)) %>%
  mutate(line_style = c("solid", "solid", "dashed")) 

jpeg("figureA6.jpeg", width = 16000, height = 6400, res = 1200)
ggplot(dataset, aes(x = Cosmopolitan, fill = cluster)) +
  geom_density(alpha = 0.3, color = NA) +  
  geom_vline(data = cluster_means, 
             aes(xintercept = mean_cosmo, color = cluster, linetype = line_style),
             linewidth = 0.8) +
  scale_fill_manual(values = c("#1f77b4", "#ff7f0e", "#2ca02c")) +
  scale_color_manual(values = c("#1f77b4", "#ff7f0e", "#2ca02c"), 
                     guide = "none") +
  scale_linetype_identity() +  
  labs(
    x = "Cosmopolitanism",
    y = "Density",
    fill = "Region"
  ) +
  theme_ipsum(base_size = 14) +
  theme(
    plot.margin = margin(10, 10, 10, 10),
    legend.position = "top",
    panel.grid.minor = element_blank()
  )
dev.off()

## Models with left-right scale as measure of ideology
m1lrs <- lmer(protect ~ East + South + lrs + (1 | country), data = dataset)
summary(m1lrs)
m2lrs <- lmer(control ~ East + South + lrs + (1 | country), data = dataset)
summary(m2lrs)
m3lrs <- lmer(cont_eu ~ East + South + lrs + (1 | country), data = dataset)
summary(m3lrs)
m4lrs <- lmer(cont_int ~ East + South + lrs + (1 | country), data = dataset)
summary(m4lrs)
m5lrs <- lmer(ref_norms ~ East + South + lrs + (1 | country), data = dataset)
summary(m5lrs)
m6lrs <- lmer(ref_money ~ East + South + lrs + (1 | country), data = dataset)
summary(m6lrs)
m7lrs <- lmer(ref_people ~ East + South + lrs + (1 | country), data = dataset)
summary(m7lrs)

# Table A4
stargazer(m1lrs, m2lrs, m3lrs, m4lrs, m5lrs,m6lrs,m7lrs,
          type = "latex",
          title = "Base models with alternative ideology measure", 
          dep.var.labels = c("Refugee protection", "Migration control", 
                             "European Union", "International", 
                             "Norm sharing", "Money sharing", "People sharing"), 
          covariate.labels = c("East", "South", "Right-wing ideology"),
          dep.var.caption = "",
          model.numbers = TRUE,
          star.cutoffs = c(0.05, 0.01, 0.001),
          omit.stat = c("f", "ser"),
          omit.table.layout = "n",  
          digits = 2,
          align = TRUE,
          no.space = TRUE,
          column.sep.width = "3pt"
)

## Models with control variables
model1c <- lmer(protect ~ East + South + Cosmopolitan + age + gender + edu + (1 | country), data = dataset)
summary(model1c)
model2c <- lmer(control ~ East + South + Cosmopolitan  + age + gender + edu + (1 | country), data = dataset)
summary(model2c)
model3c <- lmer(cont_eu ~ East + South + Cosmopolitan  + age + gender + edu + (1 | country), data = dataset)
summary(model3c)
model4c <- lmer(cont_int ~ East + South + Cosmopolitan  + age + gender + edu + (1 | country), data = dataset)
summary(model4c)
model5c <- lmer(ref_norms ~ East + South + Cosmopolitan  + age + gender + edu + (1 | country), data = dataset)
summary(model5c)
model6c <- lmer(ref_money ~ East + South + Cosmopolitan  + age + gender + edu + (1 | country), data = dataset)
summary(model6c)
model7c <- lmer(ref_people ~ East + South + Cosmopolitan  + age + gender + edu + (1 | country), data = dataset)
summary(model7c)

# Table A3
stargazer(model1c, model2c, model3c, model4c, model5c, model6c, model7c,
          type = "latex",
          title = "Multivariate regression model estimates with controls", 
          dep.var.labels = c("Refugee protection", "Migration control", 
                             "European Union", "International", 
                             "Norm sharing", "Money sharing", "People sharing"), 
          covariate.labels = c("East", "South", "Cosmopolitan", 
                               "Age", "Gender (male)", "Gender (other)", 
                               "Education (low)"),
          dep.var.caption = "",
          model.numbers = TRUE,
          star.cutoffs = c(0.05, 0.01, 0.001),
          omit.stat = c("f", "ser"),
          omit.table.layout = "n",
          digits = 2,
          align = TRUE,
          no.space = TRUE,
          column.sep.width = "3pt"
)

## Models with interaction between region and ideology
model1i <- lmer(protect ~ East*Cosmopolitan + South*Cosmopolitan + (1 | country), data = dataset)
summary(model1i)
model2i <- lmer(control ~ East*Cosmopolitan + South*Cosmopolitan + (1 | country), data = dataset)
summary(model2i)
model3i <- lmer(cont_eu ~ East*Cosmopolitan + South*Cosmopolitan + (1 | country), data = dataset)
summary(model3i)
model4i <- lmer(cont_int ~ East*Cosmopolitan + South*Cosmopolitan + (1 | country), data = dataset)
summary(model4i)
model5i <- lmer(ref_norms ~ East*Cosmopolitan + South*Cosmopolitan + (1 | country), data = dataset)
summary(model5i)
model6i <- lmer(ref_money ~ East*Cosmopolitan + South*Cosmopolitan + (1 | country), data = dataset)
summary(model6i)
model7i <- lmer(ref_people ~ East*Cosmopolitan + South*Cosmopolitan + (1 | country), data = dataset)
summary(model7i)

# Table A5: Multilevel model estimates with interaction terms
stargazer(model1i,model2i,model3i,model4i,model5i,model6i,model7i,
          title="Multivariate regression model estimates with interaction terms", 
          dep.var.labels = c("Refugee protection", "Migration control", 
                             "European Union", "International", 
                             "Norm sharing", "Money sharing", "People sharing"), 
          covariate.labels = c("East", "Cosmopolitan", "South", "East*Cosmopolitan", "South*Cosmopolitan"),
          dep.var.caption = "",
          model.numbers = TRUE,
          star.cutoffs = c(0.05, 0.01, 0.001),
          omit.stat = c("f", "ser"),
          omit.table.layout = "n",  
          digits = 2,
          align = TRUE,
          no.space = TRUE,
          column.sep.width = "3pt"
)


## Estimate linear models (OLS)
field1 <- lm(protect ~ East + South + Cosmopolitan, data = dataset)
summary(field1)
field2 <- lm(control ~ East + South + Cosmopolitan, data = dataset)
summary(field2)
coef_protect <- coeftest(field1, vcov = vcovCR(field1, cluster = dataset$country, type = "CR2"))
se_protect <- coef_protect[, 2]
coef_control <- coeftest(field2, vcov = vcovCR(field2, cluster = dataset$country, type = "CR2"))
se_control <- coef_control[, 2]

level1 <- lm(cont_eu ~ East + South + Cosmopolitan, data = dataset)
summary(level1)
level2 <- lm(cont_int ~ East + South + Cosmopolitan, data = dataset)
summary(level2)
coef_eu <- coeftest(level1, vcov = vcovCR(level1, cluster = dataset$country, type = "CR2"))
se_eu <- coef_eu[, 2]
coef_int <- coeftest(level2, vcov = vcovCR(level2, cluster = dataset$country, type = "CR2"))
se_int <- coef_int[, 2]

mode1 <- lm(ref_norms ~ East + South + Cosmopolitan, data = dataset)
summary(mode1)
mode2 <- lm(ref_money ~ East + South + Cosmopolitan, data = dataset)
summary(mode2)
mode3 <- lm(ref_people ~ East + South + Cosmopolitan, data = dataset)
summary(mode3)
coef_norms <- coeftest(mode1, vcov = vcovCR(mode1, cluster = dataset$country, type = "CR2"))
se_norms <- coef_norms[, 2]
coef_money <- coeftest(mode2, vcov = vcovCR(mode2, cluster = dataset$country, type = "CR2"))
se_money <- coef_money[, 2]
coef_people <- coeftest(mode3, vcov = vcovCR(mode3, cluster = dataset$country, type = "CR2"))
se_people <- coef_people[, 2]

# Table A6: OLS models
stargazer(field1, field2, level1, level2, mode1,mode2,mode3,
          title="Multivariate OLS estimates", 
          dep.var.labels = c("Refugee protection", "Migration control", 
                             "European Union", "International", 
                             "Norm sharing", "Money sharing", "People sharing"), 
          covariate.labels=c("East", "South", "Cosmopolitan"),  
          se=list(se_protect, se_control, se_eu, se_int, se_norms, se_money, se_people),
          dep.var.caption = "",
          model.numbers = TRUE,
          star.cutoffs = c(0.05, 0.01, 0.001),
          omit.stat = c("f", "ser"),
          omit.table.layout = "n",  
          digits = 2,
          align = TRUE,
          no.space = TRUE,
          column.sep.width = "3pt"
)

## plot predicted probabilities

# Panel A: Field of responsibility-sharing
pred_a <- bind_rows(
  # Protection predictions
  ggpredict(model1, terms = c("East [0]", "South [0]")) %>% mutate(outcome = "Protection", group_var = "North"),
  ggpredict(model1, terms = c("East [1]", "South [0]")) %>% mutate(outcome = "Protection", group_var = "East"),
  ggpredict(model1, terms = c("East [0]", "South [1]")) %>% mutate(outcome = "Protection", group_var = "South"),
  ggpredict(model1, terms = "Cosmopolitan [0]") %>% mutate(outcome = "Protection", group_var = "Communitarian"),
  ggpredict(model1, terms = "Cosmopolitan [1]") %>% mutate(outcome = "Protection", group_var = "Cosmopolitan"),
  
  # Control predictions
  ggpredict(model2, terms = c("East [0]", "South [0]")) %>% mutate(outcome = "Control", group_var = "North"),
  ggpredict(model2, terms = c("East [1]", "South [0]")) %>% mutate(outcome = "Control", group_var = "East"),
  ggpredict(model2, terms = c("East [0]", "South [1]")) %>% mutate(outcome = "Control", group_var = "South"),
  ggpredict(model2, terms = "Cosmopolitan [0]") %>% mutate(outcome = "Control", group_var = "Communitarian"),
  ggpredict(model2, terms = "Cosmopolitan [1]") %>% mutate(outcome = "Control", group_var = "Cosmopolitan")
) %>% filter(!is.na(group_var))

# Panel B: Level of responsibility-sharing
pred_b <- bind_rows(
  # EU predictions
  ggpredict(model3, terms = c("East [0]", "South [0]")) %>% mutate(outcome = "EU", group_var = "North"),
  ggpredict(model3, terms = c("East [1]", "South [0]")) %>% mutate(outcome = "EU", group_var = "East"),
  ggpredict(model3, terms = c("East [0]", "South [1]")) %>% mutate(outcome = "EU", group_var = "South"),
  ggpredict(model3, terms = "Cosmopolitan [0]") %>% mutate(outcome = "EU", group_var = "Communitarian"),
  ggpredict(model3, terms = "Cosmopolitan [1]") %>% mutate(outcome = "EU", group_var = "Cosmopolitan"),
  
  # International predictions
  ggpredict(model4, terms = c("East [0]", "South [0]")) %>% mutate(outcome = "International", group_var = "North"),
  ggpredict(model4, terms = c("East [1]", "South [0]")) %>% mutate(outcome = "International", group_var = "East"),
  ggpredict(model4, terms = c("East [0]", "South [1]")) %>% mutate(outcome = "International", group_var = "South"),
  ggpredict(model4, terms = "Cosmopolitan [0]") %>% mutate(outcome = "International", group_var = "Communitarian"),
  ggpredict(model4, terms = "Cosmopolitan [1]") %>% mutate(outcome = "International", group_var = "Cosmopolitan")
) %>% filter(!is.na(group_var))

# Panel C: Mode of responsibility-sharing
pred_c <- bind_rows(
  # Norms predictions
  ggpredict(model5, terms = c("East [0]", "South [0]")) %>% mutate(outcome = "Norms", group_var = "North"),
  ggpredict(model5, terms = c("East [1]", "South [0]")) %>% mutate(outcome = "Norms", group_var = "East"),
  ggpredict(model5, terms = c("East [0]", "South [1]")) %>% mutate(outcome = "Norms", group_var = "South"),
  ggpredict(model5, terms = "Cosmopolitan [0]") %>% mutate(outcome = "Norms", group_var = "Communitarian"),
  ggpredict(model5, terms = "Cosmopolitan [1]") %>% mutate(outcome = "Norms", group_var = "Cosmopolitan"),
  
  # Money predictions
  ggpredict(model6, terms = c("East [0]", "South [0]")) %>% mutate(outcome = "Money", group_var = "North"),
  ggpredict(model6, terms = c("East [1]", "South [0]")) %>% mutate(outcome = "Money", group_var = "East"),
  ggpredict(model6, terms = c("East [0]", "South [1]")) %>% mutate(outcome = "Money", group_var = "South"),
  ggpredict(model6, terms = "Cosmopolitan [0]") %>% mutate(outcome = "Money", group_var = "Communitarian"),
  ggpredict(model6, terms = "Cosmopolitan [1]") %>% mutate(outcome = "Money", group_var = "Cosmopolitan"),
  
  # People predictions
  ggpredict(model7, terms = c("East [0]", "South [0]")) %>% mutate(outcome = "People", group_var = "North"),
  ggpredict(model7, terms = c("East [1]", "South [0]")) %>% mutate(outcome = "People", group_var = "East"),
  ggpredict(model7, terms = c("East [0]", "South [1]")) %>% mutate(outcome = "People", group_var = "South"),
  ggpredict(model7, terms = "Cosmopolitan [0]") %>% mutate(outcome = "People", group_var = "Communitarian"),
  ggpredict(model7, terms = "Cosmopolitan [1]") %>% mutate(outcome = "People", group_var = "Cosmopolitan")
) %>% filter(!is.na(group_var))

# Reorder group_var factor
pred_a$group_var <- factor(pred_a$group_var, levels = c("North", "East", "South", "Communitarian", "Cosmopolitan"))
pred_b$group_var <- factor(pred_b$group_var, levels = c("North", "East", "South", "Communitarian", "Cosmopolitan"))
pred_c$group_var <- factor(pred_c$group_var, levels = c("North", "East", "South", "Communitarian", "Cosmopolitan"))

# Plot A: Field
pp1 <- ggplot(pred_a, aes(x = group_var, y = predicted, fill = outcome)) +
  geom_bar(stat = "identity", position = position_dodge(width = 0.8), width = 0.7) +
  geom_errorbar(aes(ymin = conf.low, ymax = conf.high), 
                position = position_dodge(width = 0.8), 
                width = 0.25,
                linewidth = 0.5) +
  labs(fill = "", 
       title = "A. Field of responsibility-sharing",
       x = "",
       y = "Predicted probability") +
  scale_fill_manual(
    values = c("Control" = "#1f77b4", "Protection" = "#ff7f0e"),
    labels = c("Control", "Protection")
  ) +
  theme_ipsum() +
  theme(
    plot.margin = margin(5, 5, 5, 5),
    legend.position = "top",
    plot.title.position = "plot",
    panel.grid.major.x = element_blank(),
    panel.grid.major.y = element_line(linetype = "dotted", color = "grey60"),
    axis.text.x = element_text(size = 10)
  )

# Plot B: Level
pp2 <- ggplot(pred_b, aes(x = group_var, y = predicted, fill = outcome)) +
  geom_bar(stat = "identity", position = position_dodge(width = 0.8), width = 0.7) +
  geom_errorbar(aes(ymin = conf.low, ymax = conf.high), 
                position = position_dodge(width = 0.8), 
                width = 0.25,
                linewidth = 0.5) +
  labs(fill = "", 
       title = "B. Level of responsibility-sharing",
       x = "",
       y = "Predicted probability") +
  scale_fill_manual(
    values = c("EU" = "#1f77b4", "International" = "#ff7f0e"),
    labels = c("EU", "International")
  ) +
  theme_ipsum() +
  theme(
    plot.margin = margin(5, 5, 5, 5),
    legend.position = "top",
    plot.title.position = "plot",
    panel.grid.major.x = element_blank(),
    panel.grid.major.y = element_line(linetype = "dotted", color = "grey60"),
    axis.text.x = element_text(size = 10)
  )

# Plot C: Mode
pp3 <- ggplot(pred_c, aes(x = group_var, y = predicted, fill = outcome)) +
  geom_bar(stat = "identity", position = position_dodge(width = 0.8), width = 0.7) +
  geom_errorbar(aes(ymin = conf.low, ymax = conf.high), 
                position = position_dodge(width = 0.8), 
                width = 0.25,
                linewidth = 0.5) +
  labs(fill = "", 
       title = "C. Mode of responsibility-sharing",
       x = "",
       y = "Predicted probability") +
  scale_fill_manual(
    values = c("Norms" = "#1f77b4", "Money" = "#ff7f0e", "People" = "#2ca02c"),
    labels = c("Norms", "Money", "People")
  ) +
  theme_ipsum() +
  theme(
    plot.margin = margin(5, 5, 5, 5),
    legend.position = "top",
    plot.title.position = "plot",
    panel.grid.major.x = element_blank(),
    panel.grid.major.y = element_line(linetype = "dotted", color = "grey60"),
    axis.text.x = element_text(size = 10)
  )

# Combine and save
jpeg("figureA7.jpeg", width = 16800, height = 3800, res = 1200)
ggarrange(pp1, pp2, pp3, ncol = 3)
dev.off()

## Conjoint experiment: predicted probabilities by country

# Nest data by country
nested <- dataset_long %>% 
  group_by(country) %>% 
  nest()

# Fit OLS models and tidy them, keeping correct country labels
country_coefs <- nested %>%
  mutate(model = map(data, ~ lm(Choice ~ protect + border + rules, data = .x)),
         tidy_model = map(model, tidy)) %>%
  dplyr::select(country, tidy_model) %>%
  unnest(cols = tidy_model)  

# Compute 95% CIs
country_coefs <- country_coefs %>%
  mutate(
    conf.low = estimate - 1.96 * std.error,
    conf.high = estimate + 1.96 * std.error
  )

# Create term labels and set factor levels
country_coefs <- country_coefs %>%
  mutate(
    term_label = case_when(
      term == "protectpeople" ~ "People-sharing\n(vs. money-sharing)",
      term == "protectnorms" ~ "Norm-sharing\n(vs. money-sharing)",
      term == "borderinternational" ~ "International border control\n(vs. European)",
      term == "rulesvoluntary" ~ "Voluntary\n(vs. mandatory)",
      TRUE ~ term
    ),
    term_label = factor(term_label, levels = rev(c(
      "People-sharing\n(vs. money-sharing)",
      "Norm-sharing\n(vs. money-sharing)",
      "International border control\n(vs. European)",
      "Voluntary\n(vs. mandatory)"
    ))),
    country = factor(country, levels = c("Denmark", "Germany", "Italy", "Greece", "Poland", "Hungary"))
  )

# Color palette
six_colors <- c(
  "Denmark" = "#2ca02c",
  "Germany" = "#98df8a",
  "Italy" = "#1f77b4",
  "Greece" = "#aec7e8",
  "Poland" = "#ff7f0e",
  "Hungary" = "#ffbb78"
)

jpeg("figureA8.jpeg", width = 12800, height = 3600, res = 1200)
ggplot(country_coefs %>% 
         filter(term %in% c("protectpeople", "protectnorms", "borderinternational", "rulesvoluntary")) %>%
         mutate(country = factor(country, 
                                 levels = rev(c("Denmark", "Germany", "Italy", "Greece", "Poland", "Hungary")))),
       aes(x = term_label, y = estimate, color = country)) +
  geom_point(position = position_dodge(width = 0.7), size = 3) +
  geom_errorbar(aes(ymin = conf.low, ymax = conf.high),
                position = position_dodge(width = 0.7), width = 0.2) +
  scale_x_discrete(limits = rev) +
  coord_flip() +
  geom_hline(yintercept = 0, linetype = "dashed", color = "gray50") +
  scale_color_manual(
    values = six_colors,
    breaks = c("Denmark", "Germany", "Italy", "Greece", "Poland", "Hungary"),  
    labels = c("Denmark", "Germany", "Italy", "Greece", "Poland", "Hungary")
  ) +
  labs(x = "Feature", y = "Effect (AMCE)", color = "Country") +
  theme_ipsum() +
  theme(
    axis.text.y = element_text(hjust = 1),
    legend.position = "right",
    plot.title.position = "plot",
    panel.grid.major.y = element_blank(),
    plot.margin = margin(5, 5, 5, 5)
  )
dev.off()

# Create ideology variable
dataset_long$ideology <- NA
dataset_long$ideology[dataset_long$Cosmopolitan > 0.5] <- "Cosmopolitan"
dataset_long$ideology[dataset_long$Cosmopolitan < 0.5] <- "Communitarian"
dataset_long$ideology <- factor(dataset_long$ideology, levels = c("Communitarian", "Cosmopolitan"))

# Fit multilevel model with ideology interactions
model_ideology <- lmer(Choice ~ protect*ideology + border*ideology + rules*ideology + 
                         factor(country) + (1 | Respondent_ID), 
                       data = dataset_long)

summary(model_ideology)

# Get predictions for each ideology group using emmeans
get_ideology_predictions <- function(ideology_name) {
  # Predictions for mean
  emm_protect <- as.data.frame(emmeans(model_ideology, ~ protect | ideology, 
                                       at = list(ideology = ideology_name))) %>%
    mutate(Factor = "protect", Predictor = as.character(protect), ideology = ideology_name)
  
  # Predictions for rules
  emm_rules <- as.data.frame(emmeans(model_ideology, ~ rules | ideology, 
                                     at = list(ideology = ideology_name))) %>%
    mutate(Factor = "rules", Predictor = as.character(rules), ideology = ideology_name)
  
  # Predictions for border
  emm_border <- as.data.frame(emmeans(model_ideology, ~ border | ideology, 
                                      at = list(ideology = ideology_name))) %>%
    mutate(Factor = "border", Predictor = as.character(border), ideology = ideology_name)
  
  # Combine
  bind_rows(emm_protect, emm_rules, emm_border)
}

# Get predictions for both ideology groups
pred_all <- bind_rows(
  get_ideology_predictions("Communitarian"),
  get_ideology_predictions("Cosmopolitan")
) %>%
  mutate(
    Factor = factor(Factor, levels = c("protect", "border", "rules")),
    ideology = factor(ideology, levels = c("Communitarian", "Cosmopolitan"))
  )

# Define facet labels
facet_labels <- c(protect = "Refugee protection", border = "Border control", rules = "Bindingness")

jpeg("figureA9.jpeg", width = 9600, height = 4000, res = 1200)
ggplot(pred_all, aes(x = Predictor, y = emmean, color = ideology, group = ideology)) +
  geom_line(linewidth = 0.8, alpha = 0.7, position = position_dodge(width = 0.3)) +
  geom_point(size = 3, position = position_dodge(width = 0.3)) +
  geom_errorbar(aes(ymin = asymp.LCL, ymax = asymp.UCL),
                width = 0.2, linewidth = 0.6, 
                position = position_dodge(width = 0.3)) +
  facet_wrap(~ Factor, scales = "free_x", nrow = 1,
             labeller = labeller(Factor = facet_labels)) +
  scale_color_manual(
    values = c("Communitarian" = "#ff7f0e", "Cosmopolitan" = "#1f77b4"),
    labels = c("Communitarian", "Cosmopolitan")
  ) +
  labs(y = "Predicted support (marginal mean)", 
       color = "") +
  theme_ipsum() +
  theme(
    axis.title.x = element_blank(),
    axis.title.y = element_text(size = 12, margin = margin(r = 10)),
    axis.text.x = element_text(size = 10),
    strip.text = element_text(size = 13, face = "bold", hjust = 0.5),
    strip.background = element_rect(fill = "grey95", color = NA),
    legend.position = "top",
    legend.text = element_text(size = 11),
    legend.key.width = unit(1.5, "cm"),
    panel.spacing = unit(1.5, "lines"),
    panel.grid.major = element_line(linetype = "dotted", color = "grey60"),
    panel.grid.major.x = element_blank(),
    plot.margin = margin(10, 10, 10, 10)
  ) +
  guides(color = guide_legend(reverse = TRUE))
dev.off()

##########################
## R-code for replication

## Integration for Whom? The Migration Bias in Social Norms

# Date: 14.08.2025

## load libraries
library(foreign)
library(sjPlot)
library(sjmisc)
library(ggplot2)
library(ggpubr)
library(coefplot)
library(data.table)
library(corrplot)
library(stargazer)
library(dplyr)

## load data
data <- read.csv("euso.a.30-suppl-2.csv")

## prepare additional variables

# Function to recode values to 0 or 1 based on <10 or ==10
recode_to_0_1 <- function(x) {
  ifelse(x < 10, 0, 1)
}

data <- data %>%
  mutate(
    count=1,
    neighbours10 = recode_to_0_1(neighbours),
    association10 = recode_to_0_1(association),
    district10 = recode_to_0_1(district),
    tradition10 = recode_to_0_1(tradition),
    religion10 = recode_to_0_1(religion),
    value10 = recode_to_0_1(value),
    work10 = recode_to_0_1(work),
    job10 = recode_to_0_1(job),
    finances10 = recode_to_0_1(finances),
    gender10 = recode_to_0_1(gender),
    laws10 = recode_to_0_1(laws),
    politics10 = recode_to_0_1(politics),
    
    # Create norms columns
    norms = religion + gender + neighbours + association + district + tradition + value + work + job + finances + laws + politics,
    norms10 = religion10 + gender10 + neighbours10 + association10 + district10 + tradition10 + value10 + work10 + job10 + finances10 + laws10 + politics10,
    
    # Scale norms10 by 10
    norms10 = norms10 * 10
  )

# sub-samples
german <- subset(data, data$region=="german")
french <- subset(data, data$region=="french")
citizens <- subset(data, data$swiss==1)
noncitizens <- subset(data, data$swiss==0)
citizens_de <- subset(data, data$swiss==1 & data$region=="german")
noncitizens_de <- subset(data, data$swiss==0 & data$region=="german")
citizens_fr <- subset(data, data$swiss==1 & data$region=="french")
noncitizens_fr <- subset(data, data$swiss==0 & data$region=="french")

########################################
### Analysis

## Descriptive statistics

# Histogram and barplot of integration norms

# Create means, standard deviations, and labels for the variables
means <- c(
  mean(data$neighbours), mean(data$association), mean(data$district), mean(data$tradition), 
  mean(data$religion), mean(data$value), mean(data$work), mean(data$job), mean(data$finances), 
  mean(data$gender), mean(data$laws), mean(data$politics)
)

sd <- c(
  sd(data$neighbours), sd(data$association), sd(data$district), sd(data$tradition), 
  sd(data$religion), sd(data$value), sd(data$work), sd(data$job), sd(data$finances), 
  sd(data$gender), sd(data$laws), sd(data$politics)
)

names <- c(
  "Neighbours", "Association", "District", "Tradition", "Religion", "Values", 
  "Work", "Ambition", "Finances", "Gender", "Laws", "Politics"
)

means_sd <- data.frame(
  means = means, 
  sd = sd, 
  names = names
)

# Save plot as a jpeg file
jpeg("figure1.jpeg", width = 3600, height = 1900, res = 300)

# Create histogram of norms
par(mfrow=c(1,2), mar=c(3,3,2,2), mgp=c(2,.7,0), tck=-.01, las=1)
hist(data$norms, xlab="Agreement with social norms", border=F, ylab="Number of respondents", main="")

# Create bar plot with means and SD
par(mar=c(4,4,2,1), mgp=c(2,.7,0), tck=-.01, las=1, bty="l")
barCenters <- barplot(means_sd$means, ylim=c(0,10.9), border=F, ylab="Agreement with social norms", col = "lightblue")
segments(barCenters, means_sd$means - means_sd$sd, barCenters, means_sd$means + means_sd$sd, lwd = 0.7, col = "gray20")
arrows(barCenters, means_sd$means - means_sd$sd, barCenters, means_sd$means + means_sd$sd, 
       lwd = 0.7, angle = 90, code = 3, length = 0.05, col = "gray20")

# Add text labels and vertical lines
text(x = barCenters, y = par("usr")[3] - 0.3, srt = 45, adj = 1, labels = means_sd$names, xpd = TRUE)
text(x = 2, y = 10.2, labels = "Social", font=2)
text(x = 5.4, y = 10.2, labels = "Cultural", font=2)
text(x = 9.1, y = 10.2, labels = "Economic", font=2)
text(x = 13.2, y = 10.2, labels = "Political-legal", font=2)

# Add vertical dashed lines
abline(v = c(3.7, 7.3, 10.9), col="gray", lty=2)
dev.off()


# correlation plot
# Load required packages
library(ggcorrplot)
library(hrbrthemes)
library(RColorBrewer)

# Select relevant columns and compute correlation matrix
norms <- data[, c(6,7,8,9,10,11,12,13,14,15,16,17)]
colnames(norms) <- c("Gender", "Religion", "Values", "Neighbours", "Association",
                     "District", "Tradition", "Work", "Ambition", "Finances", "Laws", "Politics")
M <- cor(norms, use = "complete.obs")  # use = "complete.obs" handles missing values

# Plot with ggcorrplot using theme_ipsum style
jpeg("figureA1.jpeg", width = 1800, height = 1500, res = 300)
ggcorrplot(
  M,
  method = "square",              # Use squares instead of circles
  type = "lower",                 # Show only lower triangle
  lab = TRUE,                     # Show correlation coefficients
  lab_size = 3,                   # Label size
  colors = brewer.pal(n = 3, name = "RdBu"),  # Diverging color palette
  outline.col = "white",          # Add white outlines
  show.legend = TRUE,             # Show color legend
  tl.cex = 10,                    # Text label size
  hc.order=T,
  ggtheme = theme_ipsum(base_size = 12) +     # Apply hrbrthemes style
    theme(
      axis.text.x = element_text(angle = 45, hjust = 1),
      legend.position = "right"
    )
)
dev.off()

# Calculate Average Treatment Effects (ATEs) of Immigrant Treatment (vs. Society Treatment)
reg_base <- lm(norms ~ treatment_immigrant, data=data)
summary(reg_base) # 
reg_strong <- lm(norms10 ~ treatment_immigrant, data=data)
summary(reg_strong) #
reg_cit <- lm(norms ~ treatment_immigrant, data=citizens)
summary(reg_cit) # 
reg_noncit <- lm(norms ~ treatment_immigrant, data=noncitizens)
summary(reg_noncit) #
reg_de <- lm(norms ~ treatment_immigrant, data=german)
summary(reg_de) # 
reg_fr <- lm(norms ~ treatment_immigrant, data=french)
summary(reg_fr) # 

# Table A1: Model output of question wording experiment
stargazer(reg_base,reg_strong,reg_cit,reg_noncit,reg_de,reg_fr, 
          title="Model output", 
          align=F, 
          dep.var.labels=c("Baseline model", "Maximum importance", "Citizens", "Non-citizens", "German-speaking", "French-speaking"), 
          covariate.labels=c("Immigrant treatment"),  
          no.space=TRUE, 
          dep.var.caption="", 
          model.numbers=T,
          star.cutoffs = c(0.05, 0.01, 0.001))

# Treatment effect by region and citizenship
reg_swiss_reg <- lm(norms ~ treatment_immigrant*region, data=citizens) # 
summary(reg_swiss_reg) #
reg_noswiss_reg <- lm(norms ~ treatment_immigrant*region, data=noncitizens) # 
summary(reg_noswiss_reg) #

# Table A2: Model output with interaction terms
stargazer(reg_swiss_reg, reg_noswiss_reg,
          title="Model output", 
          align=F, 
          dep.var.labels=c("Citizens", "Non-citizens"), 
          covariate.labels=c("Immigrant treatment","German-speaking region", "Immigrant treatment*German-speaking region"),  
          no.space=TRUE, 
          dep.var.caption="", 
          model.numbers=T,
          star.cutoffs = c(0.05, 0.01, 0.001))

reg_int_de <- lm(norms ~ treatment_immigrant*integration, data=german) # 
summary(reg_int_de) # 
reg_int_fr <- lm(norms ~ treatment_immigrant*integration, data=french) # 
summary(reg_int_fr) # 

library(rcompanion)

# Calculate group means with confidence intervals
Sum <- groupwiseMean(norms ~ treatment_immigrant,
                     data   = data,
                     conf   = 0.95,
                     digits = 3)

# Label treatment groups
Sum$treatment <- ifelse(Sum$treatment_immigrant == 1, "Immigrants", "Society")

# Create figure 2a: Mean agreement by treatment
figure2a <- ggplot(Sum, aes(x = treatment, y = Mean)) +
  geom_bar(stat = "identity", fill = "gray") +
  geom_errorbar(aes(ymin = Trad.lower, ymax = Trad.upper), width = 0.15) +
  xlab("Treatment status") +
  ylab("Proportion of norm agreement (in %)") +
  theme_ipsum(base_size = 12)

Neighbours <- lm(neighbours ~ treatment_immigrant , data=data)
reg_neighbours10 <- lm(neighbours10 ~ treatment_immigrant, data=data)
Association <- lm(association ~ treatment_immigrant, data=data)
District <- lm(district ~ treatment_immigrant, data=data)
Tradition <- lm(tradition ~ treatment_immigrant, data=data)
Religion <- lm(religion ~ treatment_immigrant, data=data)
Values <- lm(value ~ treatment_immigrant, data=data)
Work <- lm(work ~ treatment_immigrant, data=data)
Job <- lm(job ~ treatment_immigrant, data=data)
Finances <- lm(finances ~ treatment_immigrant, data=data)
Gender <- lm(gender ~ treatment_immigrant, data=data)
Laws <- lm(laws ~ treatment_immigrant, data=data)
Politics <- lm(politics ~ treatment_immigrant, data=data)

library(coefplot)
p1 <- multiplot(Neighbours, Association, District, coefficients="treatment_immigrant", 
                newNames=c(treatment_immigrant='Immigrant\ntreatment'), 
                title="Social", ylab="", xlab="Strength of norm", numberAngle=0) + 
  theme_ipsum() + 
  theme(legend.position="bottom", legend.title=element_blank())

p2 <- multiplot(Tradition, Religion, Values, coefficients="treatment_immigrant", 
                newNames=c(treatment_immigrant='Immigrant\ntreatment'), 
                title="Cultural", ylab="", xlab="Strength of norm", numberAngle=0) + 
  theme_ipsum() + 
  theme(legend.position="bottom", legend.title=element_blank())

p3 <- multiplot(Work, Job, Finances, coefficients="treatment_immigrant", 
                newNames=c(treatment_immigrant='Immigrant\ntreatment'), 
                title="Economic", ylab="", xlab="Strength of norm", numberAngle=0) + 
  theme_ipsum() + 
  theme(legend.position="bottom", legend.title=element_blank())

p4 <- multiplot(Gender, Laws, Politics, coefficients="treatment_immigrant", 
                newNames=c(treatment_immigrant="Immigrant\ntreatment"), 
                title="Political-legal", ylab="", xlab="Strength of norm", numberAngle=0) + 
  theme_ipsum() + 
  theme(legend.position="bottom", legend.title=element_blank())

# Arrange all plots in a 2x2 grid while keeping separate legends
figure2b <- ggarrange(p1, p2, p3, p4, ncol = 2, nrow = 2)

library(cowplot)

# Combine the two figures side by side
combined_plot <- plot_grid(figure2a, figure2b, ncol = 2, rel_widths = c(1, 2))

# Save high-resolution JPEG
ggsave("figure2.jpeg", combined_plot, 
       width = 10.1, height = 6, dpi = 600, units = "in", device = "jpeg")

# calculate ATEs for citizens-sample
reg_norms <- lm(norms ~ treatment_immigrant, data=citizens)
Neighbours <- lm(neighbours ~ treatment_immigrant, data=citizens)
Association <- lm(association ~ treatment_immigrant, data=citizens)
District <- lm(district ~ treatment_immigrant, data=citizens)
Tradition <- lm(tradition ~ treatment_immigrant, data=citizens)
Religion <- lm(religion ~ treatment_immigrant, data=citizens)
Values <- lm(value ~ treatment_immigrant, data=citizens)
Work <- lm(work ~ treatment_immigrant, data=citizens)
Job <- lm(job ~ treatment_immigrant, data=citizens)
Finances <- lm(finances ~ treatment_immigrant, data=citizens)
Gender <- lm(gender ~ treatment_immigrant, data=citizens)
Laws <- lm(laws ~ treatment_immigrant, data=citizens)
Politics <- lm(politics ~ treatment_immigrant, data=citizens)

jpeg("figureA2.jpeg", width = 3000, height = 2200, res = 300)
p1 <- multiplot(Neighbours,Association,District, coefficients="treatment_immigrant", newNames=c(treatment_immigrant='Immigrant\ntreatment'), title="Social",ylab="", xlab="Strength of norm",numberAngle=0) + theme_ipsum() + theme(legend.position="bottom", legend.title=element_blank())
p2 <- multiplot(Tradition, Religion, Values, coefficients="treatment_immigrant", newNames=c(treatment_immigrant='Immigrant\ntreatment'), title="Cultural",ylab="", xlab="Strength of norm",numberAngle=0) + theme_ipsum() + theme(legend.position="bottom", legend.title=element_blank())
p3 <- multiplot(Work, Job, Finances, coefficients="treatment_immigrant", newNames=c(treatment_immigrant='Immigrant\ntreatment'), title="Economic",ylab="", xlab="Strength of norm",numberAngle=0) + theme_ipsum() + theme(legend.position="bottom", legend.title=element_blank())
p4 <- multiplot(Gender, Laws, Politics, coefficients="treatment_immigrant", newNames=c(treatment_immigrant='Immigrant\ntreatment'), title="Political-legal",ylab="", xlab="Strength of norm",numberAngle=0) + theme_ipsum() + theme(legend.position="bottom", legend.title=element_blank())
ggarrange(p1,p2,p3,p4,  ncol = 2, nrow = 2)
dev.off()

## the same for non-citizens
reg_norms <- lm(norms ~ treatment_immigrant, data=noncitizens)
Neighbours <- lm(neighbours ~ treatment_immigrant, data=noncitizens)
Association <- lm(association ~ treatment_immigrant, data=noncitizens)
District <- lm(district ~ treatment_immigrant, data=noncitizens)
Tradition <- lm(tradition ~ treatment_immigrant, data=noncitizens)
Religion <- lm(religion ~ treatment_immigrant, data=noncitizens)
Values <- lm(value ~ treatment_immigrant, data=noncitizens)
Work <- lm(work ~ treatment_immigrant, data=noncitizens)
Job <- lm(job ~ treatment_immigrant, data=noncitizens)
Finances <- lm(finances ~ treatment_immigrant, data=noncitizens)
Gender <- lm(gender ~ treatment_immigrant, data=noncitizens)
Laws <- lm(laws ~ treatment_immigrant, data=noncitizens)
Politics <- lm(politics ~ treatment_immigrant, data=noncitizens)

jpeg("figureA3.jpeg", width = 3000, height = 2200, res = 300)
p1 <- multiplot(Neighbours, Association, District, coefficients="treatment_immigrant", newNames=c(treatment_immigrant='Immigrant\ntreatment'), title="Social", ylab="", xlab="Strength of norm",numberAngle=0) + theme_ipsum() + theme(legend.position="bottom", legend.title=element_blank())
p2 <- multiplot(Tradition, Religion, Values, coefficients="treatment_immigrant", newNames=c(treatment_immigrant='Immigrant\ntreatment'), title="Cultural", ylab="", xlab="Strength of norm",numberAngle=0) + theme_ipsum() + theme(legend.position="bottom", legend.title=element_blank())
p3 <- multiplot(Work, Job, Finances, coefficients="treatment_immigrant", newNames=c(treatment_immigrant='Immigrant\ntreatment'), title="Economic", ylab="", xlab="Strength of norm",numberAngle=0) + theme_ipsum() + theme(legend.position="bottom", legend.title=element_blank())
p4 <- multiplot(Gender, Laws, Politics, coefficients="treatment_immigrant", newNames=c(treatment_immigrant='Immigrant\ntreatment'), title="Political-legal", ylab="", xlab="Strength of norm",numberAngle=0) + theme_ipsum() + theme(legend.position="bottom", legend.title=element_blank())
ggarrange(p1,p2,p3,p4,  ncol = 2, nrow = 2)
dev.off()

# language region
data$Treatment <- NA
data$Treatment[data$treatment_immigrant==1] <- "Immigrant"
data$Treatment[data$treatment_immigrant==0] <- "Society"
reg_context <- lm(norms ~ region*Treatment + integration, data=data)
summary(reg_context) # 
plot_context <- plot_model(reg_context, type='int') + 
  xlab("Language region") + 
  theme_ipsum() + 
  ylab("Strength of social norms") + 
  ggtitle("(a) Societal context") +
  theme(plot.title = element_text(hjust = 0, size = 12, face = "bold"))

reg_ind <- lm(norms ~ integration*Treatment, data=data)
summary(reg_ind) # significant interaction

plot_ind <- plot_model(reg_ind, type='int') + 
  xlab("Integration expectations") + 
  theme_ipsum() + 
  ylab("Strength of social norms") + 
  ggtitle("(b) Individual predispositions") +
  theme(plot.title = element_text(hjust = 0, size = 12, face = "bold"))

jpeg("figure4.jpeg", width = 3000, height = 1600, res = 300)
ggarrange(plot_context, plot_ind, 
          ncol = 2, nrow = 1, 
          widths = c(1.4, 2))  # left plot: 1/3, right plot: 2/3
dev.off()

# effect of Ukraine invasion

# Define the cutoff date
cutoff_date <- as.POSIXct("2022-02-24 00:00:00")

# Count the number of responses before the cutoff date
num_responses_de <- sum(data$RecordedDate[data$region=="german"] < cutoff_date)
num_responses_fr <- sum(data$RecordedDate[data$region=="french"] < cutoff_date)

# Print the result
print(num_responses_de) # N=71
print(num_responses_fr) # N=30
# total of 101 --> so 10% before the start of the invasion

# create dummy variable
data$before_feb24 <- ifelse(data$RecordedDate < cutoff_date, 1, 0)

t_test_result <- t.test(data$norms ~ data$before_feb24)
print(t_test_result)

## equivalence analysis

# Load necessary packages
library(lavaan)
library(semTools)

# Assuming 'data' has both norm variables and treatment_immigrant
head(data[, c("gender", "religion", "value", "neighbours", "association", "district", "tradition", "work", "job", "finances", "laws", "politics", "treatment_immigrant")])

library(lavaan)

# Specify the CFA model with latent variable 'norms' representing the agreement with norms
cfa_model <- '
  norms_latent =~ gender + religion + value + neighbours + association + district + tradition + work + job + finances + laws + politics
'
# Fit the CFA model for both groups separately
fit_group0 <- cfa(cfa_model, data = data[data$treatment_immigrant == 0, ], std.lv = TRUE)
fit_group1 <- cfa(cfa_model, data = data[data$treatment_immigrant == 1, ], std.lv = TRUE)

summary(fit_group0)
summary(fit_group1)

# Use semTools to run full measurement invariance test
measurementInvariance(model = cfa_model, data = data, group = "treatment_immigrant")

# Configural model 
configural_model <- cfa(cfa_model, data = data, group = "treatment_immigrant", std.lv = TRUE)

# Summarize the configural model
summary(configural_model, fit.measures = TRUE)

# Metric model
metric_model <- cfa(cfa_model, data = data, group = "treatment_immigrant", std.lv = TRUE,
                    group.equal = "loadings")

# Summarize the metric model
summary(metric_model, fit.measures = TRUE)

# Scalar model 
scalar_model <- cfa(cfa_model, data = data, group = "treatment_immigrant", std.lv = TRUE,
                    group.equal = c("loadings", "intercepts"))

# Summarize the scalar model
summary(scalar_model, fit.measures = TRUE)

# Perform chi-square difference test between configural and metric models
anova(configural_model, metric_model)

# Perform chi-square difference test between metric and scalar models
anova(metric_model, scalar_model)

# Load theme
theme_set(theme_ipsum())

# Define colors with transparency
mycol1 <- adjustcolor("red", alpha.f = 0.5)
mycol2 <- adjustcolor("black", alpha.f = 0.5)

library(ggpubr)
library(data.table)
library(ggplot2)

# Define a function to create aggregated data and plots for any engagement measure
create_plot <- function(data, engagement_var, title, mycol1, mycol2) {
  # Convert to data.table if it's not already
  if(!is.data.table(data)) {
    data <- as.data.table(data)
  }
  
  # Use formula interface for aggregate which works with data.frames and data.tables
  formula_str <- paste("count ~", "treatment_immigrant +", engagement_var)
  sum_data <- aggregate(as.formula(formula_str), data = data, FUN = sum)
  
  # Add treatment label
  sum_data$rx <- ifelse(sum_data$treatment_immigrant == 0, "society", "immigrants")
  
  # Convert to data.table for further processing
  sum_data <- as.data.table(sum_data)
  
  # Select and rename columns
  colnames(sum_data)[which(colnames(sum_data) == engagement_var)] <- "WHO"
  sum_data <- sum_data[, .(rx, WHO, N = count)]
  setorder(sum_data, rx, WHO)
  
  # Calculate proportions efficiently
  sum_data[, prop := N / sum(N), by = rx]
  
  # Create legend labels once
  sum_data[, legend_label := rx]
  
  # Create plot
  ggplot(sum_data, aes(x = WHO, y = prop)) +
    geom_line(aes(group = legend_label, color = legend_label), size = 1) +
    geom_point(aes(color = legend_label), size = 2) +
    ylim(0, 0.5) +
    theme(panel.grid = element_blank(),
          legend.title = element_blank(),
          legend.position = c(.5, .8)) +
    scale_color_manual(values = c(mycol1, mycol2),
                       labels = c("immigrants" = "Immigrant treatment", "society" = "Society treatment"),
                       guide = guide_legend(reverse = TRUE)) +
    scale_x_discrete(labels = c("fully disagree", 1:9, "fully agree")) +
    ylab("Proportion") +
    xlab(title)
}

# Create all twelve plots using the function
plot1 <- create_plot(data, "neighbours", "Neighbourhood engagement", mycol1, mycol2)
plot2 <- create_plot(data, "association", "Association engagement", mycol1, mycol2)
plot3 <- create_plot(data, "district", "Involvement in local community", mycol1, mycol2)
plot4 <- create_plot(data, "tradition", "Practising customs and traditions", mycol1, mycol2)
plot5 <- create_plot(data, "religion", "Practising religion privately", mycol1, mycol2)
plot6 <- create_plot(data, "value", "Respecting constitutional values", mycol1, mycol2)
plot7 <- create_plot(data, "work", "Working", mycol1, mycol2)
plot8 <- create_plot(data, "job", "Job ambitions", mycol1, mycol2)
plot9 <- create_plot(data, "finances", "Financial independence", mycol1, mycol2)
plot10 <- create_plot(data, "gender", "Gender equality", mycol1, mycol2)
plot11 <- create_plot(data, "laws", "Respecting laws", mycol1, mycol2)
plot12 <- create_plot(data, "politics", "Participating in politics", mycol1, mycol2)

# Figure 3: Distribution of norm support by treatment status
jpeg("figure3.jpeg", width = 2500, height = 2500, res = 300)  
ggarrange(
  plot1, plot2, plot3, plot4,
  plot5, plot6, plot7, plot8,
  plot9, plot10, plot11, plot12,
  ncol = 3, nrow = 4,
  labels = NULL,
  common.legend = TRUE,
  legend = "bottom"
)
dev.off()

library(data.table)
library(ggplot2)

# Define a function to create aggregated data and plots with CUMULATIVE proportions
create_cumulative_plot <- function(data, engagement_var, title, mycol1, mycol2) {
  # Convert to data.table if it's not already
  if(!is.data.table(data)) {
    data <- as.data.table(data)
  }
  
  # Use formula interface for aggregate which works with data.frames and data.tables
  formula_str <- paste("count ~", "treatment_immigrant +", engagement_var)
  sum_data <- aggregate(as.formula(formula_str), data = data, FUN = sum)
  
  # Add treatment label
  sum_data$rx <- ifelse(sum_data$treatment_immigrant == 0, "society", "immigrants")
  
  # Convert to data.table for further processing
  sum_data <- as.data.table(sum_data)
  
  # Select and rename columns
  colnames(sum_data)[which(colnames(sum_data) == engagement_var)] <- "WHO"
  sum_data <- sum_data[, .(rx, WHO, N = count)]
  setorder(sum_data, rx, WHO)  # Order by rx first, then WHO
  
  # Calculate proportions efficiently
  sum_data[, prop := N / sum(N), by = rx]
  
  # Calculate cumulative proportions by treatment group
  sum_data[, cum_prop := cumsum(prop), by = rx]
  
  # Create legend labels once
  sum_data[, legend_label := rx]
  
  # Create plot with cumulative proportions
  ggplot(sum_data, aes(x = WHO, y = cum_prop)) +  # 
    geom_line(aes(group = legend_label, color = legend_label), size = 1) +
    geom_point(aes(color = legend_label), size = 2) +
    ylim(0, 1) +  # Changed to 0-1 range for cumulative proportions
    theme(panel.grid = element_blank(),
          legend.title = element_blank(),
          legend.position = c(.5, .8)) +
    # Replace the scale_color_manual section with:
    scale_color_manual(values = c("immigrants" = mycol2, "society" = mycol1),
                       labels = c("immigrants" = "Immigrant treatment", "society" = "Society treatment"),
                       guide = guide_legend(reverse = TRUE)) +
    scale_x_discrete(labels = c("fully disagree", 1:9, "fully agree")) +
    ylab("Cumulative proportion") +  # 
    xlab(title)
}

# Create all twelve plots using the function
plot1 <- create_cumulative_plot(data, "neighbours", "Neighbourhood engagement", mycol1, mycol2)
plot2 <- create_cumulative_plot(data, "association", "Association engagement", mycol1, mycol2)
plot3 <- create_cumulative_plot(data, "district", "Involvement in local community", mycol1, mycol2)
plot4 <- create_cumulative_plot(data, "tradition", "Practising customs and traditions", mycol1, mycol2)
plot5 <- create_cumulative_plot(data, "religion", "Practising religion privately", mycol1, mycol2)
plot6 <- create_cumulative_plot(data, "value", "Respecting constitutional values", mycol1, mycol2)
plot7 <- create_cumulative_plot(data, "work", "Working", mycol1, mycol2)
plot8 <- create_cumulative_plot(data, "job", "Job ambitions", mycol1, mycol2)
plot9 <- create_cumulative_plot(data, "finances", "Financial independence", mycol1, mycol2)
plot10 <- create_cumulative_plot(data, "gender", "Gender equality", mycol1, mycol2)
plot11 <- create_cumulative_plot(data, "laws", "Respecting laws", mycol1, mycol2)
plot12 <- create_cumulative_plot(data, "politics", "Participating in politics", mycol1, mycol2)

# Figure A4: Cumulative agreement with social norms by treatment status
jpeg("figureA4.jpeg", width = 2500, height = 2500, res = 300)  # 12x12 inches at 300 dpi
ggarrange(plot1, plot2, plot3, plot4,plot5, plot6, plot7, plot8,plot9, plot10, plot11, plot12,
  ncol = 3, nrow = 4,labels = NULL,common.legend = TRUE,legend = "bottom")
dev.off()

## separate for German-speaking sample
plot1 <- create_plot(german, "neighbours", "Neighbourhood engagement", mycol1, mycol2)
plot2 <- create_plot(german, "association", "Association engagement", mycol1, mycol2)
plot3 <- create_plot(german, "district", "Involvement in local community", mycol1, mycol2)
plot4 <- create_plot(german, "tradition", "Practising customs and traditions", mycol1, mycol2)
plot5 <- create_plot(german, "religion", "Practising religion privately", mycol1, mycol2)
plot6 <- create_plot(german, "value", "Respecting constitutional values", mycol1, mycol2)
plot7 <- create_plot(german, "work", "Working", mycol1, mycol2)
plot8 <- create_plot(german, "job", "Job ambitions", mycol1, mycol2)
plot9 <- create_plot(german, "finances", "Financial independence", mycol1, mycol2)
plot10 <- create_plot(german, "gender", "Gender equality", mycol1, mycol2)
plot11 <- create_plot(german, "laws", "Respecting laws", mycol1, mycol2)
plot12 <- create_plot(german, "politics", "Participating in politics", mycol1, mycol2)


# combine these plots into one
jpeg("figureA5.jpeg", width = 2500, height = 2500, res = 300) 
ggarrange(plot1,plot2,plot3,plot4,plot5,plot6,plot7,plot8,plot9,plot10,plot11,plot12, 
          ncol = 3, nrow = 4,labels=NULL, common.legend = TRUE,legend = "bottom")
dev.off()

## separate for French-speaking sample
plot1 <- create_plot(french, "neighbours", "Neighbourhood engagement", mycol1, mycol2)
plot2 <- create_plot(french, "association", "Association engagement", mycol1, mycol2)
plot3 <- create_plot(french, "district", "Involvement in local community", mycol1, mycol2)
plot4 <- create_plot(french, "tradition", "Practising customs and traditions", mycol1, mycol2)
plot5 <- create_plot(french, "religion", "Practising religion privately", mycol1, mycol2)
plot6 <- create_plot(french, "value", "Respecting constitutional values", mycol1, mycol2)
plot7 <- create_plot(french, "work", "Working", mycol1, mycol2)
plot8 <- create_plot(french, "job", "Job ambitions", mycol1, mycol2)
plot9 <- create_plot(french, "finances", "Financial independence", mycol1, mycol2)
plot10 <- create_plot(french, "gender", "Gender equality", mycol1, mycol2)
plot11 <- create_plot(french, "laws", "Respecting laws", mycol1, mycol2)
plot12 <- create_plot(french, "politics", "Participating in politics", mycol1, mycol2)

# Figure A6: Norm agreement by treatment status (French-speaking region)
jpeg("figureA6.jpeg", width = 2500, height = 2500, res = 300)  
ggarrange(plot1,plot2,plot3,plot4,plot5,plot6,plot7,plot8,plot9,plot10,plot11,plot12, 
          ncol = 3, nrow = 4,labels=NULL, common.legend = TRUE,legend = "bottom")
dev.off()

## separate for citizens
plot1 <- create_plot(citizens, "neighbours", "Neighbourhood engagement", mycol1, mycol2)
plot2 <- create_plot(citizens, "association", "Association engagement", mycol1, mycol2)
plot3 <- create_plot(citizens, "district", "Involvement in local community", mycol1, mycol2)
plot4 <- create_plot(citizens, "tradition", "Practising customs and traditions", mycol1, mycol2)
plot5 <- create_plot(citizens, "religion", "Practising religion privately", mycol1, mycol2)
plot6 <- create_plot(citizens, "value", "Respecting constitutional values", mycol1, mycol2)
plot7 <- create_plot(citizens, "work", "Working", mycol1, mycol2)
plot8 <- create_plot(citizens, "job", "Job ambitions", mycol1, mycol2)
plot9 <- create_plot(citizens, "finances", "Financial independence", mycol1, mycol2)
plot10 <- create_plot(citizens, "gender", "Gender equality", mycol1, mycol2)
plot11 <- create_plot(citizens, "laws", "Respecting laws", mycol1, mycol2)
plot12 <- create_plot(citizens, "politics", "Participating in politics", mycol1, mycol2)

jpeg("figureA7.jpeg", width = 2500, height = 2500, res = 300)  # 12x12 inches at 300 dpi
ggarrange(plot1,plot2,plot3,plot4,plot5,plot6,plot7,plot8,plot9,plot10,plot11,plot12, 
          ncol = 3, nrow = 4,labels=NULL, common.legend = TRUE,legend = "bottom")
dev.off()

## separate for non-citizens
plot1 <- create_plot(noncitizens, "neighbours", "Neighbourhood engagement", mycol1, mycol2)
plot2 <- create_plot(noncitizens, "association", "Association engagement", mycol1, mycol2)
plot3 <- create_plot(noncitizens, "district", "Involvement in local community", mycol1, mycol2)
plot4 <- create_plot(noncitizens, "tradition", "Practising customs and traditions", mycol1, mycol2)
plot5 <- create_plot(noncitizens, "religion", "Practising religion privately", mycol1, mycol2)
plot6 <- create_plot(noncitizens, "value", "Respecting constitutional values", mycol1, mycol2)
plot7 <- create_plot(noncitizens, "work", "Working", mycol1, mycol2)
plot8 <- create_plot(noncitizens, "job", "Job ambitions", mycol1, mycol2)
plot9 <- create_plot(noncitizens, "finances", "Financial independence", mycol1, mycol2)
plot10 <- create_plot(noncitizens, "gender", "Gender equality", mycol1, mycol2)
plot11 <- create_plot(noncitizens, "laws", "Respecting laws", mycol1, mycol2)
plot12 <- create_plot(noncitizens, "politics", "Participating in politics", mycol1, mycol2)

jpeg("figureA8.jpeg", width = 2500, height = 2500, res = 300)  # 12x12 inches at 300 dpi
ggarrange(plot1,plot2,plot3,plot4,plot5,plot6,plot7,plot8,plot9,plot10,plot11,plot12, 
          ncol = 3, nrow = 4,labels=NULL, common.legend = TRUE,legend = "bottom")
dev.off()
